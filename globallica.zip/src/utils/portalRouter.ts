import { RBACRole } from '../types';

export type PortalId = 'vault' | 'caretaker' | 'seller' | 'fundi' | 'public';

export interface PortalConfig {
  id: PortalId;
  name: string;
  subdomains: string[]; // e.g. ['vault', 'admin']
  canonicalHost: string; // e.g. 'vault.globallica.com'
  requiredRoles: (RBACRole | 'resident')[];
  description: string;
  loginMessage: string;
  themeColor: {
    bg: string;
    border: string;
    text: string;
    badge: string;
  };
  iconName: string;
}

export const PORTAL_REGISTRY: Record<PortalId, PortalConfig> = {
  vault: {
    id: 'vault',
    name: 'GLOBALLICA Vault & Admin Portal',
    subdomains: ['vault', 'admin', 'secure'],
    canonicalHost: 'vault.globallica.com',
    requiredRoles: ['admin'],
    description: 'Restricted administrative portal for system audits, escrow releases, and fraud management.',
    loginMessage: 'Access to vault.globallica.com requires an authenticated Admin account.',
    themeColor: {
      bg: 'bg-purple-950/90',
      border: 'border-purple-500/50',
      text: 'text-purple-300',
      badge: 'bg-purple-500 text-purple-950'
    },
    iconName: 'Lock'
  },
  caretaker: {
    id: 'caretaker',
    name: 'Caretaker & Landlord Portal',
    subdomains: ['caretaker', 'landlord', 'estates', 'housing-admin'],
    canonicalHost: 'caretaker.globallica.com',
    requiredRoles: ['caretaker', 'admin'],
    description: 'Dedicated portal for managing vacancy listings, Ardhisasa title deeds, and tenant vetting.',
    loginMessage: 'Access to caretaker.globallica.com requires a registered Caretaker or Landlord account.',
    themeColor: {
      bg: 'bg-blue-950/90',
      border: 'border-blue-500/50',
      text: 'text-blue-300',
      badge: 'bg-blue-500 text-blue-950'
    },
    iconName: 'Home'
  },
  seller: {
    id: 'seller',
    name: 'Verified Merchant & Seller Portal',
    subdomains: ['seller', 'merchant', 'store', 'market-admin'],
    canonicalHost: 'seller.globallica.com',
    requiredRoles: ['seller', 'admin'],
    description: 'Portal for posting inventory, bulk uploading products, and monitoring customer orders.',
    loginMessage: 'Access to seller.globallica.com requires a verified Seller account.',
    themeColor: {
      bg: 'bg-emerald-950/90',
      border: 'border-emerald-500/50',
      text: 'text-emerald-300',
      badge: 'bg-emerald-500 text-emerald-950'
    },
    iconName: 'ShoppingBag'
  },
  fundi: {
    id: 'fundi',
    name: 'Fundi & Artisan Services Portal',
    subdomains: ['fundi', 'pro', 'artisan', 'services-admin'],
    canonicalHost: 'fundi.globallica.com',
    requiredRoles: ['fundi', 'admin'],
    description: 'Service provider portal for managing trade verification, live selfie badges, and job quotes.',
    loginMessage: 'Access to fundi.globallica.com requires a verified Fundi or Artisan account.',
    themeColor: {
      bg: 'bg-amber-950/90',
      border: 'border-amber-500/50',
      text: 'text-amber-300',
      badge: 'bg-amber-400 text-amber-950'
    },
    iconName: 'Wrench'
  },
  public: {
    id: 'public',
    name: 'GLOBALLICA Public Marketplace',
    subdomains: ['www', 'app', 'globallica', 'main'],
    canonicalHost: 'www.globallica.com',
    requiredRoles: ['customer', 'resident', 'caretaker', 'seller', 'fundi', 'admin'],
    description: 'Main public marketplace open to all buyers, tenants, and service seekers.',
    loginMessage: 'Sign in to access personalized features and bookings.',
    themeColor: {
      bg: 'bg-emerald-900/90',
      border: 'border-emerald-700/50',
      text: 'text-emerald-200',
      badge: 'bg-emerald-400 text-emerald-950'
    },
    iconName: 'Globe'
  }
};

/**
 * Extracts subdomain from host string (e.g., 'vault.globallica.com' -> 'vault')
 */
export function extractSubdomain(hostname: string): string {
  // Normalize hostname
  const host = hostname.toLowerCase().split(':')[0]; // strip port

  // Handle IP addresses or localhost
  if (host === 'localhost' || host === '127.0.0.1' || host.endsWith('.run.app')) {
    return 'public';
  }

  const parts = host.split('.');
  if (parts.length >= 3) {
    return parts[0];
  }
  return 'public';
}

/**
 * Detects the current active portal configuration based on hostname or search parameter simulation
 */
export function detectCurrentPortal(
  hostname: string = typeof window !== 'undefined' ? window.location.hostname : '',
  searchParams?: URLSearchParams
): { portal: PortalConfig; isSimulated: boolean; detectedSubdomain: string } {
  // 1. Check for explicit search parameter simulation (e.g. ?portal=vault or ?subdomain=caretaker)
  if (searchParams) {
    const simParam = searchParams.get('portal') || searchParams.get('subdomain');
    if (simParam) {
      const lowerSim = simParam.toLowerCase();
      for (const portalKey of Object.keys(PORTAL_REGISTRY) as PortalId[]) {
        const portal = PORTAL_REGISTRY[portalKey];
        if (portal.id === lowerSim || portal.subdomains.includes(lowerSim)) {
          return { portal, isSimulated: true, detectedSubdomain: lowerSim };
        }
      }
    }
  }

  // 2. Check localStorage for dev session simulation
  if (typeof window !== 'undefined') {
    const storedPortal = localStorage.getItem('globallica_simulated_portal');
    if (storedPortal && PORTAL_REGISTRY[storedPortal as PortalId]) {
      return { 
        portal: PORTAL_REGISTRY[storedPortal as PortalId], 
        isSimulated: true, 
        detectedSubdomain: PORTAL_REGISTRY[storedPortal as PortalId].subdomains[0] 
      };
    }
  }

  // 3. Extract actual subdomain from hostname
  const subdomain = extractSubdomain(hostname);
  for (const portalKey of Object.keys(PORTAL_REGISTRY) as PortalId[]) {
    const portal = PORTAL_REGISTRY[portalKey];
    if (portal.subdomains.includes(subdomain)) {
      return { portal, isSimulated: false, detectedSubdomain: subdomain };
    }
  }

  // Default fallback to public portal
  return { portal: PORTAL_REGISTRY.public, isSimulated: false, detectedSubdomain: subdomain };
}

export interface PortalAccessDecision {
  allowed: boolean;
  portal: PortalConfig;
  detectedSubdomain: string;
  userRole: string | null;
  isAuthenticated: boolean;
  reason?: string;
  loginRedirectRequired: boolean;
}

/**
 * Evaluates whether a user role matches the required permissions for the given portal
 */
export function checkPortalAccess(params: {
  userRole?: string | null;
  isAuthenticated?: boolean;
  hostname?: string;
  searchParams?: URLSearchParams;
}): PortalAccessDecision {
  const { portal, detectedSubdomain } = detectCurrentPortal(params.hostname, params.searchParams);
  const isAuthenticated = Boolean(params.isAuthenticated);
  const normalizedUserRole = (params.userRole || '').toLowerCase();

  // Public portal allows everyone
  if (portal.id === 'public') {
    return {
      allowed: true,
      portal,
      detectedSubdomain,
      userRole: params.userRole || null,
      isAuthenticated,
      loginRedirectRequired: false
    };
  }

  // Protected portal checks
  if (!isAuthenticated && !normalizedUserRole) {
    return {
      allowed: false,
      portal,
      detectedSubdomain,
      userRole: null,
      isAuthenticated: false,
      reason: `Unauthenticated access to ${portal.canonicalHost}. Authentication is mandatory.`,
      loginRedirectRequired: true
    };
  }

  // Check if role matches required roles for portal
  const hasMatchingRole = portal.requiredRoles.some(role => {
    const r = role.toLowerCase();
    if (r === 'customer' || r === 'resident') {
      return normalizedUserRole === 'customer' || normalizedUserRole === 'resident';
    }
    return r === normalizedUserRole;
  });

  if (!hasMatchingRole) {
    return {
      allowed: false,
      portal,
      detectedSubdomain,
      userRole: params.userRole || null,
      isAuthenticated,
      reason: `User role '${params.userRole || 'Guest'}' does not have permission to access '${portal.name}' (${portal.canonicalHost}). Required role(s): ${portal.requiredRoles.join(', ')}.`,
      loginRedirectRequired: true
    };
  }

  return {
    allowed: true,
    portal,
    detectedSubdomain,
    userRole: params.userRole || null,
    isAuthenticated,
    loginRedirectRequired: false
  };
}

/**
 * Utility to force redirect or trigger portal login workflow
 */
export function executePortalLoginRedirect(portal: PortalConfig, reason?: string) {
  if (typeof window === 'undefined') return;

  console.warn(`[PortalRouter] Redirecting to login for portal '${portal.name}':`, reason);

  // Store redirect cause in session for login modal feedback
  sessionStorage.setItem('globallica_portal_redirect_cause', JSON.stringify({
    portalId: portal.id,
    portalName: portal.name,
    canonicalHost: portal.canonicalHost,
    reason: reason || portal.loginMessage,
    timestamp: Date.now()
  }));

  // Emit portal security event for state listeners
  window.dispatchEvent(new CustomEvent('globallica_portal_security_redirect', {
    detail: { portal, reason }
  }));
}
