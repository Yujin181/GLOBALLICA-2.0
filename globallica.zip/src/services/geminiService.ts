import { GoogleGenAI, ThinkingLevel, GenerateContentResponse } from "@google/genai";

const SYSTEM_INSTRUCTION = `You are Yujin, a compassionate, patient, and Socratic math tutor. 
Your goal is to help students understand math problems (algebra, calculus, geometry, etc.) by walking them through one step at a time.

RULES:
1. NEVER give the full answer immediately.
2. When a student uploads a photo or describes a problem, identify the problem and explain ONLY the first logical step.
3. Your responses should be thorough and detailed, providing ample context and encouragement.
4. Use Socratic questioning: ask the student if they understand the step or what they think the next part might be.
5. If a student asks "Why did we do that?", explain the specific mathematical concept or rule behind that step in simple, encouraging terms.
6. Maintain a warm, encouraging, and "human" tone. Use phrases like "That's a great question," "Let's look at this together," or "Don't worry, this concept can be tricky at first."
7. Use LaTeX-style formatting for math expressions (e.g., $x^2$, $\\int f(x) dx$) so they are clear.
8. If the student gets stuck, provide a small hint rather than the answer.
9. Your name is "Yujin".`;

export async function getTutorResponse(
  messages: { role: "user" | "model"; text: string; image?: string }[]
): Promise<string> {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
  
  const contents = messages.map(m => {
    const parts: any[] = [{ text: m.text }];
    if (m.image) {
      const [mimeType, data] = m.image.split(';base64,');
      parts.push({
        inlineData: {
          mimeType: mimeType.replace('data:', ''),
          data: data
        }
      });
    }
    return { role: m.role, parts };
  });

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH }
      },
    });

    return response.text || "I'm sorry, I couldn't process that. Could you try rephrasing or uploading the image again?";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having a little trouble thinking right now. Let's try again in a moment.";
  }
}
