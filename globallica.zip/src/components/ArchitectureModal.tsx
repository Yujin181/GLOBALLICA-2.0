import React, { useState } from 'react';
import { X, Database, FolderTree, Code, Server, Shield, Smartphone, Terminal, Copy, Check } from 'lucide-react';

interface ArchitectureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureModal: React.FC<ArchitectureModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'folder' | 'schema' | 'api' | 'geospatial'>('folder');
  const [copied, setCopied] = useState(false);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const folderStructureText = `
globallica-marketplace/
├── package.json
├── tsconfig.json
├── vite.config.ts
├── metadata.json
├── src/
│   ├── main.tsx
│   ├── App.tsx                       # Main application shell & tab routing
│   ├── index.css                     # Mobile-first Tailwind styling & fonts
│   ├── types/
│   │   └── index.ts                  # TypeScript interfaces (RBAC, Housing, Fundi, Products)
│   ├── data/
│   │   ├── locations.ts              # Kenyan location taxonomy (County -> Constituency -> Ward)
│   │   └── mockData.ts               # Sample houses in Kilimani/Mirema, Fundis, Vehicles
│   ├── components/
│   │   ├── Header.tsx                # Sticky topbar with role switcher & search trigger
│   │   ├── MobileNav.tsx             # Mobile bottom nav bar
│   │   ├── HeroSearch.tsx            # Cascading Location dropdowns & category quick-filters
│   │   ├── HousingModule.tsx         # Caretaker & Vacancy directory with Call/WhatsApp
│   │   ├── ServiceProvidersModule.tsx# Local Fundi directory with Haversine distance
│   │   ├── MarketplaceModule.tsx     # Cars & General products with inventory toggle
│   │   ├── CaretakerPortalModal.tsx  # Landlord vacancy listing onboarding form
│   │   ├── FundiOnboardingModal.tsx  # Fundi trade skill registration form
│   │   ├── SellerPostModal.tsx       # Vehicle/Product listing form
│   │   ├── MpesaModal.tsx            # Safaricom Daraja M-Pesa STK push simulator
│   │   ├── SafetyTipsModal.tsx       # Anti-scam trust guidelines for Kenya
│   │   └── ArchitectureModal.tsx     # Technical Blueprint & Schema Docs Viewer
└── prisma/
    └── schema.prisma                 # PostgreSQL database schema with PostGIS extension
`;

  const prismaSchemaText = `
// prisma/schema.prisma - GLOBALLICA PostgreSQL Schema with PostGIS Geospatial Support

datasource db {
  provider   = "postgresql"
  url        = env("DATABASE_URL")
  extensions = [postgis]
}

generator client {
  provider        = "prisma-client-js"
  previewFeatures = ["postgresqlExtensions"]
}

enum Role {
  CUSTOMER
  CARETAKER
  SELLER
  FUNDI
  ADMIN
}

enum HouseType {
  BEDSITTER
  SINGLE_ROOM
  ONE_BEDROOM
  TWO_BEDROOM
  THREE_BEDROOM
  MAISONETTE
  COMMERCIAL
  AIRBNB
}

enum TradeSkill {
  PLUMBER
  ELECTRICIAN
  AUTO_MECHANIC
  CARPENTER
  MAMA_FUA
  BODABODA_RIDER
  MASON_PAINTER
  APPLIANCE_REPAIR
}

enum AvailabilityStatus {
  AVAILABLE_NOW
  ON_A_JOB
  OFF_DUTY
}

model User {
  id              String         @id @default(uuid())
  phone           String         @unique // e.g. +254712345678
  email           String?        @unique
  name            String
  role            Role           @default(CUSTOMER)
  county          String
  estate          String
  avatarUrl       String?
  isVerified      Boolean        @default(false)
  createdAt       DateTime       @default(now())

  // Relations
  caretaker       Caretaker?
  serviceProvider ServiceProvider?
  products        ProductListing[]
  reviewsWritten  Review[]       @relation("ReviewAuthor")
}

model Caretaker {
  id              String           @id @default(uuid())
  userId          String           @unique
  user            User             @relation(fields: [userId], references: [id])
  agencyName      String?
  propertiesCount Int              @default(1)
  rating          Float            @default(5.0)
  isVerified      Boolean          @default(true)
  listings        HousingListing[]
}

model HousingListing {
  id           String      @id @default(uuid())
  caretakerId  String
  caretaker    Caretaker   @relation(fields: [caretakerId], references: [id])
  title        String
  houseType    HouseType
  rentKES      Int
  depositTerms String
  county       String
  constituency String
  estate       String
  latitude     Float
  longitude    Float
  amenities    String[]    // Borehole, KPLC Tokens, Wi-Fi, CCTV, Parking
  photos       String[]
  description  String
  status       String      @default("vacant") // vacant | occupied
  viewsCount   Int         @default(0)
  createdAt    DateTime    @default(now())

  // PostGIS spatial point for location indexing
  // ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)
}

model ServiceProvider {
  id                 String             @id @default(uuid())
  userId             String             @unique
  user               User               @relation(fields: [userId], references: [id])
  tradeSkill         TradeSkill
  operationalCounty  String
  operationalEstate  String
  latitude           Float
  longitude          Float
  pricingModel       String             // Per Hour | Per Job | Negotiable
  rateKES            Int
  availability       AvailabilityStatus @default(AVAILABLE_NOW)
  badge              String             @default("Verified Fundi")
  rating             Float              @default(5.0)
  completedJobsCount Int                @default(0)
  bio                String
  skillsList         String[]
  createdAt          DateTime           @default(now())
}

model ProductListing {
  id             String   @id @default(uuid())
  sellerId       String
  seller         User     @relation(fields: [sellerId], references: [id])
  title          String
  category       String   // Vehicles | Electronics | Furniture
  priceKES       Int
  isNegotiable   Boolean  @default(true)
  condition      String   // Brand New | Foreign Used | Kenyan Used
  county         String
  estate         String
  photos         String[]
  description    String
  status         String   @default("Available") // Available | Sold
  createdAt      DateTime @default(now())
}

model MpesaTransaction {
  id              String   @id @default(uuid())
  checkoutReqId   String   @unique
  mpesaReceiptNo  String?  @unique
  phoneNumber     String   // +254...
  amountKES       Int
  purpose         String   // HOUSE_VIEWING_RESERVE | FUNDI_DEPOSIT
  status          String   // PENDING | SUCCESS | FAILED
  createdAt       DateTime @default(now())
}
`;

  const apiEndpointsText = `
// Express REST API Endpoints & Safaricom M-Pesa Daraja Integration

// 1. Unified Search Endpoint with Cascading Location Filters
GET /api/v1/listings/search?query=Bedsitter&county=Nairobi&constituency=Kasarani&estate=Mirema&category=housing

// 2. Geolocation Nearby Fundis Query (PostGIS ST_DWithin / Haversine)
GET /api/v1/fundis/nearby?lat=-1.2120&lng=36.8910&radiusKm=5&tradeSkill=Plumber

// 3. Housing Vacancies by Caretaker
GET /api/v1/housing/vacancies?houseType=2+Bedroom&maxRent=40000

// 4. Safaricom M-Pesa STK Push Express Initiation
POST /api/v1/payments/mpesa-stk-push
Payload:
{
  "phoneNumber": "254712345678",
  "amountKES": 500,
  "accountReference": "HOUSE-101",
  "transactionDesc": "Reserve Viewing for 2BR Kilimani"
}

// 5. M-Pesa Daraja Callback Webhook
POST /api/v1/payments/mpesa-callback
Handling Safaricom ResultCode 0 (Success) -> Mark transaction as COMPLETED & emit WebSocket notification
`;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-stone-900 text-stone-100 rounded-3xl max-w-4xl w-full p-6 shadow-2xl border border-emerald-800 my-8 space-y-5 animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-bold">
              <Database size={22} />
            </div>
            <div>
              <h2 className="font-black text-xl text-white">GLOBALLICA Architecture & Database Schema</h2>
              <p className="text-xs text-emerald-400 font-mono">PostgreSQL + PostGIS Geospatial + Node.js Express + M-Pesa Daraja</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-white bg-stone-800 hover:bg-stone-700 rounded-full transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex items-center gap-2 border-b border-stone-800 pb-3 text-xs font-bold overflow-x-auto">
          <button
            onClick={() => setActiveTab('folder')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'folder'
                ? 'bg-amber-400 text-stone-950 font-black'
                : 'bg-stone-800 text-stone-300 hover:bg-stone-700'
            }`}
          >
            <FolderTree size={14} />
            <span>Folder Structure</span>
          </button>

          <button
            onClick={() => setActiveTab('schema')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'schema'
                ? 'bg-amber-400 text-stone-950 font-black'
                : 'bg-stone-800 text-stone-300 hover:bg-stone-700'
            }`}
          >
            <Database size={14} />
            <span>Prisma DB Schema</span>
          </button>

          <button
            onClick={() => setActiveTab('api')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'api'
                ? 'bg-amber-400 text-stone-950 font-black'
                : 'bg-stone-800 text-stone-300 hover:bg-stone-700'
            }`}
          >
            <Server size={14} />
            <span>REST API & M-Pesa</span>
          </button>
        </div>

        {/* Tab Content Display */}
        <div className="relative bg-stone-950 rounded-2xl p-4 border border-stone-800 overflow-x-auto font-mono text-xs text-emerald-400 max-h-[420px] overflow-y-auto leading-relaxed">
          <button
            onClick={() => handleCopy(
              activeTab === 'folder' ? folderStructureText : activeTab === 'schema' ? prismaSchemaText : apiEndpointsText
            )}
            className="absolute top-3 right-3 bg-stone-800 hover:bg-stone-700 text-stone-200 px-2.5 py-1 rounded-lg text-[10px] font-sans flex items-center gap-1 cursor-pointer border border-stone-700"
          >
            {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
            <span>{copied ? 'Copied!' : 'Copy Snippet'}</span>
          </button>

          <pre>
            {activeTab === 'folder' && folderStructureText}
            {activeTab === 'schema' && prismaSchemaText}
            {activeTab === 'api' && apiEndpointsText}
          </pre>
        </div>

        {/* Technical Highlights */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="bg-stone-800/80 p-3 rounded-xl border border-stone-700">
            <span className="font-bold text-amber-400 block mb-0.5">🚀 Fast Mobile Network Sync</span>
            <span className="text-stone-300 text-[11px]">Optimized for Safaricom 3G/4G with lightweight JSON payloads and image compression.</span>
          </div>

          <div className="bg-stone-800/80 p-3 rounded-xl border border-stone-700">
            <span className="font-bold text-emerald-400 block mb-0.5">📍 PostGIS Geolocation</span>
            <span className="text-stone-300 text-[11px]">Uses spatial indexing to find fundis within 0.5km - 5km radius of user's estate.</span>
          </div>

          <div className="bg-stone-800/80 p-3 rounded-xl border border-stone-700">
            <span className="font-bold text-amber-300 block mb-0.5">💳 Safaricom M-Pesa STK</span>
            <span className="text-stone-300 text-[11px]">Instant STK push API for viewing reservations & direct fundi deposits.</span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold py-2.5 rounded-xl text-xs cursor-pointer shadow-md"
        >
          Close Architecture View
        </button>
      </div>
    </div>
  );
};
