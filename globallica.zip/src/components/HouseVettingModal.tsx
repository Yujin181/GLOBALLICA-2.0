import React, { useState } from 'react';
import { HousingListing, HouseVettingInfo } from '../types';
import { X, ShieldCheck, CheckCircle2, AlertTriangle, Search, Home, MapPin, Building, FileCheck, Compass, QrCode, Lock } from 'lucide-react';

interface HouseVettingModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetHouse?: HousingListing | null;
  allHouses?: HousingListing[];
  onHouseVetted?: (houseId: string, vettingInfo: HouseVettingInfo) => void;
}

export const HouseVettingModal: React.FC<HouseVettingModalProps> = ({
  isOpen,
  onClose,
  targetHouse,
  allHouses = [],
  onHouseVetted
}) => {
  const [selectedHouseId, setSelectedHouseId] = useState<string>(targetHouse?.id || allHouses[0]?.id || '');
  const [searchLrNo, setSearchLrNo] = useState<string>('LR NO. 209/18290');
  const [ownerNameInput, setOwnerNameInput] = useState<string>('Kiprop Real Estate Investments Ltd');
  const [isProcessing, setIsProcessing] = useState(false);
  const [processStep, setProcessStep] = useState<number>(0);
  const [vettedResult, setVettedResult] = useState<HouseVettingInfo | null>(null);

  if (!isOpen) return null;

  const currentHouse = targetHouse || allHouses.find(h => h.id === selectedHouseId) || targetHouse;

  const handleRunVerification = () => {
    setIsProcessing(true);
    setProcessStep(1);

    setTimeout(() => setProcessStep(2), 1000);
    setTimeout(() => setProcessStep(3), 2000);
    setTimeout(() => setProcessStep(4), 3000);

    setTimeout(() => {
      setIsProcessing(false);
      const newVetting: HouseVettingInfo = {
        isVetted: true,
        lrTitleDeedNo: searchLrNo || 'LR NO. NBI/BLOCK 88/' + Math.floor(1000 + Math.random() * 9000),
        landRegistryStatus: 'ARDHISASA_VERIFIED',
        registeredOwnerName: ownerNameInput || 'Mwangi & Sons Properties Ltd',
        geoGpsCoordinatesVerified: true,
        physicalInspectorName: 'Inspector J. Omondi (GLOBALLICA Physical Auditor)',
        verifiedAt: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
      };
      setVettedResult(newVetting);

      if (currentHouse && onHouseVetted) {
        onHouseVetted(currentHouse.id, newVetting);
      }
    }, 3800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95 duration-200 my-auto">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-emerald-950 p-5 text-white flex items-center justify-between border-b border-amber-400/30">
          <div className="flex items-center gap-3">
            <div className="bg-amber-400 text-emerald-950 p-2.5 rounded-2xl font-black shadow-md">
              <ShieldCheck size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-amber-400 text-emerald-950 text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wide">
                  ANTI-SCAM PROTECTION
                </span>
                <span className="text-emerald-300 text-xs font-semibold">Ministry of Lands & Ardhisasa</span>
              </div>
              <h2 className="text-lg sm:text-xl font-extrabold text-white">
                Digital House & Apartment Vetting
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-stone-400 hover:text-white p-2 rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        <div className="p-5 space-y-5 max-h-[80vh] overflow-y-auto">
          
          {/* Informational Banner */}
          <div className="bg-amber-50 border border-amber-200 p-3.5 rounded-2xl flex items-start gap-3">
            <AlertTriangle size={20} className="text-amber-700 shrink-0 mt-0.5" />
            <div className="text-xs text-amber-950 leading-relaxed">
              <span className="font-bold">Why Digital House Vetting? </span>
              In Kenya, scammers post photos of non-existent apartments or stolen house photos to trick house hunters into paying fake "deposit" or "viewing fee" money. GLOBALLICA cross-checks every house against the <strong>Ardhisasa Land Register (Title Deed LR No.)</strong> and verifies <strong>GPS geo-tagged physical coordinates</strong> on site.
            </div>
          </div>

          {/* House Selector if no target house fixed */}
          {!targetHouse && allHouses.length > 0 && (
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1.5">
                Select House / Apartment to Verify:
              </label>
              <select
                value={selectedHouseId}
                onChange={(e) => {
                  setSelectedHouseId(e.target.value);
                  setVettedResult(null);
                }}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2.5 text-xs font-bold text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
              >
                {allHouses.map(h => (
                  <option key={h.id} value={h.id}>
                    {h.title} - {h.estate}, {h.county} (KES {h.rentKES.toLocaleString()}/mo)
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Selected House Overview Card */}
          {currentHouse && (
            <div className="bg-stone-50 border border-stone-200 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <img
                src={currentHouse.photos?.[0] || 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=800&q=80'}
                alt={currentHouse.title}
                className="w-full sm:w-28 h-24 object-cover rounded-xl border border-stone-300 shrink-0"
                referrerPolicy="no-referrer"
              />
              <div className="flex-1 space-y-1">
                <div className="flex items-center gap-2">
                  <span className="bg-emerald-900 text-amber-300 font-extrabold text-[10px] px-2 py-0.5 rounded">
                    {currentHouse.houseType}
                  </span>
                  <span className="text-xs font-bold text-emerald-800">
                    KES {currentHouse.rentKES.toLocaleString()}/mo
                  </span>
                </div>
                <h3 className="font-extrabold text-stone-900 text-sm">{currentHouse.title}</h3>
                <p className="text-xs text-stone-600 flex items-center gap-1">
                  <MapPin size={13} className="text-amber-600" />
                  {currentHouse.estate}, {currentHouse.county} ({currentHouse.constituency})
                </p>
                <div className="text-[11px] text-stone-500 font-semibold pt-1">
                  Caretaker: <span className="text-stone-900 font-bold">{currentHouse.caretaker.name}</span> ({currentHouse.caretaker.phone})
                </div>
              </div>
            </div>
          )}

          {/* Existing or New Vetting Status Card */}
          {currentHouse?.vettingInfo?.isVetted || vettedResult ? (
            <div className="bg-emerald-950 text-amber-300 p-4 rounded-2xl border-2 border-amber-400 shadow-md space-y-3">
              <div className="flex items-center justify-between border-b border-amber-400/40 pb-2">
                <div className="flex items-center gap-2">
                  <ShieldCheck size={20} className="text-amber-300" />
                  <span className="font-black text-sm text-amber-300 uppercase">
                    🛡️ VETTED & AUTHENTIC PROPERTY CERTIFICATE
                  </span>
                </div>
                <span className="bg-amber-400 text-emerald-950 font-black text-[10px] px-2.5 py-1 rounded-lg">
                  PASSED ARDHISASA
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="bg-emerald-900/80 p-2.5 rounded-xl border border-emerald-700">
                  <span className="text-[10px] text-emerald-300 font-semibold block">Title Deed / Land Registry No:</span>
                  <span className="font-mono font-bold text-amber-300 text-xs">
                    {(currentHouse?.vettingInfo || vettedResult)?.lrTitleDeedNo}
                  </span>
                </div>

                <div className="bg-emerald-900/80 p-2.5 rounded-xl border border-emerald-700">
                  <span className="text-[10px] text-emerald-300 font-semibold block">Registered Owner / Title Holder:</span>
                  <span className="font-bold text-white text-xs">
                    {(currentHouse?.vettingInfo || vettedResult)?.registeredOwnerName}
                  </span>
                </div>

                <div className="bg-emerald-900/80 p-2.5 rounded-xl border border-emerald-700">
                  <span className="text-[10px] text-emerald-300 font-semibold block">Ardhisasa Land Search:</span>
                  <span className="font-bold text-emerald-200 flex items-center gap-1">
                    <CheckCircle2 size={13} className="text-emerald-400" /> Ardhisasa Digital Registry Clear
                  </span>
                </div>

                <div className="bg-emerald-900/80 p-2.5 rounded-xl border border-emerald-700">
                  <span className="text-[10px] text-emerald-300 font-semibold block">GPS Physical Location Audit:</span>
                  <span className="font-bold text-emerald-200 flex items-center gap-1">
                    <Compass size={13} className="text-amber-300" /> Geo-Coordinates & Photos Confirmed
                  </span>
                </div>
              </div>

              <p className="text-[10px] text-emerald-200/90 italic pt-1 text-center">
                Verified on {(currentHouse?.vettingInfo || vettedResult)?.verifiedAt} • GLOBALLICA Anti-Scam Guarantee Active
              </p>
            </div>
          ) : (
            /* Input & Action Form */
            <div className="space-y-4 border-t border-stone-200 pt-4">
              <h4 className="font-extrabold text-stone-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                <FileCheck size={16} className="text-emerald-700" />
                Run Live Digital Title Deed & Ardhisasa Audit
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-stone-700 mb-1">
                    LR Title Deed No. / Block Parcel No:
                  </label>
                  <input
                    type="text"
                    value={searchLrNo}
                    onChange={(e) => setSearchLrNo(e.target.value)}
                    placeholder="e.g. LR NO. 209/18290 or NBI/BLOCK 88/192"
                    className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-stone-700 mb-1">
                    Registered Landlord / Company Name:
                  </label>
                  <input
                    type="text"
                    value={ownerNameInput}
                    onChange={(e) => setOwnerNameInput(e.target.value)}
                    placeholder="e.g. Mwangi Real Estate Investments Ltd"
                    className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs font-bold text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                  />
                </div>
              </div>

              {/* Step Process Display */}
              {isProcessing && (
                <div className="bg-emerald-950 text-white p-4 rounded-2xl border border-emerald-800 space-y-2 text-xs font-mono">
                  <div className="flex items-center gap-2 text-amber-300 font-bold">
                    <div className="w-2.5 h-2.5 bg-amber-400 rounded-full animate-ping" />
                    <span>Executing GLOBALLICA Digital Property Audit...</span>
                  </div>

                  <div className={`flex items-center gap-2 transition-opacity ${processStep >= 1 ? 'opacity-100 text-emerald-300' : 'opacity-40 text-stone-400'}`}>
                    <span>{processStep >= 1 ? '✅' : '⏳'} Step 1: Connecting to Ministry of Lands (Ardhisasa API)...</span>
                  </div>

                  <div className={`flex items-center gap-2 transition-opacity ${processStep >= 2 ? 'opacity-100 text-emerald-300' : 'opacity-40 text-stone-400'}`}>
                    <span>{processStep >= 2 ? '✅' : '⏳'} Step 2: Validating Title Deed {searchLrNo}...</span>
                  </div>

                  <div className={`flex items-center gap-2 transition-opacity ${processStep >= 3 ? 'opacity-100 text-emerald-300' : 'opacity-40 text-stone-400'}`}>
                    <span>{processStep >= 3 ? '✅' : '⏳'} Step 3: Verifying GPS Geo-tagged photos against site location...</span>
                  </div>

                  <div className={`flex items-center gap-2 transition-opacity ${processStep >= 4 ? 'opacity-100 text-amber-300 font-bold' : 'opacity-40 text-stone-400'}`}>
                    <span>{processStep >= 4 ? '✅' : '⏳'} Step 4: Generating GLOBALLICA Property Authenticity Certificate!</span>
                  </div>
                </div>
              )}

              {!isProcessing && (
                <button
                  type="button"
                  onClick={handleRunVerification}
                  disabled={!currentHouse}
                  className="w-full bg-emerald-800 hover:bg-emerald-700 text-amber-300 font-black py-3 rounded-2xl text-xs transition-all shadow-lg cursor-pointer flex items-center justify-center gap-2 border border-amber-400/50"
                >
                  <ShieldCheck size={18} className="text-amber-300" />
                  <span>Execute Ardhisasa Title Deed & GPS Vetting Check</span>
                </button>
              )}
            </div>
          )}

          {/* Footer Close */}
          <div className="pt-3 border-t border-stone-100 flex justify-end">
            <button
              onClick={onClose}
              className="bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold px-4 py-2 rounded-xl text-xs transition-colors cursor-pointer"
            >
              Close Vetting Portal
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
