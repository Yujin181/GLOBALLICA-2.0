import React from 'react';
import { ShieldAlert, Lock, ArrowRight, Globe, Key, UserCheck, AlertTriangle } from 'lucide-react';
import { PortalConfig, PortalId } from '../utils/portalRouter';
import { RBACRole } from '../types';

interface PortalAccessDeniedModalProps {
  isOpen: boolean;
  portal: PortalConfig;
  currentRole: RBACRole;
  reason?: string;
  onOpenLogin: () => void;
  onReturnToPublic: () => void;
}

export const PortalAccessDeniedModal: React.FC<PortalAccessDeniedModalProps> = ({
  isOpen,
  portal,
  currentRole,
  reason,
  onOpenLogin,
  onReturnToPublic
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fadeIn">
      <div className="bg-emerald-950 border border-rose-500/80 rounded-3xl max-w-lg w-full p-6 text-white shadow-2xl relative overflow-hidden">
        
        {/* Glow Header */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-rose-500 via-amber-400 to-rose-500" />

        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-rose-900/60 border border-rose-500/60 flex items-center justify-center text-rose-400 shrink-0">
            <ShieldAlert size={26} />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/30">
              SUBDOMAIN PORTAL SECURITY ENFORCEMENT
            </span>
            <h2 className="text-xl font-extrabold text-white mt-1">
              Restricted Portal Access
            </h2>
          </div>
        </div>

        {/* Portal Host Details */}
        <div className="bg-rose-950/60 border border-rose-800/60 rounded-2xl p-4 my-4 space-y-3 text-xs">
          <div className="flex items-center justify-between text-rose-200 border-b border-rose-900/80 pb-2">
            <span className="text-rose-300 font-medium">Target Host Subdomain:</span>
            <span className="font-mono font-bold text-amber-300 bg-black/40 px-2 py-0.5 rounded border border-amber-400/30">
              https://{portal.canonicalHost}
            </span>
          </div>

          <div className="flex items-center justify-between text-rose-200 border-b border-rose-900/80 pb-2">
            <span className="text-rose-300 font-medium">Target Portal Name:</span>
            <span className="font-bold text-white">{portal.name}</span>
          </div>

          <div className="flex items-center justify-between text-rose-200 border-b border-rose-900/80 pb-2">
            <span className="text-rose-300 font-medium">Your Active Role Session:</span>
            <span className="font-bold uppercase text-rose-400 bg-rose-900/80 px-2 py-0.5 rounded border border-rose-700/50">
              {currentRole}
            </span>
          </div>

          <div className="flex items-center justify-between text-rose-200">
            <span className="text-rose-300 font-medium">Required Role Permissions:</span>
            <span className="font-bold uppercase text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-700/50">
              {portal.requiredRoles.join(' OR ')}
            </span>
          </div>
        </div>

        {/* Reason Explanation */}
        <div className="bg-black/40 border border-white/10 rounded-xl p-3 text-xs text-rose-200 space-y-1">
          <div className="flex items-center gap-1.5 font-bold text-amber-300">
            <AlertTriangle size={14} />
            <span>Routing Enforcement Reason:</span>
          </div>
          <p className="leading-relaxed">
            {reason || portal.loginMessage}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="mt-6 flex flex-col sm:flex-row gap-3">
          <button
            onClick={onOpenLogin}
            className="flex-1 bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black py-3 rounded-2xl text-xs flex items-center justify-center gap-2 shadow-xl transition-transform active:scale-98 cursor-pointer border border-amber-300"
          >
            <Key size={16} />
            <span>Redirect to Portal Login</span>
            <ArrowRight size={14} />
          </button>

          <button
            onClick={onReturnToPublic}
            className="bg-emerald-900 hover:bg-emerald-800 text-emerald-100 font-bold py-3 px-4 rounded-2xl text-xs flex items-center justify-center gap-1.5 border border-emerald-700 transition-colors"
          >
            <Globe size={15} />
            <span>Exit to Main Market</span>
          </button>
        </div>

      </div>
    </div>
  );
};
