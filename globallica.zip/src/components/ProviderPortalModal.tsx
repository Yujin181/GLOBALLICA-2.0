import React, { useState } from 'react';
import { X, LogIn, Upload, Camera, Video, Film, CheckCircle, Trash2, Eye, ShieldCheck, UserCheck, PhoneCall, PlusCircle, Sparkles, AlertCircle } from 'lucide-react';
import { ServiceProvider, JobShowcase } from '../types';

interface ProviderPortalModalProps {
  isOpen: boolean;
  onClose: () => void;
  fundisList: ServiceProvider[];
  onUpdateFundiPortfolio: (fundiId: string, updatedPortfolio: JobShowcase[]) => void;
  onSelectFundiForPreview?: (fundi: ServiceProvider) => void;
}

export const ProviderPortalModal: React.FC<ProviderPortalModalProps> = ({
  isOpen,
  onClose,
  fundisList,
  onUpdateFundiPortfolio,
  onSelectFundiForPreview
}) => {
  if (!isOpen) return null;

  // Sign In state
  const [signedInFundiId, setSignedInFundiId] = useState<string | null>(fundisList[0]?.id || null);
  const [phoneNumber, setPhoneNumber] = useState<string>('+254711223344');
  const [otpCode, setOtpCode] = useState<string>('1234');
  const [isOtpSent, setIsOtpSent] = useState<boolean>(true);
  const [authStep, setAuthStep] = useState<'select' | 'authenticated'>('authenticated');

  // New Showcase Item form state
  const [jobTitle, setJobTitle] = useState<string>('');
  const [jobDescription, setJobDescription] = useState<string>('');
  const [jobLocation, setJobLocation] = useState<string>('');
  const [completedDate, setCompletedDate] = useState<string>('July 2026');
  
  // Media files / URLs state
  const [photosList, setPhotosList] = useState<string[]>([]);
  const [videosList, setVideosList] = useState<string[]>([]);
  const [photoInputUrl, setPhotoInputUrl] = useState<string>('');
  const [videoInputUrl, setVideoInputUrl] = useState<string>('');
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [uploadSuccessMsg, setUploadSuccessMsg] = useState<string>('');

  const currentFundi = fundisList.find(f => f.id === signedInFundiId) || fundisList[0];

  // Handle Image File Upload (Multiple files supported)
  const handleImageFilesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const fileArray = Array.from(files);
      fileArray.forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          if (reader.result) {
            setPhotosList(prev => [...prev, reader.result as string]);
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  // Add custom photo URL
  const handleAddPhotoUrl = () => {
    if (photoInputUrl.trim()) {
      setPhotosList(prev => [...prev, photoInputUrl.trim()]);
      setPhotoInputUrl('');
    }
  };

  // Handle Video File Upload (Multiple files supported)
  const handleVideoFilesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const fileArray = Array.from(files);
      fileArray.forEach(file => {
        const videoBlobUrl = URL.createObjectURL(file);
        setVideosList(prev => [...prev, videoBlobUrl]);
      });
    }
  };

  // Add custom video URL
  const handleAddVideoUrl = () => {
    if (videoInputUrl.trim()) {
      setVideosList(prev => [...prev, videoInputUrl.trim()]);
      setVideoInputUrl('');
    }
  };

  const handleRemovePhoto = (index: number) => {
    setPhotosList(prev => prev.filter((_, i) => i !== index));
  };

  const handleRemoveVideo = (index: number) => {
    setVideosList(prev => prev.filter((_, i) => i !== index));
  };

  // Submit new showcase item
  const handleAddShowcaseItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentFundi || !jobTitle) return;

    setIsUploading(true);

    const fallbackPhoto = 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=600&q=80';
    const finalPhotos = photosList.length > 0 ? photosList : [fallbackPhoto];
    const finalVideos = videosList;

    const newItem: JobShowcase = {
      id: `showcase-${Date.now()}`,
      title: jobTitle,
      description: jobDescription || 'Professional work verified on-site by caretaker/client.',
      photoUrl: finalPhotos[0],
      videoUrl: finalVideos[0] || undefined,
      photos: finalPhotos,
      videos: finalVideos,
      completedDate: completedDate || 'Recently',
      location: jobLocation || currentFundi.operationalEstate
    };

    const currentPortfolio = currentFundi.portfolioShowcase || [];
    const updatedPortfolio = [newItem, ...currentPortfolio];

    setTimeout(() => {
      onUpdateFundiPortfolio(currentFundi.id, updatedPortfolio);
      setIsUploading(false);
      setUploadSuccessMsg(`✨ Showcase media (${finalPhotos.length} photos, ${finalVideos.length} videos) attached to profile!`);
      
      // Reset form
      setJobTitle('');
      setJobDescription('');
      setJobLocation('');
      setPhotosList([]);
      setVideosList([]);
      setPhotoInputUrl('');
      setVideoInputUrl('');

      setTimeout(() => setUploadSuccessMsg(''), 4000);
    }, 600);
  };

  // Delete item from portfolio
  const handleDeleteShowcaseItem = (itemId: string) => {
    if (!currentFundi) return;
    const updated = (currentFundi.portfolioShowcase || []).filter(item => item.id !== itemId);
    onUpdateFundiPortfolio(currentFundi.id, updated);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-3xl w-full p-6 shadow-2xl border border-stone-200 my-6 space-y-6 animate-in fade-in zoom-in-95">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-stone-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-900 text-amber-400 flex items-center justify-center font-black shadow-md">
              <Film size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-black text-xl text-stone-900">Service Provider Sign In & Media Showcase</h2>
                <span className="text-[10px] bg-amber-400 text-stone-950 font-black px-2 py-0.5 rounded-full uppercase">
                  Fundi Dashboard
                </span>
              </div>
              <p className="text-xs text-stone-500">Upload photos and video clips of your completed work to get hired faster</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-full transition-colors cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Auth Step: Select Account / Switch Provider */}
        <div className="bg-stone-50 border border-stone-200 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <label className="text-xs font-bold text-stone-700 block">Signed In Provider Profile:</label>
            <div className="flex items-center gap-2">
              <select
                value={signedInFundiId || ''}
                onChange={(e) => setSignedInFundiId(e.target.value)}
                className="bg-white border border-stone-300 font-bold text-stone-900 text-xs rounded-xl p-2 focus:ring-2 focus:ring-emerald-600 focus:outline-none cursor-pointer"
              >
                {fundisList.map((fundi) => (
                  <option key={fundi.id} value={fundi.id}>
                    {fundi.name} ({fundi.tradeSkill} • {fundi.operationalEstate})
                  </option>
                ))}
              </select>
              {currentFundi?.isVerified && (
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-extrabold px-2 py-1 rounded-lg flex items-center gap-1 border border-emerald-300">
                  <ShieldCheck size={13} /> EPRA Verified
                </span>
              )}
            </div>
          </div>

          {currentFundi && onSelectFundiForPreview && (
            <button
              onClick={() => {
                onClose();
                onSelectFundiForPreview(currentFundi);
              }}
              className="bg-stone-900 hover:bg-stone-800 text-amber-400 font-bold text-xs px-3.5 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer shadow transition-all shrink-0"
            >
              <Eye size={14} />
              <span>Preview My Live Card & Videos</span>
            </button>
          )}
        </div>

        {/* Upload Success Alert */}
        {uploadSuccessMsg && (
          <div className="bg-emerald-50 border border-emerald-300 p-3.5 rounded-2xl text-emerald-900 text-xs font-bold flex items-center gap-2.5 animate-in fade-in">
            <CheckCircle size={18} className="text-emerald-600 shrink-0" />
            <span>{uploadSuccessMsg}</span>
          </div>
        )}

        {/* Main Content Grid: Add Showcase Form + Live Showcase Items */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Form: Upload Images & Videos */}
          <div className="lg:col-span-6 space-y-4 bg-stone-50/70 border border-stone-200 p-5 rounded-3xl">
            <div className="flex items-center gap-2 border-b border-stone-200 pb-3">
              <Upload size={18} className="text-emerald-700" />
              <h3 className="font-extrabold text-stone-900 text-sm">Upload New Showcase Media</h3>
            </div>

            <form onSubmit={handleAddShowcaseItem} className="space-y-3.5 text-xs">
              <div>
                <label htmlFor="provider-job-title" className="block text-stone-700 font-bold mb-1">Job Title / Work Done *</label>
                <input
                  id="provider-job-title"
                  name="jobTitle"
                  type="text"
                  required
                  value={jobTitle}
                  onChange={(e) => setJobTitle(e.target.value)}
                  placeholder="e.g. 5kW Solar Hybrid Inverter Installation & Meter Wiring"
                  className="w-full bg-white border border-stone-300 rounded-xl p-2.5 text-stone-900 font-medium focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label htmlFor="provider-job-location" className="block text-stone-700 font-bold mb-1">Location / Estate</label>
                  <input
                    id="provider-job-location"
                    name="jobLocation"
                    type="text"
                    value={jobLocation}
                    onChange={(e) => setJobLocation(e.target.value)}
                    placeholder={currentFundi?.operationalEstate || 'e.g. Mirema Drive'}
                    className="w-full bg-white border border-stone-300 rounded-xl p-2.5 text-stone-900 font-medium focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label htmlFor="provider-completed-date" className="block text-stone-700 font-bold mb-1">Date Completed</label>
                  <input
                    id="provider-completed-date"
                    name="completedDate"
                    type="text"
                    value={completedDate}
                    onChange={(e) => setCompletedDate(e.target.value)}
                    placeholder="July 2026"
                    className="w-full bg-white border border-stone-300 rounded-xl p-2.5 text-stone-900 font-medium focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="provider-job-desc" className="block text-stone-700 font-bold mb-1">Brief Description of Work Done</label>
                <textarea
                  id="provider-job-desc"
                  name="jobDescription"
                  rows={2}
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                  placeholder="Explain how you fixed the issue, tools used, and guarantee offered to customer..."
                  className="w-full bg-white border border-stone-300 rounded-xl p-2.5 text-stone-900 font-medium focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              {/* IMAGE UPLOAD SECTION */}
              <div className="space-y-2 pt-1">
                <label className="block font-bold text-stone-800 flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-emerald-900">
                    <Camera size={15} /> Job Photos ({photosList.length} Attached)
                  </span>
                  <span className="text-[10px] text-stone-500">Select Multiple Files / PNG, JPG, WebP</span>
                </label>

                {/* File input for images */}
                <div className="border-2 border-dashed border-emerald-300 hover:border-emerald-500 bg-emerald-50/50 rounded-2xl p-3 text-center cursor-pointer transition-colors">
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleImageFilesChange}
                    className="hidden"
                    id="photo-upload-input"
                  />
                  <label htmlFor="photo-upload-input" className="cursor-pointer block space-y-1">
                    <Camera size={22} className="mx-auto text-emerald-700" />
                    <span className="text-xs font-bold text-emerald-950 block">
                      Click to Browse & Upload Photo Files
                    </span>
                    <span className="text-[10px] text-stone-500 block">Select one or multiple photos from phone or computer</span>
                  </label>
                </div>

                {/* Paste URL for photo */}
                <div className="flex gap-1.5">
                  <input
                    id="provider-photo-url-input"
                    name="photoInputUrl"
                    aria-label="Photo image URL"
                    type="url"
                    value={photoInputUrl}
                    onChange={(e) => setPhotoInputUrl(e.target.value)}
                    placeholder="Or paste image URL (https://...)"
                    className="flex-1 bg-white border border-stone-200 rounded-xl p-2 text-[11px] text-stone-700 font-mono"
                  />
                  <button
                    type="button"
                    onClick={handleAddPhotoUrl}
                    className="bg-emerald-700 hover:bg-emerald-800 text-amber-300 font-bold px-3 py-1.5 rounded-xl text-[11px] shrink-0"
                  >
                    + Add Photo
                  </button>
                </div>

                {/* Preview Chips / Thumbnails for Attached Photos */}
                {photosList.length > 0 && (
                  <div className="flex flex-wrap gap-2 pt-1">
                    {photosList.map((photo, idx) => (
                      <div key={idx} className="relative w-16 h-16 bg-stone-200 rounded-xl overflow-hidden border border-emerald-400 group">
                        <img src={photo} alt={`Attached ${idx}`} className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => handleRemovePhoto(idx)}
                          className="absolute top-0.5 right-0.5 bg-red-600 text-white p-0.5 rounded-full hover:scale-110 transition-transform cursor-pointer"
                          title="Remove image"
                        >
                          <X size={10} />
                        </button>
                        <span className="absolute bottom-0.5 left-0.5 bg-black/70 text-white text-[8px] font-bold px-1 rounded">
                          #{idx + 1}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* VIDEO UPLOAD SECTION */}
              <div className="space-y-2 pt-2">
                <label className="block font-bold text-stone-800 flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-red-700">
                    <Video size={15} /> Job Video Clips ({videosList.length} Attached)
                  </span>
                  <span className="text-[10px] text-stone-500">Select Multiple Files / MP4, WebM, MOV</span>
                </label>

                {/* File input for videos */}
                <div className="border-2 border-dashed border-red-300 hover:border-red-500 bg-red-50/50 rounded-2xl p-3 text-center cursor-pointer transition-colors">
                  <input
                    type="file"
                    accept="video/*"
                    multiple
                    onChange={handleVideoFilesChange}
                    className="hidden"
                    id="video-upload-input"
                  />
                  <label htmlFor="video-upload-input" className="cursor-pointer block space-y-1">
                    <Film size={22} className="mx-auto text-red-600" />
                    <span className="text-xs font-bold text-red-950 block">
                      Click to Browse & Upload Video Files
                    </span>
                    <span className="text-[10px] text-stone-500 block">Select one or multiple video clips of your completed work</span>
                  </label>
                </div>

                {/* Sample Preset Video Clip Quick-Picker */}
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-stone-500 block">Quick Demo Preset Video Clips:</span>
                  <div className="flex flex-wrap gap-1">
                    <button
                      type="button"
                      onClick={() => {
                        setVideosList(prev => [...prev, 'https://assets.mixkit.co/videos/preview/mixkit-plumbing-repairing-a-pipe-under-the-sink-41525-large.mp4']);
                      }}
                      className="text-[10px] bg-stone-200 hover:bg-red-100 text-stone-800 font-bold px-2 py-0.5 rounded cursor-pointer flex items-center gap-1"
                    >
                      <Film size={10} className="text-red-600" /> Plumbing Clip
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setVideosList(prev => [...prev, 'https://assets.mixkit.co/videos/preview/mixkit-hands-of-an-electrician-fixing-wires-41526-large.mp4']);
                      }}
                      className="text-[10px] bg-stone-200 hover:bg-red-100 text-stone-800 font-bold px-2 py-0.5 rounded cursor-pointer flex items-center gap-1"
                    >
                      <Film size={10} className="text-red-600" /> Electrical Clip
                    </button>
                  </div>
                </div>

                {/* Paste URL for video */}
                <div className="flex gap-1.5">
                  <input
                    type="url"
                    value={videoInputUrl}
                    onChange={(e) => setVideoInputUrl(e.target.value)}
                    placeholder="Or paste video clip URL (https://...mp4)"
                    className="flex-1 bg-white border border-stone-200 rounded-xl p-2 text-[11px] text-stone-700 font-mono"
                  />
                  <button
                    type="button"
                    onClick={handleAddVideoUrl}
                    className="bg-red-700 hover:bg-red-800 text-white font-bold px-3 py-1.5 rounded-xl text-[11px] shrink-0"
                  >
                    + Add Video
                  </button>
                </div>

                {/* Preview List for Attached Videos */}
                {videosList.length > 0 && (
                  <div className="space-y-1.5 pt-1">
                    {videosList.map((video, idx) => (
                      <div key={idx} className="flex items-center justify-between bg-stone-900 text-white p-2 rounded-xl border border-stone-800 text-xs">
                        <div className="flex items-center gap-2 overflow-hidden">
                          <Film size={14} className="text-red-500 shrink-0" />
                          <span className="font-mono text-[10px] text-amber-300 truncate">Video Clip #{idx + 1}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveVideo(idx)}
                          className="text-stone-400 hover:text-red-400 p-1 shrink-0 cursor-pointer"
                        >
                          <X size={12} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={isUploading}
                className="w-full bg-emerald-800 hover:bg-emerald-900 text-amber-300 font-black py-3 rounded-2xl shadow-lg flex items-center justify-center gap-2 cursor-pointer transition-all text-xs"
              >
                {isUploading ? (
                  <span>Processing Media Upload...</span>
                ) : (
                  <>
                    <PlusCircle size={16} />
                    <span>Attach Photos & Videos to Profile</span>
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Right Column: Existing Portfolio Showcase Items */}
          <div className="lg:col-span-6 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h3 className="font-extrabold text-stone-900 text-sm flex items-center gap-1.5">
                <Camera size={16} className="text-emerald-700" />
                <span>My Showcase Items ({currentFundi?.portfolioShowcase?.length || 0})</span>
              </h3>
              <span className="text-[10px] text-stone-500 font-semibold">Live in App</span>
            </div>

            {(!currentFundi?.portfolioShowcase || currentFundi.portfolioShowcase.length === 0) ? (
              <div className="bg-stone-50 border border-stone-200 rounded-3xl p-8 text-center space-y-2">
                <Film size={32} className="mx-auto text-stone-300" />
                <h4 className="font-bold text-stone-800 text-sm">No Showcase Items Attached Yet</h4>
                <p className="text-xs text-stone-500">
                  Upload photos and videos on the left form so customers in {currentFundi?.operationalEstate} can view your craftsmanship!
                </p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1">
                {currentFundi.portfolioShowcase.map((item) => {
                  const itemPhotos = item.photos && item.photos.length > 0 ? item.photos : [item.photoUrl];
                  const itemVideos = item.videos && item.videos.length > 0 ? item.videos : (item.videoUrl ? [item.videoUrl] : []);

                  return (
                    <div key={item.id} className="bg-stone-50 border border-stone-200 rounded-2xl p-3 shadow-sm flex flex-col space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h4 className="font-bold text-stone-900 text-xs">{item.title}</h4>
                          <span className="text-[10px] text-stone-500 block">
                            📍 {item.location} • {item.completedDate}
                          </span>
                        </div>
                        <button
                          onClick={() => handleDeleteShowcaseItem(item.id)}
                          className="text-red-500 hover:text-red-700 p-1 bg-red-50 rounded-lg hover:bg-red-100 transition-colors cursor-pointer shrink-0"
                          title="Remove showcase item"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>

                      <p className="text-[11px] text-stone-600 line-clamp-2">{item.description}</p>

                      {/* Display Photos Array */}
                      {itemPhotos.length > 0 && (
                        <div className="space-y-1 pt-1">
                          <span className="text-[10px] font-bold text-emerald-900 flex items-center gap-1">
                            <Camera size={12} /> {itemPhotos.length} Photo(s) Attached
                          </span>
                          <div className="grid grid-cols-3 gap-1.5">
                            {itemPhotos.map((pUrl, pIdx) => (
                              <div key={pIdx} className="relative h-20 bg-stone-200 rounded-xl overflow-hidden border border-stone-300">
                                <img
                                  src={pUrl}
                                  alt={`${item.title} ${pIdx}`}
                                  className="w-full h-full object-cover"
                                  referrerPolicy="no-referrer"
                                />
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Display Videos Array */}
                      {itemVideos.length > 0 && (
                        <div className="space-y-1 pt-1">
                          <span className="text-[10px] font-bold text-red-700 flex items-center gap-1">
                            <Film size={12} /> {itemVideos.length} Video Clip(s) Attached
                          </span>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {itemVideos.map((vUrl, vIdx) => (
                              <div key={vIdx} className="relative h-28 bg-black rounded-xl overflow-hidden border border-stone-800 flex items-center justify-center">
                                <video
                                  src={vUrl}
                                  controls
                                  className="w-full h-full object-cover"
                                />
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>

        {/* Footer info */}
        <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-500 font-semibold">
          <span className="flex items-center gap-1">
            <ShieldCheck size={14} className="text-emerald-600" /> All photos & videos are displayed on your local listing card
          </span>
          <button
            onClick={onClose}
            className="bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold px-4 py-2 rounded-xl cursor-pointer"
          >
            Close Portal
          </button>
        </div>

      </div>
    </div>
  );
};
