import React, { useState } from 'react';
import { X, Calendar, RefreshCw, ShieldCheck, CheckCircle2, Clock, MapPin, Phone, CreditCard, Sparkles, AlertCircle, Play, Pause, Trash2, ArrowRight, UserCheck, Camera, ShieldAlert } from 'lucide-react';
import { ServiceProvider, DomesticSubscription, EscrowJobPayment } from '../types';

interface DomesticSubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetProvider?: ServiceProvider | null;
  allProviders?: ServiceProvider[];
  subscriptions: DomesticSubscription[];
  onAddSubscription: (sub: DomesticSubscription) => void;
  onUpdateSubscription: (sub: DomesticSubscription) => void;
  onOpenLiveSelfie?: (provider?: ServiceProvider) => void;
}

export const DomesticSubscriptionModal: React.FC<DomesticSubscriptionModalProps> = ({
  isOpen,
  onClose,
  targetProvider,
  allProviders = [],
  subscriptions = [],
  onAddSubscription,
  onUpdateSubscription,
  onOpenLiveSelfie
}) => {
  const [activeTab, setActiveTab] = useState<'CREATE' | 'MY_SUBSCRIPTIONS' | 'HISTORY'>(
    targetProvider ? 'CREATE' : subscriptions.length > 0 ? 'MY_SUBSCRIPTIONS' : 'CREATE'
  );

  const [selectedProviderId, setSelectedProviderId] = useState<string>(
    targetProvider?.id || allProviders.find(p => p.tradeSkill.includes('Mama Fua'))?.id || allProviders[0]?.id || ''
  );

  const currentProvider = targetProvider || allProviders.find(p => p.id === selectedProviderId) || allProviders[0];

  // Form State
  const [clientName, setClientName] = useState('Sarah Mwangi');
  const [clientPhone, setClientPhone] = useState('+254712345678');
  const [clientEstate, setClientEstate] = useState(currentProvider?.operationalEstate || 'Kilimani, Nairobi');
  const [frequency, setFrequency] = useState<'WEEKLY' | 'BI_WEEKLY' | 'MONTHLY' | 'CUSTOM_DAYS'>('WEEKLY');
  const [selectedDays, setSelectedDays] = useState<string[]>(['Tuesday', 'Saturday']);
  const [preferredTimeSlot, setPreferredTimeSlot] = useState('08:00 AM - 01:00 PM');
  const [ratePerVisitKES, setRatePerVisitKES] = useState<number>(currentProvider?.rateKES || 1500);
  const [autoEscrowDeduct, setAutoEscrowDeduct] = useState(true);
  const [mpesaPhone, setMpesaPhone] = useState('254712345678');
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Auto-deduction demo trigger state
  const [isDeductingId, setIsDeductingId] = useState<string | null>(null);
  const [deductionSuccess, setDeductionSuccess] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleToggleDay = (day: string) => {
    if (selectedDays.includes(day)) {
      if (selectedDays.length > 1) {
        setSelectedDays(selectedDays.filter(d => d !== day));
      }
    } else {
      setSelectedDays([...selectedDays, day]);
    }
  };

  const calculateMonthlyEstimate = () => {
    if (frequency === 'WEEKLY') return ratePerVisitKES * selectedDays.length * 4;
    if (frequency === 'BI_WEEKLY') return ratePerVisitKES * selectedDays.length * 2;
    if (frequency === 'MONTHLY') return ratePerVisitKES * 1;
    return ratePerVisitKES * selectedDays.length * 4;
  };

  const handleCreateSubscription = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentProvider) return;

    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);

      const nextDate = new Date();
      nextDate.setDate(nextDate.getDate() + 3);
      const formattedNextDate = nextDate.toISOString().split('T')[0];

      const newSub: DomesticSubscription = {
        id: `sub-${Date.now()}`,
        providerId: currentProvider.id,
        providerName: currentProvider.name,
        providerSkill: currentProvider.tradeSkill,
        providerAvatar: currentProvider.avatar,
        clientName,
        clientPhone,
        clientEstate,
        frequency,
        preferredDays: selectedDays,
        preferredTimeSlot,
        ratePerVisitKES,
        autoEscrowDeduct,
        nextScheduledDate: formattedNextDate,
        status: 'ACTIVE',
        createdDate: new Date().toISOString().split('T')[0],
        mpesaAutoBillNumber: mpesaPhone,
        completedVisitsCount: 0,
        lastEscrowDeductionAt: autoEscrowDeduct ? `Auto-Deducted Today ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}` : undefined
      };

      onAddSubscription(newSub);
      setSuccessMessage(`✅ Successfully subscribed to ${currentProvider.name}! Auto-escrow booking schedule activated.`);
      
      setTimeout(() => {
        setSuccessMessage(null);
        setActiveTab('MY_SUBSCRIPTIONS');
      }, 2000);
    }, 1200);
  };

  const handleTogglePause = (sub: DomesticSubscription) => {
    const updated: DomesticSubscription = {
      ...sub,
      status: sub.status === 'ACTIVE' ? 'PAUSED' : 'ACTIVE'
    };
    onUpdateSubscription(updated);
  };

  const handleTriggerManualDeduction = (sub: DomesticSubscription) => {
    setIsDeductingId(sub.id);
    setTimeout(() => {
      setIsDeductingId(null);
      const updated: DomesticSubscription = {
        ...sub,
        completedVisitsCount: sub.completedVisitsCount + 1,
        lastEscrowDeductionAt: `M-PESA STK Auto-Escrow (Receipt KES${sub.ratePerVisitKES} - ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})`
      };
      onUpdateSubscription(updated);
      setDeductionSuccess(`💰 Auto-Escrow KES ${sub.ratePerVisitKES.toLocaleString()} deposited for ${sub.providerName}! M-PESA STK Push confirmed.`);
      setTimeout(() => setDeductionSuccess(null), 3500);
    }, 1500);
  };

  const weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-3xl w-full overflow-hidden shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95 duration-200 my-auto">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-emerald-950 p-5 text-white flex items-center justify-between border-b border-amber-400/30">
          <div className="flex items-center gap-3">
            <div className="bg-amber-400 text-emerald-950 p-2.5 rounded-2xl font-black shadow-md shrink-0">
              <RefreshCw size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-amber-400 text-emerald-950 text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wide">
                  AUTOMATED DOMESTIC HELP
                </span>
                <span className="text-emerald-300 text-xs font-semibold">Urban Kenya Household Subscriptions</span>
              </div>
              <h2 className="text-lg sm:text-xl font-extrabold text-white">
                Part-Time Help Auto-Booking & Escrow
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-stone-400 hover:text-white p-2 rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="bg-stone-900 px-5 pt-3 border-b border-stone-800 flex items-center justify-between overflow-x-auto gap-2">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('CREATE')}
              className={`px-4 py-2.5 rounded-t-xl text-xs font-extrabold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'CREATE'
                  ? 'bg-amber-400 text-emerald-950 shadow-md'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/60'
              }`}
            >
              <Calendar size={14} />
              <span>+ New Subscription</span>
            </button>

            <button
              onClick={() => setActiveTab('MY_SUBSCRIPTIONS')}
              className={`px-4 py-2.5 rounded-t-xl text-xs font-extrabold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'MY_SUBSCRIPTIONS'
                  ? 'bg-amber-400 text-emerald-950 shadow-md'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/60'
              }`}
            >
              <ShieldCheck size={14} />
              <span>Active Subscriptions ({subscriptions.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('HISTORY')}
              className={`px-4 py-2.5 rounded-t-xl text-xs font-extrabold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'HISTORY'
                  ? 'bg-amber-400 text-emerald-950 shadow-md'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/60'
              }`}
            >
              <CreditCard size={14} />
              <span>Auto-Escrow Audit Trail</span>
            </button>
          </div>

          <div className="hidden sm:flex items-center gap-1 text-[11px] text-amber-300 font-bold bg-emerald-950 px-2.5 py-1 rounded-lg border border-emerald-800 shrink-0">
            <ShieldCheck size={13} className="text-amber-300" />
            <span>M-PESA Auto-Deduct Guard</span>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-5 max-h-[78vh] overflow-y-auto">

          {/* Success Banner */}
          {successMessage && (
            <div className="bg-emerald-100 text-emerald-950 p-3.5 rounded-2xl border border-emerald-300 text-xs font-bold animate-in fade-in">
              {successMessage}
            </div>
          )}

          {/* Manual Deduction Toast */}
          {deductionSuccess && (
            <div className="bg-amber-100 text-amber-950 p-3.5 rounded-2xl border border-amber-300 text-xs font-bold animate-in fade-in flex items-center gap-2">
              <Sparkles size={16} className="text-amber-700 shrink-0" />
              <span>{deductionSuccess}</span>
            </div>
          )}

          {/* TAB 1: CREATE SUBSCRIPTION */}
          {activeTab === 'CREATE' && (
            <form onSubmit={handleCreateSubscription} className="space-y-5">
              
              {/* Context Banner */}
              <div className="bg-stone-900 text-stone-200 p-4 rounded-2xl border border-stone-800 text-xs leading-relaxed space-y-1.5">
                <div className="flex items-center justify-between text-amber-300 font-extrabold">
                  <span className="flex items-center gap-1.5">
                    <Sparkles size={15} className="text-amber-300" />
                    Automated Recurring Household Help
                  </span>
                  <span className="bg-amber-400 text-emerald-950 text-[10px] font-black px-2 py-0.5 rounded">
                    KENYA URBAN FAVORITE
                  </span>
                </div>
                <p>
                  Never worry about manually booking your trusted Mama Fua, Nanny, House Help, or Handyman again. The app automatically reserves your preferred time slots and deducts the fee into safe GLOBALLICA Escrow 24 hours before each visit.
                </p>
              </div>

              {/* Specialist Selection if not pre-targeted */}
              {!targetProvider && allProviders.length > 0 && (
                <div>
                  <label className="block text-xs font-bold text-stone-800 mb-1">
                    Select Favorite Specialist / Domestic Helper:
                  </label>
                  <select
                    value={selectedProviderId}
                    onChange={(e) => {
                      setSelectedProviderId(e.target.value);
                      const p = allProviders.find(x => x.id === e.target.value);
                      if (p) setRatePerVisitKES(p.rateKES);
                    }}
                    className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3.5 py-2.5 text-xs font-bold text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                  >
                    {allProviders.map(p => (
                      <option key={p.id} value={p.id}>
                        {p.name} - {p.tradeSkill} ({p.operationalEstate}, KES {p.rateKES.toLocaleString()}/visit)
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Provider Preview Card */}
              {currentProvider && (
                <div className="bg-stone-50 border border-stone-200 rounded-2xl p-4 flex items-center justify-between gap-4 shadow-sm">
                  <div className="flex items-center gap-3">
                    <img
                      src={currentProvider.avatar}
                      alt={currentProvider.name}
                      className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-600 shadow-sm shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-extrabold text-stone-900 text-sm">{currentProvider.name}</h3>
                        <span className="bg-emerald-100 text-emerald-950 font-extrabold text-[10px] px-2 py-0.5 rounded border border-emerald-300">
                          {currentProvider.tradeSkill}
                        </span>
                      </div>
                      <p className="text-xs text-stone-500 font-medium mt-0.5">
                        📍 Base: {currentProvider.operationalEstate}, {currentProvider.operationalCounty} • Tel: {currentProvider.phone}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[10px] font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                          ★ {currentProvider.rating} ({currentProvider.reviewsCount} reviews)
                        </span>
                        <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          {currentProvider.completedJobsCount}+ Jobs Completed
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-[10px] text-stone-500 uppercase font-extrabold block">Standard Rate</span>
                    <span className="text-base font-black text-emerald-900">KES {currentProvider.rateKES.toLocaleString()}</span>
                    <span className="text-[10px] text-stone-400 block">per visit</span>
                  </div>
                </div>
              )}

              {/* Client & Location Details */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Client / Household Name</label>
                  <input
                    type="text"
                    required
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs font-bold text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                    placeholder="e.g. Sarah Mwangi"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Contact Phone</label>
                  <input
                    type="text"
                    required
                    value={clientPhone}
                    onChange={(e) => setClientPhone(e.target.value)}
                    className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs font-bold text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                    placeholder="+254712345678"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Household Estate & Apartment</label>
                  <input
                    type="text"
                    required
                    value={clientEstate}
                    onChange={(e) => setClientEstate(e.target.value)}
                    className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs font-bold text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                    placeholder="e.g. Kilimani, Rose Ave, Hse B4"
                  />
                </div>
              </div>

              {/* Subscription Schedule Setup */}
              <div className="bg-stone-50 border border-stone-200 rounded-2xl p-4 space-y-4">
                <h4 className="font-extrabold text-xs text-stone-900 uppercase tracking-wide flex items-center gap-1.5">
                  <Calendar size={15} className="text-emerald-800" />
                  Configure Service Schedule & Frequency
                </h4>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: 'WEEKLY', label: 'Weekly', desc: 'e.g. 1-3 times a week' },
                    { id: 'BI_WEEKLY', label: 'Bi-Weekly', desc: 'Every 2 weeks' },
                    { id: 'MONTHLY', label: 'Monthly', desc: 'Once per month' },
                    { id: 'CUSTOM_DAYS', label: 'Custom Days', desc: 'Pick exact days' }
                  ].map((freq) => (
                    <button
                      key={freq.id}
                      type="button"
                      onClick={() => setFrequency(freq.id as any)}
                      className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer ${
                        frequency === freq.id
                          ? 'bg-emerald-950 text-white border-amber-400 shadow-md'
                          : 'bg-white text-stone-700 border-stone-200 hover:border-emerald-600'
                      }`}
                    >
                      <span className={`block font-black text-xs ${frequency === freq.id ? 'text-amber-300' : 'text-stone-900'}`}>
                        {freq.label}
                      </span>
                      <span className="text-[10px] text-stone-400 font-medium">{freq.desc}</span>
                    </button>
                  ))}
                </div>

                {/* Days Selection */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1.5">
                    Select Preferred Visit Days:
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {weekDays.map(day => {
                      const isSelected = selectedDays.includes(day);
                      return (
                        <button
                          key={day}
                          type="button"
                          onClick={() => handleToggleDay(day)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-amber-400 text-emerald-950 border border-amber-500 shadow-sm'
                              : 'bg-white text-stone-600 border border-stone-200 hover:border-stone-400'
                          }`}
                        >
                          {isSelected ? '✓ ' : ''}{day}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Time Slot & Rate */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">Arrival Time Window</label>
                    <select
                      value={preferredTimeSlot}
                      onChange={(e) => setPreferredTimeSlot(e.target.value)}
                      className="w-full bg-white border border-stone-200 rounded-xl px-3 py-2 text-xs font-bold text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                    >
                      <option value="08:00 AM - 01:00 PM">08:00 AM - 01:00 PM (Morning Shift)</option>
                      <option value="01:00 PM - 05:00 PM">01:00 PM - 05:00 PM (Afternoon Shift)</option>
                      <option value="08:00 AM - 05:00 PM">08:00 AM - 05:00 PM (Full Day Shift)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">Agreed Rate per Visit (KES)</label>
                    <input
                      type="number"
                      required
                      min={500}
                      value={ratePerVisitKES}
                      onChange={(e) => setRatePerVisitKES(Number(e.target.value))}
                      className="w-full bg-white border border-stone-200 rounded-xl px-3 py-2 text-xs font-bold text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* M-PESA Auto-Deduct Escrow Configuration */}
              <div className="bg-gradient-to-r from-emerald-950 to-emerald-900 text-white rounded-2xl p-4 border border-amber-400/40 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShieldCheck size={20} className="text-amber-300" />
                    <h4 className="font-extrabold text-sm text-amber-300">
                      Automated M-PESA Escrow Billing
                    </h4>
                  </div>

                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={autoEscrowDeduct}
                      onChange={(e) => setAutoEscrowDeduct(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-emerald-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-400"></div>
                  </label>
                </div>

                <p className="text-xs text-stone-200 leading-relaxed">
                  When enabled, GLOBALLICA sends an automatic M-PESA STK prompt 24 hours before each scheduled visit. The funds are held safely in Escrow and are only released to the specialist after you verify completion.
                </p>

                {autoEscrowDeduct && (
                  <div className="pt-2 border-t border-emerald-800/80 grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
                    <div>
                      <label className="block text-[11px] font-bold text-amber-200 mb-1">
                        M-PESA Phone Number for STK Prompts
                      </label>
                      <input
                        type="text"
                        value={mpesaPhone}
                        onChange={(e) => setMpesaPhone(e.target.value)}
                        className="w-full bg-emerald-900 border border-emerald-700 rounded-xl px-3 py-1.5 text-xs font-mono font-bold text-white focus:outline-none focus:ring-1 focus:ring-amber-400"
                      />
                    </div>

                    <div className="bg-emerald-900/90 p-2.5 rounded-xl border border-emerald-700 text-right">
                      <span className="text-[10px] text-emerald-300 block font-semibold">Estimated Monthly Spend:</span>
                      <span className="font-mono font-black text-amber-300 text-sm">
                        KES {calculateMonthlyEstimate().toLocaleString()}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting || !currentProvider}
                className="w-full bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black py-3.5 rounded-2xl text-xs transition-all shadow-lg active:scale-98 cursor-pointer flex items-center justify-center gap-2 border border-amber-500"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw size={16} className="animate-spin text-emerald-950" />
                    <span>Activating Subscription & M-PESA Mandate...</span>
                  </>
                ) : (
                  <>
                    <Sparkles size={18} className="text-emerald-950" />
                    <span>Subscribe to {currentProvider?.name || 'Specialist'} (KES {ratePerVisitKES.toLocaleString()}/visit)</span>
                  </>
                )}
              </button>

            </form>
          )}

          {/* TAB 2: MY SUBSCRIPTIONS */}
          {activeTab === 'MY_SUBSCRIPTIONS' && (
            <div className="space-y-4">
              
              {subscriptions.length === 0 ? (
                <div className="bg-stone-50 border border-stone-200 rounded-2xl p-8 text-center space-y-3">
                  <RefreshCw size={36} className="mx-auto text-stone-400" />
                  <h3 className="font-bold text-stone-800 text-sm">No Active Household Subscriptions Yet</h3>
                  <p className="text-xs text-stone-500 max-w-sm mx-auto">
                    Subscribe to your favorite Mama Fua, Nanny, Gardener, or Plumber to enjoy automated weekly or monthly visits with auto-escrow protection.
                  </p>
                  <button
                    onClick={() => setActiveTab('CREATE')}
                    className="bg-emerald-950 text-amber-300 px-4 py-2 rounded-xl text-xs font-black shadow cursor-pointer"
                  >
                    + Create First Subscription
                  </button>
                </div>
              ) : (
                subscriptions.map(sub => (
                  <div
                    key={sub.id}
                    className="bg-white border-2 border-stone-200 hover:border-emerald-600 rounded-2xl p-4 shadow-sm transition-all space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-100 pb-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={sub.providerAvatar}
                          alt={sub.providerName}
                          className="w-12 h-12 rounded-2xl object-cover border-2 border-emerald-600 shadow-xs"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-extrabold text-stone-900 text-sm">{sub.providerName}</h3>
                            <span className={`text-[10px] font-black px-2 py-0.5 rounded uppercase ${
                              sub.status === 'ACTIVE'
                                ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                                : 'bg-stone-200 text-stone-700'
                            }`}>
                              ● {sub.status}
                            </span>
                          </div>
                          <p className="text-xs text-stone-500 font-medium">
                            {sub.providerSkill} • Household: {sub.clientEstate}
                          </p>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <span className="text-[10px] text-stone-400 font-bold block uppercase">Agreed Rate</span>
                        <span className="text-base font-black text-emerald-900">KES {sub.ratePerVisitKES.toLocaleString()}</span>
                        <span className="text-[10px] text-stone-500 block">per visit</span>
                      </div>
                    </div>

                    {/* Schedule details */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs bg-stone-50 p-3 rounded-xl border border-stone-200">
                      <div>
                        <span className="text-[10px] text-stone-400 font-bold block uppercase">Frequency</span>
                        <span className="font-extrabold text-stone-800">{sub.frequency}</span>
                      </div>

                      <div>
                        <span className="text-[10px] text-stone-400 font-bold block uppercase">Scheduled Days</span>
                        <span className="font-bold text-stone-800">{sub.preferredDays.join(', ')}</span>
                      </div>

                      <div>
                        <span className="text-[10px] text-stone-400 font-bold block uppercase">Time Window</span>
                        <span className="font-bold text-stone-800">{sub.preferredTimeSlot}</span>
                      </div>

                      <div>
                        <span className="text-[10px] text-stone-400 font-bold block uppercase">Next Scheduled Visit</span>
                        <span className="font-black text-emerald-800">📅 {sub.nextScheduledDate}</span>
                      </div>
                    </div>

                    {/* Escrow status info */}
                    {sub.lastEscrowDeductionAt && (
                      <div className="bg-emerald-50 text-emerald-950 p-2.5 rounded-xl border border-emerald-200 text-[11px] flex items-center justify-between">
                        <span className="font-bold flex items-center gap-1">
                          <ShieldCheck size={14} className="text-emerald-700" />
                          <span>Last Escrow Auto-Deposit: {sub.lastEscrowDeductionAt}</span>
                        </span>
                        <span className="font-extrabold text-emerald-900 bg-emerald-200 px-2 py-0.5 rounded">
                          {sub.completedVisitsCount} Visits Completed
                        </span>
                      </div>
                    )}

                    {/* Action Controls */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleTogglePause(sub)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1 ${
                            sub.status === 'ACTIVE'
                              ? 'bg-amber-100 text-amber-950 border border-amber-300 hover:bg-amber-200'
                              : 'bg-emerald-900 text-white hover:bg-emerald-800'
                          }`}
                        >
                          {sub.status === 'ACTIVE' ? <Pause size={13} /> : <Play size={13} />}
                          <span>{sub.status === 'ACTIVE' ? 'Pause Subscription' : 'Resume Subscription'}</span>
                        </button>

                        <button
                          type="button"
                          disabled={isDeductingId === sub.id}
                          onClick={() => handleTriggerManualDeduction(sub)}
                          className="bg-emerald-950 hover:bg-emerald-900 text-amber-300 px-3 py-1.5 rounded-xl text-xs font-extrabold border border-amber-400/40 transition-colors cursor-pointer flex items-center gap-1 shadow-xs"
                        >
                          {isDeductingId === sub.id ? (
                            <RefreshCw size={13} className="animate-spin text-amber-300" />
                          ) : (
                            <CreditCard size={13} className="text-amber-300" />
                          )}
                          <span>Trigger Auto-Escrow Deposit Now</span>
                        </button>
                      </div>

                      {/* Live Selfie Check Trigger if passed */}
                      {onOpenLiveSelfie && (
                        <button
                          type="button"
                          onClick={() => {
                            const p = allProviders.find(x => x.id === sub.providerId);
                            onOpenLiveSelfie(p || null);
                          }}
                          className="bg-stone-800 hover:bg-stone-700 text-amber-300 px-3 py-1.5 rounded-xl text-xs font-extrabold transition-colors cursor-pointer flex items-center gap-1"
                        >
                          <Camera size={13} className="text-amber-300" />
                          <span>📸 Live Selfie Check</span>
                        </button>
                      )}
                    </div>

                  </div>
                ))
              )}

            </div>
          )}

          {/* TAB 3: AUDIT TRAIL */}
          {activeTab === 'HISTORY' && (
            <div className="space-y-3">
              <div className="bg-stone-900 text-stone-200 p-3.5 rounded-2xl border border-stone-800 text-xs flex items-center justify-between">
                <span className="font-extrabold text-amber-300 flex items-center gap-1.5">
                  <ShieldCheck size={16} className="text-amber-300" />
                  GLOBALLICA Automated Escrow Billing Ledger
                </span>
                <span className="text-[10px] bg-emerald-900 text-emerald-200 px-2 py-0.5 rounded font-mono">
                  M-PESA B2C & C2B ENCRYPTED
                </span>
              </div>

              <div className="space-y-2">
                {[
                  {
                    code: 'QA88120491',
                    provider: 'Mama Fua Jane Wambui',
                    amount: 1500,
                    date: '2026-07-25 07:00 AM',
                    status: 'FUNDS_HELD_IN_ESCROW',
                    visitDate: '2026-07-25'
                  },
                  {
                    code: 'QA88091238',
                    provider: 'Mama Fua Jane Wambui',
                    amount: 1500,
                    date: '2026-07-21 07:00 AM',
                    status: 'RELEASED_TO_SPECIALIST',
                    visitDate: '2026-07-21'
                  },
                  {
                    code: 'QA87941092',
                    provider: 'Fundi James Otieno',
                    amount: 2500,
                    date: '2026-07-04 09:00 AM',
                    status: 'RELEASED_TO_SPECIALIST',
                    visitDate: '2026-07-04'
                  }
                ].map((log, idx) => (
                  <div key={idx} className="bg-stone-50 border border-stone-200 rounded-2xl p-3 flex items-center justify-between text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-stone-900">Receipt: {log.code}</span>
                        <span className="bg-stone-200 text-stone-800 text-[10px] font-bold px-1.5 py-0.5 rounded">
                          {log.provider}
                        </span>
                      </div>
                      <span className="text-[10px] text-stone-500 block mt-0.5">
                        Visit Date: {log.visitDate} • Auto-Deducted at {log.date}
                      </span>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="font-black text-emerald-900 text-sm block">KES {log.amount.toLocaleString()}</span>
                      <span className={`text-[10px] font-extrabold px-1.5 py-0.5 rounded ${
                        log.status === 'RELEASED_TO_SPECIALIST'
                          ? 'bg-emerald-100 text-emerald-900'
                          : 'bg-amber-100 text-amber-900 border border-amber-300'
                      }`}>
                        {log.status === 'RELEASED_TO_SPECIALIST' ? '✅ Released to Provider' : '🔒 Escrow Deposit Active'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Footer Close */}
          <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
            <span className="text-[11px] text-stone-500 font-medium">
              🔒 100% Protected by GLOBALLICA Escrow Guarantee. Cancel or pause anytime.
            </span>
            <button
              onClick={onClose}
              className="bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold px-4 py-2 rounded-xl text-xs transition-colors cursor-pointer"
            >
              Close Window
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
