import React, { useState } from 'react';
import { HousingListing } from '../types';
import { Home, PhoneCall, MessageSquare, ShieldCheck, CheckCircle2, MapPin, Eye, Zap, Droplets, Wifi, ShieldAlert, Award, Calendar, DollarSign, ExternalLink, Filter as FilterIcon } from 'lucide-react';

interface HousingModuleProps {
  listings: HousingListing[];
  onSelectHousing: (house: HousingListing) => void;
  onReserveMpesa: (house: HousingListing) => void;
  onOpenCaretakerPortal: () => void;
  onOpenHouseVetting?: (house?: HousingListing) => void;
}

export const HousingModule: React.FC<HousingModuleProps> = ({
  listings,
  onSelectHousing,
  onReserveMpesa,
  onOpenCaretakerPortal,
  onOpenHouseVetting
}) => {
  const [houseTypeFilter, setHouseTypeFilter] = useState<string>('all');
  const [maxRentFilter, setMaxRentFilter] = useState<number>(100000);
  const [amenityFilter, setAmenityFilter] = useState<string>('all');

  const filtered = listings.filter(h => {
    if (houseTypeFilter !== 'all' && h.houseType !== houseTypeFilter) return false;
    if (h.rentKES > maxRentFilter) return false;
    if (amenityFilter !== 'all' && !h.amenities.includes(amenityFilter)) return false;
    return true;
  });

  return (
    <div className="w-full max-w-full space-y-6">
      {/* Housing Section Banner */}
      <div className="w-full max-w-full bg-gradient-to-r from-emerald-900 to-emerald-800 text-white p-4 sm:p-5 rounded-2xl shadow-lg border border-emerald-700 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-amber-400 text-emerald-950 font-black px-2 py-0.5 rounded text-[10px] uppercase">
              🏠 Housing & Rentals Kenya
            </span>
            <span className="text-emerald-200 text-xs font-semibold">Verified Caretakers & Direct Landlords</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            Vacant Houses in Kilimani, Mirema, Pipeline, Ruaka & Nyali
          </h2>
          <p className="text-emerald-200 text-xs mt-1">
            Zero agency middlemen extortion. Call or WhatsApp verified Caretakers directly to view vacant bedsitters, 1BR & 2BR apartments.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {onOpenHouseVetting && (
            <button
              onClick={() => onOpenHouseVetting()}
              className="bg-emerald-950 hover:bg-emerald-900 text-amber-300 border border-amber-400/50 font-extrabold px-3 py-2.5 rounded-xl text-xs shadow-md transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
            >
              <ShieldCheck size={16} className="text-amber-300" />
              <span>Digital Title Deed / House Vetting</span>
            </button>
          )}

          <button
            onClick={onOpenCaretakerPortal}
            className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-extrabold px-3 py-2.5 rounded-xl text-xs shadow-lg transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
          >
            <Home size={16} />
            <span>List Vacancy</span>
          </button>
        </div>
      </div>

      {/* Sub-Filters for Housing */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-stone-200 flex flex-wrap items-center gap-3 text-xs">
        <span className="font-bold text-stone-700 flex items-center gap-1">
          <FilterIcon size={14} className="text-emerald-700" />
          Filter Vacancies:
        </span>

        {/* House Type */}
        <select
          id="housing-type-filter"
          name="houseTypeFilter"
          aria-label="Filter by House Type"
          value={houseTypeFilter}
          onChange={(e) => setHouseTypeFilter(e.target.value)}
          className="bg-stone-50 border border-stone-200 rounded-lg px-3 py-1.5 font-semibold text-stone-800 focus:ring-2 focus:ring-emerald-600 focus:outline-none cursor-pointer"
        >
          <option value="all">All House Types</option>
          <option value="Bedsitter">Bedsitter</option>
          <option value="Single Room">Single Room</option>
          <option value="1 Bedroom">1 Bedroom</option>
          <option value="2 Bedroom">2 Bedroom</option>
          <option value="3 Bedroom">3 Bedroom</option>
          <option value="Maisonette">Maisonette / Villa</option>
        </select>

        {/* Max Rent */}
        <div className="flex items-center gap-2 bg-stone-50 px-3 py-1.5 rounded-lg border border-stone-200">
          <label htmlFor="max-rent-range" className="font-semibold text-stone-600">Max Rent KES:</label>
          <span className="font-bold text-emerald-800">{maxRentFilter.toLocaleString()}</span>
          <input
            id="max-rent-range"
            name="maxRentFilter"
            aria-label="Maximum rent range filter"
            type="range"
            min={5000}
            max={100000}
            step={2500}
            value={maxRentFilter}
            onChange={(e) => setMaxRentFilter(Number(e.target.value))}
            className="w-24 accent-emerald-700 cursor-pointer"
          />
        </div>

        {/* Amenity Filter */}
        <select
          id="housing-amenity-filter"
          name="amenityFilter"
          aria-label="Filter by Amenity"
          value={amenityFilter}
          onChange={(e) => setAmenityFilter(e.target.value)}
          className="bg-stone-50 border border-stone-200 rounded-lg px-3 py-1.5 font-semibold text-stone-800 focus:ring-2 focus:ring-emerald-600 focus:outline-none cursor-pointer"
        >
          <option value="all">All Amenities</option>
          <option value="Borehole Water">💧 Borehole Water 24/7</option>
          <option value="KPLC Token Meter">⚡ Token Meter (KPLC)</option>
          <option value="Wi-Fi Ready">📶 Wi-Fi Ready</option>
          <option value="Parking Space">🚗 Parking Space</option>
          <option value="CCTV Security">📹 CCTV & Security</option>
          <option value="Balcony">🛋️ Balcony</option>
        </select>

        {filtered.length !== listings.length && (
          <span className="text-stone-500 font-medium ml-auto">
            Showing <strong>{filtered.length}</strong> of {listings.length} vacancies
          </span>
        )}
      </div>

      {/* Vacancy Grid */}
      {filtered.length === 0 ? (
        <div className="bg-stone-50 border border-dashed border-stone-300 rounded-2xl p-8 text-center text-stone-500 space-y-2">
          <Home size={36} className="mx-auto text-stone-400" />
          <h3 className="font-bold text-stone-700">No vacancies match your selected filter</h3>
          <p className="text-xs">Try increasing the rent range or selecting "All House Types".</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((house) => {
            const caretakerWaLink = `https://wa.me/${house.caretaker.whatsapp}?text=${encodeURIComponent(
              `Jambo ${house.caretaker.name}, I found your ${house.houseType} listing "${house.title}" in ${house.estate}, ${house.county} on GLOBALLICA. Is it still vacant?`
            )}`;

            return (
              <div
                key={house.id}
                className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col group"
              >
                {/* Photo & Badge Overlay */}
                <div 
                  onClick={() => onSelectHousing(house)}
                  className="relative h-48 sm:h-52 bg-stone-100 overflow-hidden cursor-pointer"
                >
                  <img
                    src={house.photos?.[0] || 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=800&q=80'}
                    alt={house.title}
                    onError={(e) => {
                      e.currentTarget.src = 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=800&q=80';
                    }}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Rent Tag */}
                  <div className="absolute top-3 left-3 bg-emerald-900/90 text-white px-3 py-1 rounded-xl shadow-md backdrop-blur-sm border border-emerald-700/50">
                    <span className="text-[10px] uppercase font-bold text-emerald-300 block">Rent / Month</span>
                    <span className="text-base font-black text-amber-300">
                      KES {house.rentKES.toLocaleString()}
                    </span>
                  </div>

                  {/* House Type Badge */}
                  <div className="absolute top-3 right-3 bg-stone-900/80 text-white text-xs font-bold px-2.5 py-1 rounded-lg backdrop-blur-sm">
                    {house.houseType}
                  </div>

                  {/* Estate Location Pill */}
                  <div className="absolute bottom-3 left-3 bg-stone-900/85 text-white text-xs font-semibold px-2.5 py-1 rounded-lg flex items-center gap-1 backdrop-blur-sm">
                    <MapPin size={13} className="text-amber-400" />
                    <span>{house.estate}, {house.county}</span>
                  </div>

                  {/* Views counter */}
                  <div className="absolute bottom-3 right-3 bg-black/60 text-white text-[10px] px-2 py-0.5 rounded flex items-center gap-1">
                    <Eye size={11} />
                    <span>{house.views} views</span>
                  </div>
                </div>

                {/* Listing Body */}
                <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    <h3 
                      onClick={() => onSelectHousing(house)}
                      className="font-bold text-stone-900 text-sm sm:text-base line-clamp-2 hover:text-emerald-700 cursor-pointer transition-colors leading-snug"
                    >
                      {house.title}
                    </h3>

                    {/* Deposit Terms */}
                    <div className="mt-2 bg-amber-50 border border-amber-200/80 rounded-lg p-2 text-xs text-amber-900">
                      <span className="font-bold">Terms: </span>
                      {house.depositTerms}
                    </div>

                    {/* House Vetting Status Badge */}
                    {house.vettingInfo?.isVetted ? (
                      <div className="mt-2 bg-emerald-950 text-amber-300 p-2 rounded-xl text-[10px] font-extrabold flex items-center justify-between border border-emerald-700">
                        <span className="flex items-center gap-1">
                          <ShieldCheck size={12} className="text-amber-300" />
                          <span>🛡️ Ardhisasa Title Deed Vetted</span>
                        </span>
                        <span className="font-mono text-emerald-200">{house.vettingInfo.lrTitleDeedNo}</span>
                      </div>
                    ) : onOpenHouseVetting && (
                      <button
                        type="button"
                        onClick={() => onOpenHouseVetting(house)}
                        className="mt-2 w-full bg-stone-900 hover:bg-black text-amber-300 p-2 rounded-xl text-[10px] font-bold flex items-center justify-between border border-stone-700 cursor-pointer"
                      >
                        <span className="flex items-center gap-1">
                          <ShieldCheck size={12} className="text-amber-400" /> Run Digital House & Title Deed Vetting
                        </span>
                        <span className="bg-amber-400 text-stone-950 px-1.5 py-0.2 rounded font-black">
                          Vet House
                        </span>
                      </button>
                    )}

                    {/* Amenity Badges */}
                    <div className="mt-3 flex flex-wrap gap-1">
                      {house.amenities.slice(0, 4).map((amenity) => (
                        <span
                          key={amenity}
                          className="bg-emerald-50 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-md border border-emerald-200/60 flex items-center gap-1"
                        >
                          {amenity.includes('Water') && <Droplets size={10} className="text-blue-600" />}
                          {amenity.includes('Token') && <Zap size={10} className="text-amber-600" />}
                          {amenity.includes('Wi-Fi') && <Wifi size={10} className="text-emerald-600" />}
                          <span>{amenity}</span>
                        </span>
                      ))}
                      {house.amenities.length > 4 && (
                        <span className="text-[10px] font-bold text-stone-500 bg-stone-100 px-1.5 py-0.5 rounded">
                          +{house.amenities.length - 4} more
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Caretaker Directory Box - Prompt Item 2.B Requirement */}
                  <div className="pt-3 border-t border-stone-100 space-y-2">
                    <div className="flex items-center justify-between bg-stone-50 p-2.5 rounded-xl border border-stone-200/70">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={house.caretaker.avatar}
                          alt={house.caretaker.name}
                          className="w-9 h-9 rounded-full object-cover border border-emerald-600"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <div className="flex items-center gap-1">
                            <span className="font-bold text-xs text-stone-900 line-clamp-1">
                              {house.caretaker.name}
                            </span>
                            {house.caretaker.isVerified && (
                              <span title="Verified Caretaker">
                                <ShieldCheck size={14} className="text-emerald-600 shrink-0" />
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-stone-500 font-medium">
                            Caretaker • ★ {house.caretaker.rating} ({house.caretaker.reviewCount} reviews)
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Quick Call & WhatsApp Action Buttons */}
                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <a
                        href={`tel:${house.caretaker.phone}`}
                        className="flex items-center justify-center gap-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2 px-3 rounded-xl text-xs transition-colors shadow-sm cursor-pointer"
                      >
                        <PhoneCall size={14} />
                        <span>Call Caretaker</span>
                      </a>

                      <a
                        href={caretakerWaLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 px-3 rounded-xl text-xs transition-colors shadow-sm cursor-pointer"
                      >
                        <MessageSquare size={14} />
                        <span>WhatsApp</span>
                      </a>
                    </div>

                    {/* M-Pesa Reserve Viewing Option */}
                    <button
                      onClick={() => onReserveMpesa(house)}
                      className="w-full bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black py-1.5 px-3 rounded-xl text-[11px] transition-all flex items-center justify-center gap-1.5 cursor-pointer border border-amber-300"
                    >
                      <Zap size={13} className="text-emerald-900" />
                      <span>Reserve Viewing Slot (KES 500 M-Pesa STK)</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

function Filter({ size, className }: { size: number; className?: string }) {
  return (
    <svg width={size} height={size} className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
    </svg>
  );
}
