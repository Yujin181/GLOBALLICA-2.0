import React, { useState } from 'react';
import { X, PhoneCall, MessageSquare, ShieldCheck, MapPin, Eye, CheckCircle2, Zap, Droplets, Wifi, ShieldAlert, Award, Calendar, DollarSign, ExternalLink, Camera, Video, Play, Film, QrCode, Lock, Truck, Car, RefreshCw } from 'lucide-react';
import { HousingListing, ServiceProvider, ProductListing } from '../types';
import { getProductCategoryPhoto } from '../utils/categoryImages';

interface ListingDetailModalProps {
  item: HousingListing | ServiceProvider | ProductListing | null;
  onClose: () => void;
  onReserveMpesa: (item: any) => void;
  onOpenNtsaVerification?: (initialRegNo?: string) => void;
  onOpenDigitalVetting?: (provider?: ServiceProvider) => void;
  onOpenEscrowTracker?: (provider?: ServiceProvider) => void;
  onOpenHouseVetting?: (house?: HousingListing) => void;
  onOpenLiveSelfie?: (provider?: ServiceProvider) => void;
  onOpenSubscriptions?: (provider?: ServiceProvider) => void;
}

export const ListingDetailModal: React.FC<ListingDetailModalProps> = ({
  item,
  onClose,
  onReserveMpesa,
  onOpenNtsaVerification,
  onOpenDigitalVetting,
  onOpenEscrowTracker,
  onOpenHouseVetting,
  onOpenLiveSelfie,
  onOpenSubscriptions
}) => {
  const [selectedPhotoIdx, setSelectedPhotoIdx] = useState(0);

  if (!item) return null;

  // Type guard functions
  const isHousing = 'houseType' in item;
  const isFundi = 'tradeSkill' in item;
  const isProduct = 'condition' in item;

  let phone = '';
  let whatsapp = '';
  let contactName = '';
  let title = '';

  if (isHousing) {
    phone = (item as HousingListing).caretaker.phone;
    whatsapp = (item as HousingListing).caretaker.whatsapp;
    contactName = (item as HousingListing).caretaker.name;
    title = (item as HousingListing).title;
  } else if (isFundi) {
    phone = (item as ServiceProvider).phone;
    whatsapp = (item as ServiceProvider).whatsapp;
    contactName = (item as ServiceProvider).name;
    title = `${(item as ServiceProvider).name} (${(item as ServiceProvider).tradeSkill})`;
  } else if (isProduct) {
    phone = (item as ProductListing).sellerPhone;
    whatsapp = (item as ProductListing).sellerWhatsapp;
    contactName = (item as ProductListing).sellerName;
    title = (item as ProductListing).title;
  }

  const waMessage = encodeURIComponent(
    `Jambo ${contactName}, I found your listing "${title}" on GLOBALLICA Kenya. Is it available?`
  );
  const waLink = `https://wa.me/${whatsapp}?text=${waMessage}`;

  const housingPhotos = isHousing ? ((item as HousingListing).photos?.length ? (item as HousingListing).photos : ['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=800&q=80']) : [];
  const productPhotos = isProduct ? ((item as ProductListing).photos?.length ? (item as ProductListing).photos : [getProductCategoryPhoto((item as ProductListing).category)]) : [];

  const handleImgError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    e.currentTarget.src = 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=800&q=80';
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-stone-200 my-8 space-y-5 animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-stone-100 pb-3">
          <div>
            <span className="bg-emerald-100 text-emerald-900 text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wider">
              {isHousing ? '🏠 Housing Vacancy' : isFundi ? '🛠️ Fundi Profile' : '🚗 Product Listing'}
            </span>
            <h2 className="font-extrabold text-lg sm:text-xl text-stone-900 mt-1 leading-snug">
              {title}
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-full transition-colors cursor-pointer shrink-0"
          >
            <X size={18} />
          </button>
        </div>

        {/* Media Photo */}
        {isHousing && (
          <div className="space-y-2">
            <div className="relative h-64 bg-stone-100 rounded-2xl overflow-hidden border border-stone-200 shadow-inner">
              <img
                src={housingPhotos[selectedPhotoIdx] || housingPhotos[0]}
                alt={title}
                onError={handleImgError}
                className="w-full h-full object-cover transition-all duration-300"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-3 right-3 bg-emerald-950 text-amber-300 font-extrabold text-xs px-3 py-1 rounded-xl shadow">
                RENT: KES {(item as HousingListing).rentKES.toLocaleString()} / Mo
              </div>
              <div className="absolute bottom-3 left-3 bg-stone-900/90 text-white text-xs px-3 py-1 rounded-xl flex items-center gap-1 backdrop-blur-sm font-semibold">
                <MapPin size={13} className="text-amber-400" />
                <span>{(item as HousingListing).estate}, {(item as HousingListing).county}</span>
              </div>
            </div>

            {/* Photo Thumbnails Selector */}
            {housingPhotos.length > 1 && (
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                {housingPhotos.map((imgUrl, pIdx) => (
                  <button
                    key={pIdx}
                    onClick={() => setSelectedPhotoIdx(pIdx)}
                    className={`relative w-20 h-14 rounded-xl overflow-hidden shrink-0 border-2 transition-all cursor-pointer ${
                      selectedPhotoIdx === pIdx ? 'border-emerald-600 ring-2 ring-emerald-300 scale-105' : 'border-stone-200 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={imgUrl} onError={handleImgError} alt={`Photo ${pIdx + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}

            {/* Anti-Scam House Title Deed Vetting Status Banner */}
            {(item as HousingListing).vettingInfo?.isVetted ? (
              <div className="bg-emerald-950 text-amber-300 p-3 rounded-2xl border border-amber-400/60 shadow-sm flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <ShieldCheck size={18} className="text-amber-300 shrink-0" />
                  <div>
                    <span className="font-black text-amber-300 block">🛡️ Ardhisasa Land Registry Vetted Property</span>
                    <span className="text-[10px] text-emerald-200">
                      Title Deed: {(item as HousingListing).vettingInfo?.lrTitleDeedNo} • Owner: {(item as HousingListing).vettingInfo?.registeredOwnerName}
                    </span>
                  </div>
                </div>
                <span className="bg-amber-400 text-emerald-950 text-[10px] font-black px-2 py-1 rounded-lg shrink-0">
                  REAL PROPERTY
                </span>
              </div>
            ) : onOpenHouseVetting && (
              <div className="bg-stone-900 text-stone-200 p-3 rounded-2xl border border-stone-700 flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-amber-300 block">Verify Title Deed & Physical Site Location</span>
                  <span className="text-[10px] text-stone-400">Run Ardhisasa land search & GPS physical audit.</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenHouseVetting(item as HousingListing);
                  }}
                  className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-extrabold px-3 py-1.5 rounded-xl text-xs shadow transition-transform active:scale-95 cursor-pointer shrink-0"
                >
                  Vet Property
                </button>
              </div>
            )}
          </div>
        )}

        {isFundi && (
          <div className="space-y-3">
            <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-center gap-4">
              <img
                src={(item as ServiceProvider).avatar}
                alt={title}
                onError={handleImgError}
                className="w-20 h-20 rounded-2xl object-cover border-2 border-emerald-600 shadow-md"
                referrerPolicy="no-referrer"
              />
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-extrabold text-base text-stone-900">{(item as ServiceProvider).name}</h3>
                  <ShieldCheck size={18} className="text-emerald-600" />
                </div>
                <span className="bg-amber-100 text-amber-900 font-bold text-xs px-2 py-0.5 rounded border border-amber-300 inline-block mt-1">
                  {(item as ServiceProvider).tradeSkill}
                </span>
                <p className="text-xs text-stone-600 font-semibold mt-1">
                  📍 {(item as ServiceProvider).operationalEstate}, {(item as ServiceProvider).operationalCounty} • ★ {(item as ServiceProvider).rating} ({(item as ServiceProvider).reviewsCount} reviews)
                </p>
              </div>
            </div>

            {/* Anti-Scam Vetting Status Banner */}
            {(item as ServiceProvider).vettingInfo?.isVetted ? (
              <div className="bg-emerald-950 text-amber-300 p-3 rounded-2xl border border-amber-400/60 shadow-sm flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <ShieldCheck size={18} className="text-amber-300 shrink-0" />
                  <div>
                    <span className="font-black text-amber-300 block">🛡️ IPRS ID & DCI Good Conduct Vetted</span>
                    <span className="text-[10px] text-emerald-200">
                      National ID: {(item as ServiceProvider).vettingInfo?.nationalIdNo} • License: {(item as ServiceProvider).vettingInfo?.tradeLicenceNo || 'Verified'}
                    </span>
                  </div>
                </div>
                <span className="bg-amber-400 text-emerald-950 text-[10px] font-black px-2 py-1 rounded-lg shrink-0">
                  CLEARANCE CERT
                </span>
              </div>
            ) : onOpenDigitalVetting && (
              <div className="bg-stone-900 text-stone-200 p-3 rounded-2xl border border-stone-700 flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-amber-300 block">Verify Provider Background (DCI/IPRS)</span>
                  <span className="text-[10px] text-stone-400">Run digital ID, Police clearance & TVET certificate lookup.</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenDigitalVetting(item as ServiceProvider);
                  }}
                  className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-extrabold px-3 py-1.5 rounded-xl text-xs shadow transition-transform active:scale-95 cursor-pointer shrink-0"
                >
                  Vet Provider
                </button>
              </div>
            )}

            {/* Domestic Help Subscription Banner */}
            {onOpenSubscriptions && (
              <div className="bg-gradient-to-r from-emerald-950 to-emerald-900 text-white p-3.5 rounded-2xl border border-amber-400/40 flex items-center justify-between text-xs shadow-md">
                <div className="flex items-center gap-2.5">
                  <div className="bg-amber-400 text-emerald-950 p-2 rounded-xl font-black shrink-0">
                    <RefreshCw size={18} />
                  </div>
                  <div>
                    <span className="font-extrabold text-amber-300 block">🔁 Subscribe to {item.name}</span>
                    <span className="text-[10px] text-emerald-200">
                      Set up automated weekly/monthly house visits & auto-escrow M-PESA deductions.
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenSubscriptions(item as ServiceProvider);
                  }}
                  className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black px-3.5 py-2 rounded-xl text-xs shadow transition-transform active:scale-95 cursor-pointer shrink-0 border border-amber-500"
                >
                  Subscribe Now
                </button>
              </div>
            )}

            {/* Anti-Impersonation AI Live Selfie Status Banner */}
            {(item as ServiceProvider).liveSelfieVerification?.isSelfieVerified ? (
              <div className="bg-gradient-to-r from-emerald-950 to-emerald-900 text-amber-300 p-3 rounded-2xl border border-emerald-500 shadow-sm flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Camera size={18} className="text-amber-300 shrink-0" />
                  <div>
                    <span className="font-black text-amber-300 block">📸 AI Live Selfie Face Matched & Cleared</span>
                    <span className="text-[10px] text-emerald-200">
                      Match Confidence: {(item as ServiceProvider).liveSelfieVerification?.matchedScorePercent}% • Identity Matched to Onboarding
                    </span>
                  </div>
                </div>
                <span className="bg-amber-400 text-emerald-950 text-[10px] font-black px-2 py-1 rounded-lg shrink-0">
                  PASSED BIOMETRICS
                </span>
              </div>
            ) : onOpenLiveSelfie && (
              <div className="bg-emerald-950 text-white p-3 rounded-2xl border border-emerald-700 flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-amber-300 block">Require AI Live Selfie Verification</span>
                  <span className="text-[10px] text-emerald-200">Verify specialist's real-time identity before job arrival.</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenLiveSelfie(item as ServiceProvider);
                  }}
                  className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-extrabold px-3 py-1.5 rounded-xl text-xs shadow transition-transform active:scale-95 cursor-pointer shrink-0"
                >
                  Verify Face
                </button>
              </div>
            )}
          </div>
        )}

        {isProduct && (
          <div className="space-y-2">
            <div className="relative h-64 bg-stone-100 rounded-2xl overflow-hidden border border-stone-200 shadow-inner">
              <img
                src={productPhotos[selectedPhotoIdx] || productPhotos[0]}
                alt={title}
                onError={handleImgError}
                className="w-full h-full object-cover transition-all duration-300"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-3 right-3 bg-emerald-950 text-amber-300 font-extrabold text-xs px-3 py-1 rounded-xl shadow">
                PRICE: KES {(item as ProductListing).priceKES.toLocaleString()}
              </div>
            </div>

            {/* Photo Thumbnails Selector */}
            {productPhotos.length > 1 && (
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                {productPhotos.map((imgUrl, pIdx) => (
                  <button
                    key={pIdx}
                    onClick={() => setSelectedPhotoIdx(pIdx)}
                    className={`relative w-20 h-14 rounded-xl overflow-hidden shrink-0 border-2 transition-all cursor-pointer ${
                      selectedPhotoIdx === pIdx ? 'border-emerald-600 ring-2 ring-emerald-300 scale-105' : 'border-stone-200 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={imgUrl} onError={handleImgError} alt={`Photo ${pIdx + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Details Checklist */}
        <div className="space-y-3 text-xs">
          {isHousing && (
            <div className="bg-stone-50 p-3 rounded-2xl border border-stone-200 space-y-2">
              <div className="font-bold text-stone-800">Deposit & Terms:</div>
              <p className="text-stone-700 bg-white p-2 rounded-xl border border-stone-200 font-medium">
                {(item as HousingListing).depositTerms}
              </p>

              <div className="font-bold text-stone-800 pt-1">Included Amenities:</div>
              <div className="flex flex-wrap gap-1.5">
                {(item as HousingListing).amenities.map(a => (
                  <span key={a} className="bg-emerald-100 text-emerald-900 text-xs font-bold px-2.5 py-1 rounded-lg border border-emerald-300">
                    ✓ {a}
                  </span>
                ))}
              </div>
            </div>
          )}

          {isFundi && (
            <div className="bg-stone-50 p-3 rounded-2xl border border-stone-200 space-y-2">
              <div className="font-bold text-stone-800">Profile & Experience:</div>
              <p className="text-stone-700">{item.bio}</p>

              <div className="font-bold text-stone-800 pt-1">Specialized Skills:</div>
              <div className="flex flex-wrap gap-1.5">
                {(item as ServiceProvider).skillsList.map(s => (
                  <span key={s} className="bg-stone-200 text-stone-800 font-bold px-2.5 py-1 rounded-lg">
                    ✓ {s}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Job Showcase & Portfolio Gallery for Fundis */}
          {isFundi && (item as ServiceProvider).portfolioShowcase && (item as ServiceProvider).portfolioShowcase!.length > 0 && (
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-stone-900 text-sm flex items-center gap-1.5">
                  <Camera size={16} className="text-emerald-700" />
                  <span>Job Showcase & Portfolio ({(item as ServiceProvider).portfolioShowcase!.length} Past Completed Jobs)</span>
                </h3>
                <span className="text-[10px] bg-emerald-100 text-emerald-900 font-bold px-2 py-0.5 rounded border border-emerald-300">
                  Verified Photos & Work History
                </span>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {(item as ServiceProvider).portfolioShowcase!.map((showcase) => {
                  const itemPhotos = showcase.photos && showcase.photos.length > 0 ? showcase.photos : [showcase.photoUrl];
                  const itemVideos = showcase.videos && showcase.videos.length > 0 ? showcase.videos : (showcase.videoUrl ? [showcase.videoUrl] : []);

                  return (
                    <div key={showcase.id} className="bg-stone-50 border border-stone-200 rounded-2xl p-3.5 shadow-sm space-y-2.5">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h4 className="font-extrabold text-stone-900 text-xs sm:text-sm leading-snug">{showcase.title}</h4>
                          {showcase.location && (
                            <span className="text-[10px] text-emerald-800 font-semibold block pt-0.5">
                              📍 {showcase.location} {showcase.completedDate && `• ${showcase.completedDate}`}
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          {itemPhotos.length > 0 && (
                            <span className="bg-emerald-100 text-emerald-900 font-bold text-[9px] px-2 py-0.5 rounded flex items-center gap-1">
                              <Camera size={10} /> {itemPhotos.length} Photo{itemPhotos.length > 1 ? 's' : ''}
                            </span>
                          )}
                          {itemVideos.length > 0 && (
                            <span className="bg-red-100 text-red-700 font-bold text-[9px] px-2 py-0.5 rounded flex items-center gap-1">
                              <Film size={10} /> {itemVideos.length} Video{itemVideos.length > 1 ? 's' : ''}
                            </span>
                          )}
                        </div>
                      </div>

                      <p className="text-[11px] text-stone-600 leading-relaxed">{showcase.description}</p>

                      {/* Display Photos Gallery */}
                      {itemPhotos.length > 0 && (
                        <div className="space-y-1">
                          <span className="text-[10px] font-extrabold text-stone-500 uppercase tracking-wider block">Job Photos:</span>
                          <div className={`grid ${itemPhotos.length === 1 ? 'grid-cols-1' : itemPhotos.length === 2 ? 'grid-cols-2' : 'grid-cols-3'} gap-2`}>
                            {itemPhotos.map((pUrl, pIdx) => (
                              <div key={pIdx} className="relative h-32 sm:h-36 bg-stone-200 rounded-xl overflow-hidden border border-stone-300 shadow-inner group">
                                <img
                                  src={pUrl}
                                  alt={`${showcase.title} ${pIdx}`}
                                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                                  referrerPolicy="no-referrer"
                                />
                                {itemPhotos.length > 1 && (
                                  <span className="absolute bottom-1 right-1 bg-black/70 text-white text-[8px] font-bold px-1.5 py-0.5 rounded">
                                    {pIdx + 1}/{itemPhotos.length}
                                  </span>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Display Videos Gallery */}
                      {itemVideos.length > 0 && (
                        <div className="space-y-1 pt-1">
                          <span className="text-[10px] font-extrabold text-stone-500 uppercase tracking-wider block">Job Video Clips:</span>
                          <div className={`grid ${itemVideos.length === 1 ? 'grid-cols-1' : 'grid-cols-1 sm:grid-cols-2'} gap-2`}>
                            {itemVideos.map((vUrl, vIdx) => (
                              <div key={vIdx} className="relative bg-black rounded-xl overflow-hidden border border-stone-800 shadow-md">
                                <video
                                  src={vUrl}
                                  controls
                                  playsInline
                                  className="w-full h-44 object-cover"
                                />
                                <div className="absolute top-2 left-2 bg-red-600 text-white font-extrabold text-[9px] px-2 py-0.5 rounded-full flex items-center gap-1 shadow">
                                  <Film size={10} />
                                  <span>Video Clip #{vIdx + 1}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* NTSA Strict Logbook Digital Verification Card */}
          {((isProduct && (item as ProductListing).category === 'Vehicles') ||
            (isFundi && ((item as ServiceProvider).tradeSkill === 'Cab / Taxi Ride (Uber Style)' || (item as ServiceProvider).tradeSkill === 'Lorry / Truck For Hire'))) && (
            <div className="bg-gradient-to-br from-stone-900 via-emerald-950 to-stone-900 rounded-2xl p-4 text-white border border-amber-400/60 shadow-md space-y-3">
              <div className="flex items-center justify-between border-b border-emerald-800 pb-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-amber-400 text-emerald-950 font-black flex items-center justify-center text-sm">
                    🇰🇪
                  </div>
                  <div>
                    <span className="text-[10px] font-extrabold text-amber-300 uppercase tracking-wider block">
                      NTSA TIMS LOGBOOK VERIFICATION
                    </span>
                    <h4 className="font-black text-xs text-white">Republic of Kenya Digital Logbook Status</h4>
                  </div>
                </div>

                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1">
                  <ShieldCheck size={12} className="text-emerald-400" /> TIMS Authenticated
                </span>
              </div>

              {item.ntsaVerification ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 bg-white/5 p-3 rounded-xl border border-white/10 text-[11px]">
                  <div>
                    <span className="text-[9px] text-emerald-200 font-bold block uppercase">Reg Number</span>
                    <span className="text-amber-300 font-black text-sm">{item.ntsaVerification.registrationNo}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-emerald-200 font-bold block uppercase">Logbook Serial</span>
                    <span className="text-white font-semibold">{item.ntsaVerification.logbookSerial}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-emerald-200 font-bold block uppercase">Class</span>
                    <span className="text-white font-semibold">{item.ntsaVerification.vehicleClass}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-emerald-200 font-bold block uppercase">Registered Owner</span>
                    <span className="text-amber-200 font-bold truncate block">{item.ntsaVerification.registeredOwner}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-emerald-200 font-bold block uppercase">Chassis Match</span>
                    <span className="text-white font-mono text-[10px]">{item.ntsaVerification.chassisNo}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-emerald-200 font-bold block uppercase">TIMS Ref</span>
                    <span className="text-white font-mono text-[10px]">{item.ntsaVerification.timsRefNumber}</span>
                  </div>
                </div>
              ) : (
                <div className="bg-white/5 p-3 rounded-xl border border-white/10 text-xs flex items-center justify-between gap-2">
                  <div className="space-y-0.5">
                    <span className="text-amber-300 font-bold text-xs block">
                      Verify Logbook Ownership with NTSA QR Scanner
                    </span>
                    <span className="text-[11px] text-emerald-200">
                      Scan logbook QR code or lookup TIMS registry to authenticate this vehicle.
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => onOpenNtsaVerification && onOpenNtsaVerification(isProduct ? (item as ProductListing).title : undefined)}
                    className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black text-xs px-3 py-2 rounded-xl flex items-center gap-1.5 shrink-0 shadow transition-transform active:scale-95 cursor-pointer"
                  >
                    <QrCode size={14} />
                    <span>Scan Logbook</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Description */}
          <div className="text-stone-600 leading-relaxed">
            <span className="font-bold text-stone-900 block mb-1">Description & Overview:</span>
            {isFundi ? (item as ServiceProvider).bio : (item as HousingListing | ProductListing).description}
          </div>
        </div>

        {/* Contact & M-Pesa Reserve Action */}
        <div className="pt-2 border-t border-stone-100 space-y-2">
          {isHousing && (
            <button
              onClick={() => {
                onClose();
                onReserveMpesa(item);
              }}
              className="w-full bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black py-2.5 rounded-2xl text-xs transition-all shadow-md cursor-pointer flex items-center justify-center gap-2 border border-amber-300"
            >
              <Zap size={15} />
              <span>Reserve House Viewing Slot (KES 500 via M-Pesa STK)</span>
            </button>
          )}

          {isFundi && onOpenEscrowTracker && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenEscrowTracker(item as ServiceProvider);
              }}
              className="w-full bg-emerald-950 hover:bg-emerald-900 text-amber-300 font-extrabold py-2.5 rounded-2xl text-xs transition-all shadow-md cursor-pointer flex items-center justify-center gap-2 border border-emerald-700"
            >
              <Lock size={15} className="text-amber-300" />
              <span>🔒 Book & Deposit Job Payment in Escrow (Release Code Protected)</span>
            </button>
          )}

          <div className="grid grid-cols-2 gap-2">
            <a
              href={`tel:${phone}`}
              className="flex items-center justify-center gap-2 bg-emerald-800 hover:bg-emerald-900 text-white font-bold py-3 rounded-2xl text-xs transition-colors cursor-pointer shadow-md"
            >
              <PhoneCall size={16} />
              <span>Call {contactName}</span>
            </a>

            <a
              href={waLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 rounded-2xl text-xs transition-colors cursor-pointer shadow-md"
            >
              <MessageSquare size={16} />
              <span>WhatsApp Chat</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
