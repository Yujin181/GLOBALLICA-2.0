import React, { useState } from 'react';
import { X, Lock, ShieldCheck, CheckCircle2, KeyRound, Smartphone, AlertCircle, ArrowRight, DollarSign, Loader2, Zap, Send, FileCheck, Check } from 'lucide-react';
import { EscrowJobPayment, ServiceProvider } from '../types';

interface EscrowJobTrackerModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialProvider?: ServiceProvider | null;
  escrowJobs: EscrowJobPayment[];
  onAddEscrowJob: (job: EscrowJobPayment) => void;
  onVerifyAndIssueCode: (jobId: string) => void;
  onReleaseEscrowPayment: (jobId: string, inputCode: string) => boolean;
}

export const EscrowJobTrackerModal: React.FC<EscrowJobTrackerModalProps> = ({
  isOpen,
  onClose,
  initialProvider,
  escrowJobs,
  onAddEscrowJob,
  onVerifyAndIssueCode,
  onReleaseEscrowPayment
}) => {
  const [activeTab, setActiveTab] = useState<'deposit' | 'jobs' | 'release'>('deposit');
  
  // New Job Deposit Form
  const [providerName, setProviderName] = useState(initialProvider?.name || 'Dennis Mwangi');
  const [providerPhone, setProviderPhone] = useState(initialProvider?.phone || '0712345678');
  const [tradeSkill, setTradeSkill] = useState<string>(initialProvider?.tradeSkill || 'Plumber');
  const [clientName, setClientName] = useState('David K.');
  const [clientPhone, setClientPhone] = useState('0722114455');
  const [amountKES, setAmountKES] = useState(initialProvider?.rateKES || 1500);
  const [jobDescription, setJobDescription] = useState('Fix leaking main pipe and install new sink tap in kitchen');
  const [mpesaReceipt, setMpesaReceipt] = useState('');
  
  const [isDepositing, setIsDepositing] = useState(false);
  const [depositSuccessMsg, setDepositSuccessMsg] = useState('');

  // Selected Job for Release Code Input
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);
  const [releaseInputCode, setReleaseInputCode] = useState('');
  const [releaseError, setReleaseError] = useState('');
  const [releaseSuccessJob, setReleaseSuccessJob] = useState<EscrowJobPayment | null>(null);

  if (!isOpen) return null;

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsDepositing(true);

    setTimeout(() => {
      setIsDepositing(false);
      // Generate unique 6-digit release code e.g. 782910
      const code = Math.floor(100000 + Math.random() * 900000).toString();
      const newJob: EscrowJobPayment = {
        id: `ESC-JOB-${Date.now()}`,
        providerId: initialProvider?.id || `PROV-${Math.floor(1000 + Math.random() * 9000)}`,
        providerName,
        providerPhone,
        tradeSkill,
        clientName,
        clientPhone,
        amountKES,
        jobDescription,
        depositDate: new Date().toISOString().split('T')[0],
        mpesaDepositReceipt: mpesaReceipt.trim().toUpperCase() || `RKE${Math.floor(10000000 + Math.random() * 90000000)}`,
        releaseCode: code,
        status: 'DEPOSITED_ESCROW'
      };

      onAddEscrowJob(newJob);
      setDepositSuccessMsg(`✓ KES ${amountKES.toLocaleString()} deposited in GLOBALLICA Escrow! Provider ${providerName} notified.`);
      
      setTimeout(() => {
        setDepositSuccessMsg('');
        setActiveTab('jobs');
      }, 1500);
    }, 1200);
  };

  const handleVerifyQuality = (jobId: string) => {
    onVerifyAndIssueCode(jobId);
  };

  const handleExecuteRelease = (e: React.FormEvent) => {
    e.preventDefault();
    setReleaseError('');
    if (!selectedJobId) return;

    const success = onReleaseEscrowPayment(selectedJobId, releaseInputCode.trim());
    if (success) {
      const found = escrowJobs.find(j => j.id === selectedJobId);
      if (found) {
        setReleaseSuccessJob({
          ...found,
          status: 'FUNDS_RELEASED_TO_PROVIDER',
          releasedAt: new Date().toLocaleString()
        });
      }
      setReleaseInputCode('');
    } else {
      setReleaseError('❌ Invalid Release Code! Please check the 6-digit code issued upon client work verification.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-stone-900 text-white rounded-3xl max-w-2xl w-full shadow-2xl border border-emerald-800 overflow-hidden my-6 animate-in fade-in zoom-in-95 space-y-0">
        
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-stone-900 to-emerald-950 p-5 flex items-center justify-between border-b border-emerald-800">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-400 text-emerald-950 flex items-center justify-center font-black shadow-lg">
              <Lock size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-black text-lg text-white tracking-tight">GLOBALLICA Escrow Job Payment & Code Release</h2>
                <span className="bg-emerald-500 text-emerald-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
                  Zero Scam Protection
                </span>
              </div>
              <p className="text-xs text-emerald-200 mt-0.5">
                Funds locked before job starts • Released via 6-digit client code upon work verification
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-stone-300 hover:text-white bg-stone-800 hover:bg-stone-700 rounded-full transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-5">
          {/* Navigation Tabs */}
          <div className="flex bg-stone-950 p-1 rounded-2xl border border-stone-800 text-xs font-bold">
            <button
              type="button"
              onClick={() => setActiveTab('deposit')}
              className={`flex-1 py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'deposit' ? 'bg-emerald-600 text-white shadow-md' : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              <Lock size={15} className={activeTab === 'deposit' ? 'text-amber-300' : ''} />
              <span>1. Deposit Escrow Funds</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('jobs')}
              className={`flex-1 py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'jobs' ? 'bg-emerald-600 text-white shadow-md' : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              <FileCheck size={15} className={activeTab === 'jobs' ? 'text-amber-300' : ''} />
              <span>2. Verify Work & Issue Code ({escrowJobs.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('release')}
              className={`flex-1 py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'release' ? 'bg-emerald-600 text-white shadow-md' : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              <KeyRound size={15} className={activeTab === 'release' ? 'text-amber-300' : ''} />
              <span>3. Enter Code & Release Payout</span>
            </button>
          </div>

          {/* TAB 1: DEPOSIT ESCROW FUNDS */}
          {activeTab === 'deposit' && (
            <div className="space-y-4">
              <div className="bg-emerald-950/80 p-4 rounded-2xl border border-emerald-700/80 space-y-2">
                <div className="flex items-center gap-2 text-amber-300 font-extrabold text-xs">
                  <ShieldCheck size={16} />
                  <span>Why Deposit Payment Before Work Begins?</span>
                </div>
                <p className="text-xs text-emerald-100 leading-relaxed">
                  100% protection for both client and provider. Funds are locked securely in platform Escrow. The provider is guaranteed payment for their work, and the client retains total control—funds are ONLY released when the client verifies the work and inputs the 6-digit release code.
                </p>
              </div>

              {depositSuccessMsg && (
                <div className="bg-emerald-600 text-white p-3 rounded-xl font-bold text-xs flex items-center gap-2 shadow">
                  <CheckCircle2 size={18} className="text-amber-300" />
                  <span>{depositSuccessMsg}</span>
                </div>
              )}

              <form onSubmit={handleDepositSubmit} className="space-y-3 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="escrow-provider-name" className="block font-bold text-stone-300 mb-1">
                      Service Provider / Driver Name *
                    </label>
                    <input
                      id="escrow-provider-name"
                      name="providerName"
                      type="text"
                      required
                      value={providerName}
                      onChange={(e) => setProviderName(e.target.value)}
                      className="w-full bg-stone-950 border border-stone-700 rounded-xl p-2.5 text-stone-200 font-bold"
                    />
                  </div>

                  <div>
                    <label htmlFor="escrow-provider-phone" className="block font-bold text-stone-300 mb-1">
                      Provider Registered M-Pesa Phone (Payout Target) *
                    </label>
                    <input
                      id="escrow-provider-phone"
                      name="providerPhone"
                      type="text"
                      required
                      value={providerPhone}
                      onChange={(e) => setProviderPhone(e.target.value)}
                      placeholder="0712345678"
                      className="w-full bg-stone-950 border border-stone-700 rounded-xl p-2.5 text-amber-300 font-mono font-bold"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label htmlFor="escrow-trade-skill" className="block font-bold text-stone-300 mb-1">
                      Skill / Service Type
                    </label>
                    <input
                      id="escrow-trade-skill"
                      name="tradeSkill"
                      type="text"
                      required
                      value={tradeSkill}
                      onChange={(e) => setTradeSkill(e.target.value)}
                      className="w-full bg-stone-950 border border-stone-700 rounded-xl p-2.5 text-stone-200 font-bold"
                    />
                  </div>

                  <div>
                    <label htmlFor="escrow-client-name" className="block font-bold text-stone-300 mb-1">
                      Client Name
                    </label>
                    <input
                      id="escrow-client-name"
                      name="clientName"
                      type="text"
                      required
                      value={clientName}
                      onChange={(e) => setClientName(e.target.value)}
                      className="w-full bg-stone-950 border border-stone-700 rounded-xl p-2.5 text-stone-200 font-bold"
                    />
                  </div>

                  <div>
                    <label htmlFor="escrow-client-phone" className="block font-bold text-stone-300 mb-1">
                      Client Phone Number
                    </label>
                    <input
                      id="escrow-client-phone"
                      name="clientPhone"
                      type="text"
                      required
                      value={clientPhone}
                      onChange={(e) => setClientPhone(e.target.value)}
                      className="w-full bg-stone-950 border border-stone-700 rounded-xl p-2.5 text-stone-200 font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="escrow-job-description" className="block font-bold text-stone-300 mb-1">
                    Job Description & Agreed Work Capacity *
                  </label>
                  <textarea
                    id="escrow-job-description"
                    name="jobDescription"
                    rows={2}
                    required
                    value={jobDescription}
                    onChange={(e) => setJobDescription(e.target.value)}
                    placeholder="Describe exact work scope and required capacity..."
                    className="w-full bg-stone-950 border border-stone-700 rounded-xl p-2.5 text-stone-200 text-xs"
                  ></textarea>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="escrow-amount-kes" className="block font-bold text-stone-300 mb-1">
                      Agreed Job Amount (KES) *
                    </label>
                    <input
                      id="escrow-amount-kes"
                      name="amountKES"
                      type="number"
                      required
                      value={amountKES}
                      onChange={(e) => setAmountKES(Number(e.target.value))}
                      className="w-full bg-stone-950 border border-emerald-700 rounded-xl p-2.5 text-emerald-400 font-black text-sm"
                    />
                  </div>

                  <div>
                    <label htmlFor="escrow-mpesa-receipt" className="block font-bold text-stone-300 mb-1">
                      M-Pesa Deposit Transaction Code (Optional)
                    </label>
                    <input
                      id="escrow-mpesa-receipt"
                      name="mpesaReceipt"
                      type="text"
                      value={mpesaReceipt}
                      onChange={(e) => setMpesaReceipt(e.target.value)}
                      placeholder="e.g. RKE992014"
                      className="w-full bg-stone-950 border border-stone-700 rounded-xl p-2.5 text-amber-300 font-mono text-xs uppercase"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isDepositing}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black py-3 rounded-2xl text-xs transition-all shadow-lg cursor-pointer flex items-center justify-center gap-2 active:scale-98 mt-2"
                >
                  {isDepositing ? (
                    <>
                      <Loader2 size={16} className="animate-spin text-amber-300" />
                      <span>Locking Funds in GLOBALLICA Escrow...</span>
                    </>
                  ) : (
                    <>
                      <Lock size={16} className="text-amber-300" />
                      <span>Deposit KES {amountKES.toLocaleString()} Into Secure Escrow</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          )}

          {/* TAB 2: ACTIVE ESCROW JOBS & CLIENT WORK VERIFICATION */}
          {activeTab === 'jobs' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-stone-300">Active Escrow Accounts ({escrowJobs.length})</span>
                <span className="text-[10px] text-emerald-400 font-semibold">Client Verification Required Prior to Release</span>
              </div>

              {escrowJobs.length === 0 ? (
                <div className="bg-stone-950 p-8 text-center rounded-2xl border border-stone-800 space-y-2">
                  <Lock size={32} className="text-stone-600 mx-auto" />
                  <p className="text-stone-400 text-xs font-bold">No Escrow Jobs Created Yet</p>
                  <p className="text-[11px] text-stone-500">
                    Deposit payment first on Tab 1 to lock job funds securely in Escrow.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {escrowJobs.map((job) => (
                    <div
                      key={job.id}
                      className="bg-stone-950 p-4 rounded-2xl border border-stone-800 space-y-3"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-800 pb-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-extrabold text-amber-300 text-sm">{job.providerName}</h4>
                            <span className="bg-stone-800 text-stone-300 text-[10px] px-2 py-0.5 rounded font-mono">
                              {job.tradeSkill}
                            </span>
                          </div>
                          <p className="text-[11px] text-stone-400">
                            Client: <strong className="text-stone-200">{job.clientName} ({job.clientPhone})</strong>
                          </p>
                        </div>

                        <div className="text-right">
                          <span className="font-black text-emerald-400 text-base block">
                            KES {job.amountKES.toLocaleString()}
                          </span>
                          <span className="text-[10px] text-stone-500 font-mono">
                            Receipt: {job.mpesaDepositReceipt}
                          </span>
                        </div>
                      </div>

                      <p className="text-xs text-stone-300 leading-relaxed bg-stone-900 p-2.5 rounded-xl border border-stone-800/80">
                        <strong>Work Scope:</strong> {job.jobDescription}
                      </p>

                      <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                        {/* Status badge */}
                        {job.status === 'DEPOSITED_ESCROW' && (
                          <span className="inline-flex items-center gap-1 text-[11px] bg-amber-950 text-amber-300 border border-amber-700/60 px-2.5 py-1 rounded-full font-bold">
                            <Lock size={12} /> Funds Locked in Escrow (Pending Client Verification)
                          </span>
                        )}

                        {job.status === 'CLIENT_VERIFIED_PENDING_CODE' && (
                          <div className="bg-emerald-950 p-2.5 rounded-xl border border-emerald-600/80 space-y-1 w-full">
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-emerald-300 font-bold flex items-center gap-1">
                                <CheckCircle2 size={14} className="text-emerald-400" /> Work Verified by Client
                              </span>
                              <span className="text-[10px] text-stone-400">Release Code Generated</span>
                            </div>
                            <div className="flex items-center justify-between bg-stone-900 p-2 rounded-lg border border-amber-400/60">
                              <span className="text-[11px] text-stone-300">Client Completion Release Code:</span>
                              <span className="font-mono text-base font-black text-amber-300 tracking-widest bg-stone-950 px-3 py-1 rounded border border-amber-400/80">
                                {job.releaseCode}
                              </span>
                            </div>
                          </div>
                        )}

                        {job.status === 'FUNDS_RELEASED_TO_PROVIDER' && (
                          <span className="inline-flex items-center gap-1 text-[11px] bg-emerald-950 text-emerald-400 border border-emerald-600 px-2.5 py-1 rounded-full font-bold">
                            <CheckCircle2 size={12} /> Escrow Released to M-Pesa ({job.providerPhone})
                          </span>
                        )}

                        {/* Action Buttons */}
                        {job.status === 'DEPOSITED_ESCROW' && (
                          <button
                            type="button"
                            onClick={() => handleVerifyQuality(job.id)}
                            className="bg-amber-400 hover:bg-amber-300 text-stone-950 font-black text-xs px-3.5 py-2 rounded-xl transition-all shadow cursor-pointer flex items-center gap-1.5 active:scale-95"
                          >
                            <CheckCircle2 size={14} />
                            <span>Verify Work Quality & Generate Release Code</span>
                          </button>
                        )}

                        {job.status === 'CLIENT_VERIFIED_PENDING_CODE' && (
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedJobId(job.id);
                              setActiveTab('release');
                            }}
                            className="bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs px-3.5 py-2 rounded-xl transition-all shadow cursor-pointer flex items-center gap-1.5 ml-auto"
                          >
                            <KeyRound size={14} />
                            <span>Enter Code & Execute Payout &rarr;</span>
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: ENTER RELEASE CODE & EXECUTE DIRECT M-PESA PAYOUT */}
          {activeTab === 'release' && (
            <div className="space-y-4">
              {releaseSuccessJob ? (
                <div className="bg-emerald-950 p-6 rounded-3xl border-2 border-emerald-500 text-center space-y-4 shadow-xl">
                  <div className="w-16 h-16 rounded-2xl bg-amber-400 text-emerald-950 flex items-center justify-center mx-auto text-3xl font-black shadow-lg">
                    📲
                  </div>
                  <div className="space-y-1">
                    <h3 className="font-black text-lg text-white">
                      Escrow Funds Released Directly to Service Provider!
                    </h3>
                    <p className="text-xs text-emerald-200">
                      Disbursement processed to registered M-Pesa line <strong className="text-amber-300">{releaseSuccessJob.providerPhone}</strong>
                    </p>
                  </div>

                  <div className="bg-stone-900 p-4 rounded-2xl border border-stone-800 text-xs font-mono text-left space-y-1.5">
                    <div className="flex justify-between">
                      <span className="text-stone-400">Service Provider:</span>
                      <span className="text-amber-300 font-bold">{releaseSuccessJob.providerName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">Target M-Pesa Line:</span>
                      <span className="text-emerald-400 font-bold">{releaseSuccessJob.providerPhone}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">Payout Amount:</span>
                      <span className="text-emerald-400 font-bold">KES {releaseSuccessJob.amountKES.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">M-Pesa Disburse Ref:</span>
                      <span className="text-amber-300 font-bold">DISBURSE-MPESA-{Math.floor(10000000 + Math.random() * 90000000)}</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setReleaseSuccessJob(null);
                      setActiveTab('jobs');
                    }}
                    className="w-full bg-amber-400 text-emerald-950 font-black py-3 rounded-xl text-xs hover:bg-amber-300 cursor-pointer"
                  >
                    Done / Return to Job Tracker
                  </button>
                </div>
              ) : (
                <form onSubmit={handleExecuteRelease} className="space-y-4">
                  <div className="bg-stone-800/80 p-4 rounded-2xl border border-stone-700 text-xs space-y-2">
                    <span className="font-bold text-amber-300 text-xs block">
                      🔑 How Code Verification Works:
                    </span>
                    <p className="text-stone-300 leading-relaxed">
                      1. Client verifies completed work and receives the 6-digit release code. <br />
                      2. Client inputs code below (or provides code to the fundi/driver to input). <br />
                      3. System unlocks Escrow and immediately disburses full payment via M-Pesa to the provider's registered phone line.
                    </p>
                  </div>

                  <div>
                    <label htmlFor="escrow-select-job" className="block text-xs font-bold text-stone-300 mb-1">
                      Select Active Escrow Job *
                    </label>
                    <select
                      id="escrow-select-job"
                      name="selectedJobId"
                      required
                      value={selectedJobId || ''}
                      onChange={(e) => setSelectedJobId(e.target.value)}
                      className="w-full bg-stone-950 border border-stone-700 rounded-xl p-3 text-stone-200 text-xs font-bold"
                    >
                      <option value="">-- Select Escrow Job --</option>
                      {escrowJobs.map((j) => (
                        <option key={j.id} value={j.id}>
                          {j.providerName} ({j.tradeSkill}) - KES {j.amountKES.toLocaleString()} [{j.status.replace(/_/g, ' ')}]
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label htmlFor="escrow-release-code-input" className="block text-xs font-bold text-stone-300 mb-1 flex items-center justify-between">
                      <span>Enter 6-Digit Client Completion Release Code *</span>
                      <span className="text-[10px] text-amber-400 font-mono">e.g. 782910</span>
                    </label>
                    <input
                      id="escrow-release-code-input"
                      name="releaseInputCode"
                      type="text"
                      required
                      maxLength={6}
                      value={releaseInputCode}
                      onChange={(e) => setReleaseInputCode(e.target.value)}
                      placeholder="e.g. 782910"
                      className="w-full bg-stone-950 border border-emerald-700 rounded-xl p-3.5 text-amber-300 font-mono text-center font-black text-xl tracking-widest focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>

                  {releaseError && (
                    <div className="bg-rose-950 text-rose-200 p-3 rounded-xl border border-rose-600 text-xs font-bold flex items-center gap-2">
                      <AlertCircle size={16} className="text-rose-400 shrink-0" />
                      <span>{releaseError}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black py-3.5 rounded-2xl text-xs transition-all shadow-lg cursor-pointer flex items-center justify-center gap-2 active:scale-98"
                  >
                    <KeyRound size={16} className="text-amber-300" />
                    <span>Verify Code & Disburse M-Pesa Payout to Provider Line</span>
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
