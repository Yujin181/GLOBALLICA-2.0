import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Globe, 
  Home, 
  ShoppingBag, 
  Wrench, 
  AlertTriangle, 
  ExternalLink, 
  UserCheck, 
  RefreshCw,
  ChevronDown,
  Key,
  LogOut,
  AlertCircle
} from 'lucide-react';
import { PortalConfig, PortalId, PORTAL_REGISTRY } from '../utils/portalRouter';
import { RBACRole } from '../types';
import { useAuth } from '../context/AuthContext';

interface PortalGuardBannerProps {
  currentPortal: PortalConfig;
  currentRole: RBACRole;
  onRoleChange?: (role: RBACRole) => void;
  isAccessDenied: boolean;
  denialReason?: string;
  simulatedPortalId: PortalId | null;
  onSelectPortal: (portalId: PortalId | 'clear') => void;
  onOpenLogin: () => void;
}

export const PortalGuardBanner: React.FC<PortalGuardBannerProps> = ({
  currentPortal,
  currentRole,
  onRoleChange,
  isAccessDenied,
  denialReason,
  simulatedPortalId,
  onSelectPortal,
  onOpenLogin
}) => {
  const { currentUser, userProfile, signOutUser } = useAuth();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const getPortalIcon = (id: PortalId) => {
    switch (id) {
      case 'vault': return <Lock size={16} className="text-purple-400" />;
      case 'caretaker': return <Home size={16} className="text-blue-400" />;
      case 'seller': return <ShoppingBag size={16} className="text-emerald-400" />;
      case 'fundi': return <Wrench size={16} className="text-amber-400" />;
      default: return <Globe size={16} className="text-emerald-400" />;
    }
  };

  return (
    <div className={`w-full text-white text-xs py-2 px-3 sm:px-6 transition-all border-b ${
      isAccessDenied 
        ? 'bg-rose-950/95 border-rose-500/60 shadow-lg shadow-rose-950/40' 
        : 'bg-emerald-950/90 border-emerald-800/60'
    }`}>
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        
        {/* Left: Current Portal Subdomain Info */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="flex items-center gap-2 bg-black/40 px-3 py-1 rounded-full border border-white/10 shadow-inner">
            {getPortalIcon(currentPortal.id)}
            <span className="font-bold tracking-tight text-white font-mono text-[11px] sm:text-xs">
              https://{currentPortal.canonicalHost}
            </span>
            {simulatedPortalId && (
              <span className="bg-amber-400 text-emerald-950 text-[9px] font-black uppercase px-1.5 py-0.5 rounded">
                Simulated
              </span>
            )}
          </div>

          <span className="hidden sm:inline-block text-white/30">|</span>

          {/* Access Status Badge */}
          {isAccessDenied ? (
            <div className="flex items-center gap-1.5 text-rose-300 font-bold bg-rose-900/60 px-2.5 py-1 rounded-md border border-rose-500/40 animate-pulse">
              <AlertTriangle size={14} className="text-rose-400" />
              <span>ACCESS DENIED — Role Mismatch</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-emerald-300 font-medium bg-emerald-900/40 px-2.5 py-1 rounded-md border border-emerald-500/30">
              <ShieldCheck size={14} className="text-emerald-400" />
              <span>Verified Portal Session: <strong className="text-white capitalize">{currentRole}</strong></span>
            </div>
          )}
        </div>

        {/* Center: Interactive Subdomain Simulator Controls */}
        <div className="flex items-center gap-2 flex-wrap ml-auto">
          
          {/* Portal Switcher Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="flex items-center gap-1.5 bg-emerald-900/80 hover:bg-emerald-800 text-emerald-100 px-3 py-1.5 rounded-lg border border-emerald-700/60 font-medium text-xs transition-colors cursor-pointer"
            >
              <Globe size={13} className="text-amber-400" />
              <span>Switch Subdomain Portal</span>
              <ChevronDown size={13} className="text-emerald-300" />
            </button>

            {isDropdownOpen && (
              <div 
                className="absolute right-0 mt-2 w-72 bg-emerald-950 border border-emerald-700 rounded-xl shadow-2xl z-50 overflow-hidden py-1"
                onMouseLeave={() => setIsDropdownOpen(false)}
              >
                <div className="px-3 py-2 bg-emerald-900/80 border-b border-emerald-800">
                  <p className="text-[10px] font-bold text-amber-300 uppercase tracking-wider">
                    Simulate Subdomain Routing
                  </p>
                  <p className="text-[11px] text-emerald-200">
                    Test role-based access & redirect logic live
                  </p>
                </div>

                {(Object.keys(PORTAL_REGISTRY) as PortalId[]).map((portalKey) => {
                  const p = PORTAL_REGISTRY[portalKey];
                  const isSelected = currentPortal.id === p.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => {
                        onSelectPortal(p.id);
                        setIsDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2.5 flex items-start gap-2.5 hover:bg-emerald-800/60 transition-colors border-b border-emerald-900/50 ${
                        isSelected ? 'bg-emerald-900/90 font-bold border-l-4 border-l-amber-400' : ''
                      }`}
                    >
                      <div className="mt-0.5">{getPortalIcon(p.id)}</div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-white text-xs">{p.name}</span>
                          <span className="text-[10px] text-emerald-400 font-mono">.{p.subdomains[0]}</span>
                        </div>
                        <p className="text-[10px] text-emerald-300/80 mt-0.5 line-clamp-1">
                          Roles required: {p.requiredRoles.join(', ')}
                        </p>
                      </div>
                    </button>
                  );
                })}

                {simulatedPortalId && (
                  <button
                    onClick={() => {
                      onSelectPortal('clear');
                      setIsDropdownOpen(false);
                    }}
                    className="w-full text-center py-2 text-[11px] text-amber-300 hover:bg-emerald-900/40 font-bold border-t border-emerald-800"
                  >
                    Reset to Real Host Subdomain
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Quick Role Tester (if access denied or testing) */}
          {onRoleChange && (
            <div className="flex items-center gap-1 bg-black/30 p-0.5 rounded-lg border border-white/10">
              <span className="text-[10px] text-emerald-300 px-1.5 font-semibold hidden md:inline">Test Role:</span>
              {(['customer', 'caretaker', 'seller', 'fundi', 'admin'] as RBACRole[]).map((r) => (
                <button
                  key={r}
                  onClick={() => onRoleChange(r)}
                  className={`px-2 py-1 rounded text-[10px] font-bold capitalize transition-colors ${
                    currentRole === r
                      ? 'bg-amber-400 text-emerald-950 shadow-sm'
                      : 'text-emerald-200 hover:text-white hover:bg-emerald-800/50'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          )}

          {/* Action Button */}
          {isAccessDenied ? (
            <button
              onClick={onOpenLogin}
              className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 shadow-md transition-transform active:scale-95 cursor-pointer"
            >
              <Key size={13} />
              <span>Login for Portal Access</span>
            </button>
          ) : (
            currentUser ? (
              <button
                onClick={signOutUser}
                className="bg-rose-900/60 hover:bg-rose-800 text-rose-200 border border-rose-700/60 px-2.5 py-1 rounded-lg text-[11px] flex items-center gap-1 transition-colors"
              >
                <LogOut size={12} />
                <span>Sign Out</span>
              </button>
            ) : (
              <button
                onClick={onOpenLogin}
                className="bg-emerald-800 hover:bg-emerald-700 text-white px-2.5 py-1 rounded-lg text-[11px] flex items-center gap-1 transition-colors"
              >
                <UserCheck size={12} />
                <span>Sign In</span>
              </button>
            )
          )}

        </div>

      </div>

      {/* Access Denied Warning Bar */}
      {isAccessDenied && (
        <div className="mt-2 bg-rose-900/80 border border-rose-500/80 rounded-xl p-3 text-rose-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xl animate-fadeIn">
          <div className="flex items-start gap-2.5">
            <AlertCircle size={18} className="text-amber-300 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-xs text-white">
                Subdomain Permission Restriction on {currentPortal.canonicalHost}
              </p>
              <p className="text-[11px] text-rose-200 mt-0.5">
                {denialReason || currentPortal.loginMessage}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
            <button
              onClick={onOpenLogin}
              className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-extrabold px-3 py-1.5 rounded-lg text-xs shadow transition-transform active:scale-95 cursor-pointer"
            >
              Authenticate as {currentPortal.requiredRoles.join(' / ')}
            </button>
            <button
              onClick={() => onSelectPortal('public')}
              className="bg-emerald-900 hover:bg-emerald-800 text-white px-2 py-1.5 rounded-lg text-xs border border-emerald-700"
            >
              Return to Main Market
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
