import React from 'react';
import { ShoppingBag, Home, Wrench, Truck, ShieldCheck, PlusCircle, Database, Phone, UserCheck, LogOut, Lock, User, Camera, RefreshCw } from 'lucide-react';
import { RBACRole } from '../types';
import { useAuth } from '../context/AuthContext';
import globallicaLogo from '../assets/images/globallica_logo_1785390734136.jpg';

interface HeaderProps {
  currentRole: RBACRole;
  setCurrentRole: (role: RBACRole) => void;
  onOpenCaretakerPortal: () => void;
  onOpenFundiPortal: () => void;
  onOpenMediaPortal?: () => void;
  onOpenSellerPortal: () => void;
  onOpenArchitectureModal: () => void;
  onOpenSafetyModal: () => void;
  onOpenPhoneAuthModal: () => void;
  onOpenDigitalVetting?: () => void;
  onOpenEscrowTracker?: () => void;
  onOpenHouseVetting?: () => void;
  onOpenLiveSelfie?: () => void;
  onOpenSubscriptions?: () => void;
  activeCategory: string;
  setActiveCategory: (cat: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  setCurrentRole,
  onOpenCaretakerPortal,
  onOpenFundiPortal,
  onOpenMediaPortal,
  onOpenSellerPortal,
  onOpenArchitectureModal,
  onOpenSafetyModal,
  onOpenPhoneAuthModal,
  onOpenDigitalVetting,
  onOpenEscrowTracker,
  onOpenHouseVetting,
  onOpenLiveSelfie,
  onOpenSubscriptions,
  activeCategory,
  setActiveCategory
}) => {
  const { currentUser, userProfile, signOutUser } = useAuth();

  return (
    <header className="sticky top-0 z-40 bg-emerald-900 text-white shadow-lg border-b border-emerald-800">
      {/* Top Banner Notice - Kenya Mobile Net & Auth Badge */}
      <div className="bg-emerald-950 text-emerald-200 text-xs py-1.5 px-4 flex items-center justify-between border-b border-emerald-900/60">
        <div className="flex items-center gap-2 overflow-x-auto whitespace-nowrap scrollbar-none">
          <span className="inline-flex items-center gap-1 bg-emerald-800 text-emerald-100 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider">
            🇰🇪 GLOBALLICA Kenya
          </span>
          <span className="hidden sm:inline text-emerald-300">Verified Marketplace & Direct Caretakers</span>
        </div>

        <div className="flex items-center gap-3 text-xs shrink-0">
          {/* Firebase Phone Auth User Quick Pill */}
          {userProfile || currentUser ? (
            <div className="flex items-center gap-2 bg-emerald-900 border border-emerald-700 px-2.5 py-0.5 rounded-full text-[11px]">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="font-mono font-bold text-amber-300">
                {userProfile?.phoneNumber || currentUser?.phoneNumber}
              </span>
              <button
                onClick={onOpenPhoneAuthModal}
                className="hover:text-white underline font-semibold text-[10px] cursor-pointer ml-1"
                title="Manage Profile & Location"
              >
                Profile
              </button>
              <button
                onClick={signOutUser}
                className="text-stone-400 hover:text-red-300 cursor-pointer ml-1"
                title="Sign Out"
              >
                <LogOut size={12} />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenPhoneAuthModal}
              className="flex items-center gap-1 bg-amber-400 hover:bg-amber-300 text-emerald-950 font-extrabold px-2.5 py-0.5 rounded-full text-[11px] shadow transition-all cursor-pointer"
            >
              <Phone size={12} />
              <span>Phone Sign In / Register</span>
            </button>
          )}

          <button 
            onClick={onOpenSafetyModal} 
            className="flex items-center gap-1 hover:text-emerald-100 transition-colors cursor-pointer text-amber-300 font-medium"
            title="Kenyan Scam Protection Rules"
          >
            <ShieldCheck size={14} />
            <span className="hidden sm:inline">Trust & Safety</span>
          </button>
          
          <button 
            onClick={onOpenArchitectureModal}
            className="flex items-center gap-1 bg-emerald-800/80 hover:bg-emerald-800 text-emerald-100 px-2 py-0.5 rounded text-xs transition-all cursor-pointer font-mono"
            title="View Database Schema & Architecture"
          >
            <Database size={13} className="text-amber-400" />
            <span className="hidden sm:inline">DB Schema & Arch</span>
            <span className="sm:hidden">Arch</span>
          </button>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="w-full max-w-full px-3 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <div className="flex items-center gap-3">
          <div 
            onClick={() => setActiveCategory('all')} 
            className="cursor-pointer flex items-center gap-2.5 group"
          >
            <img 
              src={globallicaLogo} 
              alt="GLOBALLICA Logo" 
              referrerPolicy="no-referrer"
              className="w-10 h-10 rounded-xl object-cover border border-amber-400/50 shadow-md group-hover:scale-105 transition-transform"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl tracking-tight text-white group-hover:text-amber-300 transition-colors">
                  GLOBALLICA
                </span>
                <span className="bg-amber-400 text-emerald-950 text-[10px] font-bold px-1.5 py-0.2 rounded uppercase">
                  KE
                </span>
              </div>
              <p className="text-[10px] text-emerald-200 font-medium tracking-wide">
                Housing, Goods & Local Services
              </p>
            </div>
          </div>
        </div>

        {/* Quick Category Links (Desktop) */}
        <nav className="hidden md:flex items-center gap-1 bg-emerald-950/60 p-1 rounded-xl border border-emerald-800/60">
          <button
            onClick={() => setActiveCategory('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeCategory === 'all' 
                ? 'bg-amber-400 text-emerald-950 shadow-sm' 
                : 'text-emerald-100 hover:bg-emerald-800/50'
            }`}
          >
            All Items
          </button>

          <button
            onClick={() => setActiveCategory('housing')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeCategory === 'housing' 
                ? 'bg-amber-400 text-emerald-950 shadow-sm' 
                : 'text-emerald-100 hover:bg-emerald-800/50'
            }`}
          >
            <Home size={14} />
            Housing & Caretakers
          </button>

          <button
            onClick={() => setActiveCategory('services')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeCategory === 'services' 
                ? 'bg-amber-400 text-emerald-950 shadow-sm' 
                : 'text-emerald-100 hover:bg-emerald-800/50'
            }`}
          >
            <Wrench size={14} />
            Local Fundis
          </button>

          <button
            onClick={() => setActiveCategory('transport')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeCategory === 'transport' 
                ? 'bg-amber-400 text-emerald-950 shadow-sm' 
                : 'text-emerald-100 hover:bg-emerald-800/50'
            }`}
          >
            <Truck size={14} />
            Transport & Cabs
          </button>

          <button
            onClick={() => setActiveCategory('marketplace')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeCategory === 'marketplace' 
                ? 'bg-amber-400 text-emerald-950 shadow-sm' 
                : 'text-emerald-100 hover:bg-emerald-800/50'
            }`}
          >
            <ShoppingBag size={14} />
            Cars & Goods
          </button>
        </nav>

        {/* Actions & Role Switcher */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Role Switcher Pill */}
          <div className="relative inline-flex items-center bg-emerald-950 p-1 rounded-xl border border-emerald-800 text-xs">
            <span className="text-[10px] text-emerald-300 font-medium px-2 hidden lg:inline">
              Role:
            </span>
            <select
              id="header-role-select"
              name="currentRole"
              aria-label="Select User Role"
              value={currentRole}
              onChange={(e) => setCurrentRole(e.target.value as RBACRole)}
              className="bg-emerald-800 text-white font-semibold rounded-lg px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-amber-400 cursor-pointer"
            >
              <option value="customer">Buyer / Customer</option>
              <option value="caretaker">Caretaker / Landlord</option>
              <option value="fundi">Fundi / Service Provider</option>
              <option value="seller">Product / Car Seller</option>
            </select>
          </div>

          {/* Post Listing CTA based on Role */}
          {currentRole === 'caretaker' && (
            <button
              onClick={onOpenCaretakerPortal}
              className="flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 text-emerald-950 font-bold px-3 py-1.5 rounded-xl text-xs transition-all shadow-md active:scale-95 cursor-pointer"
            >
              <PlusCircle size={15} />
              <span>List House</span>
            </button>
          )}

          {currentRole === 'fundi' && (
            <div className="flex items-center gap-1.5">
              {onOpenMediaPortal && (
                <button
                  onClick={onOpenMediaPortal}
                  className="flex items-center gap-1.5 bg-amber-400 text-emerald-950 font-black px-3 py-1.5 rounded-xl text-xs transition-all shadow-md active:scale-95 cursor-pointer"
                >
                  <UserCheck size={15} />
                  <span>Sign In & Showcase</span>
                </button>
              )}
              <button
                onClick={onOpenFundiPortal}
                className="flex items-center gap-1.5 bg-emerald-800 border border-emerald-700 hover:bg-emerald-700 text-emerald-100 font-bold px-2.5 py-1.5 rounded-xl text-xs transition-all active:scale-95 cursor-pointer"
              >
                <span>New Register</span>
              </button>
            </div>
          )}

          {(currentRole === 'seller' || currentRole === 'customer') && (
            <button
              onClick={onOpenSellerPortal}
              className="flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 text-emerald-950 font-bold px-3 py-1.5 rounded-xl text-xs transition-all shadow-md active:scale-95 cursor-pointer"
            >
              <PlusCircle size={15} />
              <span>Post Item / Car</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
