import React, { useState } from 'react';
import { X, ShieldCheck, UserCheck, AlertTriangle, CheckCircle2, Lock, FileText, Search, Shield, Building2, ExternalLink } from 'lucide-react';
import { ServiceProvider, ServiceVettingInfo } from '../types';

interface DigitalVettingModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetProvider?: ServiceProvider | null;
  onVettingComplete?: (providerId: string, vettingInfo: ServiceVettingInfo) => void;
}

const SAMPLE_VETTING_DATA = [
  {
    name: 'Dennis Mwangi (Master Plumber & Pipefitter)',
    idNo: '33891024',
    goodConductNo: 'DCI-CID-2026-992014',
    licenceNo: 'TVET-PLM-881920',
    clearance: 'CLEARED_NO_RECORD' as const
  },
  {
    name: 'John Kamau (Heavy Lorry Haulage Driver)',
    idNo: '28910482',
    goodConductNo: 'DCI-CID-2026-771829',
    licenceNo: 'NTSA-PSV-HEAVY-002190',
    clearance: 'CLEARED_NO_RECORD' as const
  },
  {
    name: 'Peter Ochieng (Master Auto Mechanic & Electrician)',
    idNo: '31209381',
    goodConductNo: 'DCI-CID-2026-663810',
    licenceNo: 'TVET-AUTO-992104',
    clearance: 'CLEARED_NO_RECORD' as const
  }
];

export const DigitalVettingModal: React.FC<DigitalVettingModalProps> = ({
  isOpen,
  onClose,
  targetProvider,
  onVettingComplete
}) => {
  const [nationalId, setNationalId] = useState(targetProvider?.vettingInfo?.nationalIdNo || '33891024');
  const [goodConductCert, setGoodConductCert] = useState(targetProvider?.vettingInfo?.goodConductCertNo || 'DCI-CID-2026-992014');
  const [tradeLicence, setTradeLicence] = useState(targetProvider?.vettingInfo?.tradeLicenceNo || 'TVET-CERT-2026-881920');

  const [isSearching, setIsSearching] = useState(false);
  const [searchStep, setSearchStep] = useState('');
  const [vettingResult, setVettingResult] = useState<ServiceVettingInfo | null>(
    targetProvider?.vettingInfo || null
  );

  if (!isOpen) return null;

  const handleStartVetting = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nationalId.trim()) return;

    setIsSearching(true);
    setSearchStep('Connecting to Republic of Kenya IPRS (Integrated Population Registration System)...');

    setTimeout(() => {
      setSearchStep('Verifying National Identity Card against Criminal Registry Database...');
    }, 700);

    setTimeout(() => {
      setSearchStep('Cross-checking DCI Police Clearance Certificate of Good Conduct...');
    }, 1400);

    setTimeout(() => {
      setSearchStep('Validating TVET / NTSA Trade Accreditation...');
    }, 2100);

    setTimeout(() => {
      setIsSearching(false);
      const result: ServiceVettingInfo = {
        isVetted: true,
        nationalIdNo: nationalId.trim(),
        iprsVerified: true,
        goodConductCertNo: goodConductCert.trim() || `DCI-CID-2026-${Math.floor(100000 + Math.random() * 900000)}`,
        dciVerified: true,
        tradeLicenceNo: tradeLicence.trim() || `NTSA-TVET-2026-${Math.floor(100000 + Math.random() * 900000)}`,
        vettingDate: new Date().toISOString().split('T')[0],
        clearanceStatus: 'CLEARED_NO_RECORD'
      };
      setVettingResult(result);
    }, 2800);
  };

  const handleApplyVetting = () => {
    if (targetProvider && vettingResult && onVettingComplete) {
      onVettingComplete(targetProvider.id, vettingResult);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-stone-200 overflow-hidden my-6 animate-in fade-in zoom-in-95">
        
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-stone-900 p-5 text-white flex items-center justify-between border-b border-emerald-800">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-400 text-emerald-950 flex items-center justify-center font-black shadow-lg">
              <ShieldCheck size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-black text-lg text-white tracking-tight">Service Provider Digital Anti-Scam Vetting</h2>
                <span className="bg-amber-400 text-emerald-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
                  IPRS & DCI Check
                </span>
              </div>
              <p className="text-xs text-emerald-200 mt-0.5">
                Verify National ID, DCI Police Good Conduct & Trade Accreditation
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-stone-300 hover:text-white bg-white/10 hover:bg-white/20 rounded-full transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-5">
          {/* Target Provider Banner */}
          {targetProvider && (
            <div className="bg-stone-50 p-3.5 rounded-2xl border border-stone-200 flex items-center gap-3">
              <img
                src={targetProvider.avatar}
                alt={targetProvider.name}
                className="w-12 h-12 rounded-xl object-cover border-2 border-emerald-800"
              />
              <div>
                <span className="text-[10px] font-extrabold text-emerald-800 uppercase tracking-wider block">
                  VETTING SUBJECT
                </span>
                <h3 className="font-black text-stone-900 text-sm">{targetProvider.name}</h3>
                <p className="text-xs text-stone-500 font-semibold">{targetProvider.tradeSkill} • {targetProvider.phone}</p>
              </div>
            </div>
          )}

          {/* If Result Exists, Display Official Digital Clearance Badge */}
          {vettingResult ? (
            <div className="space-y-5">
              <div className="bg-gradient-to-br from-stone-900 via-emerald-950 to-stone-900 rounded-3xl p-6 text-white border-2 border-amber-400 shadow-xl space-y-4 relative overflow-hidden">
                <div className="flex items-center justify-between border-b border-emerald-800 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-2xl bg-amber-400 text-emerald-950 font-black flex items-center justify-center text-lg shadow-md">
                      🇰🇪
                    </div>
                    <div>
                      <span className="text-[9px] font-extrabold text-amber-300 uppercase tracking-widest block">
                        DCI & IPRS KENYA GOVERNMENT
                      </span>
                      <h3 className="text-base font-black text-white">Digital Security Clearance Certificate</h3>
                    </div>
                  </div>

                  <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 px-2.5 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                    <ShieldCheck size={14} className="text-emerald-400" /> PASSED NO RECORD
                  </span>
                </div>

                {/* Grid details */}
                <div className="grid grid-cols-2 gap-3 bg-white/5 p-4 rounded-2xl border border-white/10 text-xs">
                  <div>
                    <span className="text-[10px] text-emerald-200 font-bold block uppercase">National ID (IPRS)</span>
                    <span className="text-amber-300 font-mono font-extrabold text-sm">{vettingResult.nationalIdNo}</span>
                  </div>

                  <div>
                    <span className="text-[10px] text-emerald-200 font-bold block uppercase">DCI Good Conduct Cert</span>
                    <span className="text-white font-mono font-bold text-xs">{vettingResult.goodConductCertNo}</span>
                  </div>

                  <div>
                    <span className="text-[10px] text-emerald-200 font-bold block uppercase">Trade Accreditation</span>
                    <span className="text-white font-mono font-bold text-xs">{vettingResult.tradeLicenceNo || 'NTSA / TVET Certified'}</span>
                  </div>

                  <div>
                    <span className="text-[10px] text-emerald-200 font-bold block uppercase">Clearance Status</span>
                    <span className="text-emerald-400 font-extrabold">AUTHENTICATED • NO SCAM RECORD</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] text-emerald-200 border-t border-emerald-800/80 pt-2">
                  <span className="flex items-center gap-1">
                    <Lock size={12} className="text-amber-400" /> Vetted Date: <strong>{vettingResult.vettingDate}</strong>
                  </span>
                  <span className="text-amber-300 font-bold">
                    🛡️ GLOBALLICA Scam-Free Guarantee
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setVettingResult(null)}
                  className="px-4 py-2.5 rounded-xl border border-stone-300 text-stone-700 font-bold text-xs hover:bg-stone-100 transition-colors cursor-pointer"
                >
                  Run Another ID Lookup
                </button>

                <button
                  type="button"
                  onClick={handleApplyVetting}
                  className="px-6 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-black text-xs flex items-center gap-2 shadow-lg transition-transform active:scale-95 cursor-pointer"
                >
                  <ShieldCheck size={16} className="text-amber-300" />
                  <span>Attach Verified Vetting Badge</span>
                </button>
              </div>
            </div>
          ) : isSearching ? (
            /* Loading Step State */
            <div className="py-12 text-center space-y-4">
              <div className="relative w-20 h-20 mx-auto">
                <div className="absolute inset-0 rounded-full border-4 border-emerald-200 border-t-emerald-700 animate-spin"></div>
                <div className="absolute inset-2 rounded-full bg-emerald-950 text-amber-400 flex items-center justify-center font-black text-2xl shadow-inner">
                  🇰🇪
                </div>
              </div>

              <div className="space-y-1">
                <h3 className="font-extrabold text-stone-900 text-base">Performing Digital Anti-Scam Vetting</h3>
                <p className="text-xs text-emerald-800 font-semibold animate-pulse">{searchStep}</p>
                <p className="text-[11px] text-stone-400">Authenticating with Kenyan Government Registries...</p>
              </div>
            </div>
          ) : (
            /* Vetting Form */
            <form onSubmit={handleStartVetting} className="space-y-4">
              <div>
                <label htmlFor="vetting-id-number" className="block text-stone-800 font-bold mb-1 text-xs">
                  Kenyan National ID Number (IPRS Registry) *
                </label>
                <input
                  id="vetting-id-number"
                  name="nationalId"
                  type="text"
                  required
                  value={nationalId}
                  onChange={(e) => setNationalId(e.target.value)}
                  placeholder="e.g. 33891024"
                  className="w-full bg-stone-50 border border-stone-200 rounded-xl p-3 text-stone-900 font-mono text-sm tracking-wider"
                />
              </div>

              <div>
                <label htmlFor="vetting-dci-cert" className="block text-stone-800 font-bold mb-1 text-xs">
                  DCI Police Clearance / Certificate of Good Conduct Ref No.
                </label>
                <input
                  id="vetting-dci-cert"
                  name="goodConductCert"
                  type="text"
                  value={goodConductCert}
                  onChange={(e) => setGoodConductCert(e.target.value)}
                  placeholder="e.g. DCI-CID-2026-992014"
                  className="w-full bg-stone-50 border border-stone-200 rounded-xl p-3 text-stone-900 font-mono text-xs"
                />
              </div>

              <div>
                <label htmlFor="vetting-trade-licence" className="block text-stone-800 font-bold mb-1 text-xs">
                  Trade / NTSA PSV / TVET Certification Ref No. (Optional)
                </label>
                <input
                  id="vetting-trade-licence"
                  name="tradeLicence"
                  type="text"
                  value={tradeLicence}
                  onChange={(e) => setTradeLicence(e.target.value)}
                  placeholder="e.g. NTSA-PSV-2026-881902"
                  className="w-full bg-stone-50 border border-stone-200 rounded-xl p-3 text-stone-900 font-mono text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-emerald-800 hover:bg-emerald-900 text-white font-black text-xs py-3.5 rounded-xl shadow-lg transition-transform active:scale-98 flex items-center justify-center gap-2 cursor-pointer"
              >
                <ShieldCheck size={16} className="text-amber-300" />
                <span>Run Instant Digital Vetting Check</span>
              </button>

              {/* Sample Profiles for Quick Testing */}
              <div className="pt-3 border-t border-stone-200 space-y-2">
                <span className="text-[11px] font-extrabold text-stone-700 uppercase tracking-wider block">
                  🧪 Test Instant Vetting Data Samples:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {SAMPLE_VETTING_DATA.map((sample, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setNationalId(sample.idNo);
                        setGoodConductCert(sample.goodConductNo);
                        setTradeLicence(sample.licenceNo);
                      }}
                      className="text-left bg-stone-50 hover:bg-amber-50/80 border border-stone-200 hover:border-amber-300 p-2 rounded-xl transition-all cursor-pointer group"
                    >
                      <span className="text-xs font-bold text-stone-900 group-hover:text-emerald-900 block truncate">
                        {sample.name}
                      </span>
                      <span className="text-[10px] text-stone-500 font-mono block">
                        ID: {sample.idNo}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
