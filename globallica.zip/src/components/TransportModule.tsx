import React, { useState } from 'react';
import { ServiceProvider } from '../types';
import { Truck, Car, PhoneCall, MessageSquare, ShieldCheck, MapPin, Star, UserCheck, CheckCircle, Clock, Zap, PlusCircle, Filter, Eye, Camera, Images, Package, ShieldAlert, QrCode } from 'lucide-react';
import { KENYAN_LOCATIONS, calculateDistanceKm } from '../data/locations';
import { getTradeSkillPhoto } from '../utils/categoryImages';

interface TransportModuleProps {
  providers: ServiceProvider[];
  selectedEstate: string;
  selectedCounty: string;
  onOpenDriverPortal: () => void;
  onOpenMediaPortal?: () => void;
  onOpenNtsaVerification?: () => void;
  onOpenDigitalVetting?: (provider?: ServiceProvider) => void;
  onOpenEscrowTracker?: (provider?: ServiceProvider) => void;
  onBookTransportMpesa: (provider: ServiceProvider) => void;
  onSelectProvider?: (provider: ServiceProvider) => void;
}

export const TransportModule: React.FC<TransportModuleProps> = ({
  providers,
  selectedEstate,
  selectedCounty,
  onOpenDriverPortal,
  onOpenMediaPortal,
  onOpenNtsaVerification,
  onOpenDigitalVetting,
  onOpenEscrowTracker,
  onBookTransportMpesa,
  onSelectProvider
}) => {
  const [selectedSubCategory, setSelectedSubCategory] = useState<string>('all');
  const [availableOnly, setAvailableOnly] = useState<boolean>(false);

  // Filter transport providers (Cab, Lorry, BodaBoda, Movers)
  const isTransportSkill = (skill: string) => {
    return (
      skill === 'Cab / Taxi Ride (Uber Style)' ||
      skill === 'Lorry / Truck For Hire' ||
      skill === 'BodaBoda / Delivery' ||
      skill === 'Movers'
    );
  };

  const transportProviders = providers.filter(p => isTransportSkill(p.tradeSkill));

  // Determine lat/lng for distance calculation
  let searchLat = -1.2891;
  let searchLng = 36.7886;

  if (selectedEstate !== 'all') {
    for (const countyObj of KENYAN_LOCATIONS) {
      for (const constObj of countyObj.constituencies) {
        const foundEstate = constObj.estates.find(e => e.name === selectedEstate);
        if (foundEstate) {
          searchLat = foundEstate.lat;
          searchLng = foundEstate.lng;
          break;
        }
      }
    }
  }

  const providersWithDistance = transportProviders.map(p => ({
    ...p,
    distanceKm: calculateDistanceKm(searchLat, searchLng, p.latitude, p.longitude)
  }));

  const filtered = providersWithDistance.filter(p => {
    if (selectedSubCategory !== 'all' && p.tradeSkill !== selectedSubCategory) return false;
    if (availableOnly && p.availability !== 'Available Now') return false;
    if (selectedCounty !== 'all') {
      const normSel = selectedCounty.replace(/^\d+:\s*/, '').trim().toLowerCase();
      const normCounty = (p.operationalCounty || '').replace(/^\d+:\s*/, '').trim().toLowerCase();
      if (normCounty !== normSel && !normCounty.includes(normSel) && !normSel.includes(normCounty)) return false;
    }
    if (selectedEstate !== 'all') {
      if ((p.operationalEstate || '').toLowerCase() !== selectedEstate.toLowerCase()) return false;
    }
    return true;
  });

  return (
    <div className="w-full max-w-full space-y-6">
      {/* Banner Header */}
      <div className="w-full max-w-full bg-gradient-to-r from-emerald-950 via-emerald-900 to-stone-900 rounded-3xl p-5 sm:p-8 text-white shadow-xl relative overflow-hidden border border-emerald-800">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-amber-400/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-3xl space-y-2">
          <div className="inline-flex items-center gap-1.5 bg-amber-400/20 text-amber-300 border border-amber-400/30 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
            <Truck size={14} className="text-amber-400" />
            <span>Transport, Uber-Style Cabs & Lorries For Hire</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Cabs, Uber Rides & Heavy Lorries in {selectedEstate !== 'all' ? selectedEstate : 'Your Area'}
          </h2>

          <p className="text-emerald-200 text-xs sm:text-sm leading-relaxed">
            Need an executive AC taxi ride to JKIA or SGR? Or a 3-Ton/10-Ton lorry with loaders to move house or deliver construction materials? Book verified Kenyan transport drivers with instant M-Pesa fare calculation.
          </p>

          <div className="pt-2 flex flex-wrap gap-3">
            {onOpenDigitalVetting && (
              <button
                onClick={() => onOpenDigitalVetting()}
                className="bg-emerald-800 hover:bg-emerald-700 text-amber-300 font-extrabold px-3.5 py-2.5 rounded-xl text-xs flex items-center gap-2 border border-amber-400/50 shadow transition-all cursor-pointer"
              >
                <ShieldCheck size={16} className="text-amber-300" />
                <span>Driver Digital Vetting Check</span>
              </button>
            )}

            {onOpenEscrowTracker && (
              <button
                onClick={() => onOpenEscrowTracker()}
                className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black px-3.5 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-lg transition-transform active:scale-95 cursor-pointer"
              >
                <ShieldCheck size={16} />
                <span>Escrow Trip Payments</span>
              </button>
            )}

            <button
              onClick={onOpenDriverPortal}
              className="bg-stone-900 hover:bg-black text-white font-extrabold px-3.5 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow transition-all cursor-pointer"
            >
              <PlusCircle size={16} />
              <span>List Your Lorry / Cab</span>
            </button>

            {onOpenNtsaVerification && (
              <button
                onClick={onOpenNtsaVerification}
                className="bg-stone-900 hover:bg-black text-amber-300 font-extrabold px-3.5 py-2.5 rounded-xl text-xs flex items-center gap-2 border border-amber-400/50 shadow transition-all cursor-pointer"
              >
                <QrCode size={15} className="text-amber-400" />
                <span>Logbook QR Scanner</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Sub-Category Filter Bar */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-stone-200 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-bold text-stone-700 flex items-center gap-1">
            <Filter size={14} className="text-emerald-700" />
            Transport Type:
          </span>

          <button
            onClick={() => setSelectedSubCategory('all')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              selectedSubCategory === 'all'
                ? 'bg-emerald-800 text-white shadow-sm'
                : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
            }`}
          >
            All Transport ({transportProviders.length})
          </button>

          <button
            onClick={() => setSelectedSubCategory('Cab / Taxi Ride (Uber Style)')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              selectedSubCategory === 'Cab / Taxi Ride (Uber Style)'
                ? 'bg-emerald-800 text-white shadow-sm'
                : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
            }`}
          >
            <Car size={14} className="text-amber-500" />
            <span>🚖 Uber Cabs & Taxis</span>
          </button>

          <button
            onClick={() => setSelectedSubCategory('Lorry / Truck For Hire')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              selectedSubCategory === 'Lorry / Truck For Hire'
                ? 'bg-emerald-800 text-white shadow-sm'
                : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
            }`}
          >
            <Truck size={14} className="text-amber-500" />
            <span>🚛 Lorries & Trucks</span>
          </button>

          <button
            onClick={() => setSelectedSubCategory('Movers')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              selectedSubCategory === 'Movers'
                ? 'bg-emerald-800 text-white shadow-sm'
                : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
            }`}
          >
            <Package size={14} className="text-amber-500" />
            <span>📦 House Movers</span>
          </button>

          <button
            onClick={() => setSelectedSubCategory('BodaBoda / Delivery')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              selectedSubCategory === 'BodaBoda / Delivery'
                ? 'bg-emerald-800 text-white shadow-sm'
                : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
            }`}
          >
            <span>🛵 Boda Riders</span>
          </button>
        </div>

        <label htmlFor="transport-availability-only" className="flex items-center gap-2 text-xs font-bold text-stone-700 cursor-pointer">
          <input
            id="transport-availability-only"
            name="availableOnly"
            aria-label="Available Now Drivers Only"
            type="checkbox"
            checked={availableOnly}
            onChange={(e) => setAvailableOnly(e.target.checked)}
            className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
          />
          <span>Available Now Only</span>
        </label>
      </div>

      {/* Grid of Transport Drivers */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-3xl p-10 text-center border border-stone-200 shadow-sm space-y-3">
          <div className="w-16 h-16 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center mx-auto text-2xl font-black">
            🚛
          </div>
          <h3 className="text-lg font-extrabold text-stone-800">No Transport Drivers Found Match Filter</h3>
          <p className="text-xs text-stone-500 max-w-md mx-auto">
            Try resetting your sub-category filter or selecting a broader county area to view available Lorries and Cabs.
          </p>
          <button
            onClick={() => {
              setSelectedSubCategory('all');
              setAvailableOnly(false);
            }}
            className="bg-emerald-800 text-white text-xs font-bold px-4 py-2 rounded-xl hover:bg-emerald-900 transition-colors"
          >
            Show All Transport Drivers
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((provider) => {
            const isCab = provider.tradeSkill === 'Cab / Taxi Ride (Uber Style)';
            const isLorry = provider.tradeSkill === 'Lorry / Truck For Hire';

            return (
              <div
                key={provider.id}
                className="bg-white rounded-3xl border border-stone-200 shadow-sm hover:shadow-md transition-all overflow-hidden flex flex-col justify-between group"
              >
                <div>
                  {/* Top Header Card */}
                  <div className="p-4 bg-stone-50/80 border-b border-stone-100 flex items-start gap-3">
                    <img
                      src={provider.avatar}
                      alt={provider.name}
                      className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-600 shrink-0 shadow-sm"
                    />

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-extrabold text-stone-900 text-sm truncate">
                          {provider.name}
                        </span>
                        {provider.isVerified && (
                          <span className="inline-flex items-center gap-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold px-1.5 py-0.2 rounded-full shrink-0">
                            <ShieldCheck size={10} className="text-emerald-700" /> Verified
                          </span>
                        )}
                        <span className="inline-flex items-center gap-0.5 bg-amber-100 text-amber-900 border border-amber-300 text-[9px] font-black px-1.5 py-0.2 rounded-full shrink-0">
                          <QrCode size={9} className="text-amber-700" /> NTSA LOGBOOK
                        </span>
                      </div>

                      <div className="flex items-center gap-2 mt-1">
                        <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-md ${
                          isCab
                            ? 'bg-amber-100 text-amber-900 border border-amber-200'
                            : isLorry
                            ? 'bg-blue-100 text-blue-900 border border-blue-200'
                            : 'bg-emerald-100 text-emerald-900 border border-emerald-200'
                        }`}>
                          {isCab ? '🚖 Cab / Uber Taxi' : isLorry ? '🚛 Lorry / Truck For Hire' : provider.tradeSkill}
                        </span>

                        <div className="flex items-center gap-1 text-amber-500 text-xs font-bold">
                          <Star size={12} className="fill-amber-400 text-amber-400" />
                          <span>{provider.rating.toFixed(1)}</span>
                          <span className="text-stone-400 text-[10px]">({provider.reviewsCount})</span>
                        </div>
                      </div>

                      <p className="text-[11px] text-stone-500 font-medium flex items-center gap-1 mt-1">
                        <MapPin size={11} className="text-emerald-700 shrink-0" />
                        <span>{provider.operationalEstate}, {provider.operationalCounty}</span>
                        {provider.distanceKm !== undefined && (
                          <span className="text-emerald-700 font-bold ml-1">
                            ({provider.distanceKm.toFixed(1)} km away)
                          </span>
                        )}
                      </p>
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-4 space-y-3">
                    {/* Digital Vetting Badge */}
                    {provider.vettingInfo?.isVetted ? (
                      <div className="bg-emerald-950 text-amber-300 p-2 rounded-xl text-[10px] font-extrabold flex items-center justify-between border border-emerald-700">
                        <span className="flex items-center gap-1">
                          <ShieldCheck size={12} className="text-amber-300" />
                          <span>🛡️ DCI Police & IPRS ID Cleared Driver</span>
                        </span>
                        <span className="font-mono">ID: {provider.vettingInfo.nationalIdNo}</span>
                      </div>
                    ) : onOpenDigitalVetting && (
                      <button
                        type="button"
                        onClick={() => onOpenDigitalVetting(provider)}
                        className="w-full bg-stone-900 hover:bg-black text-amber-300 p-2 rounded-xl text-[10px] font-bold flex items-center justify-between border border-stone-700 cursor-pointer"
                      >
                        <span className="flex items-center gap-1">
                          <ShieldCheck size={12} className="text-amber-400" /> Driver Anti-Scam Vetting Check
                        </span>
                        <span className="bg-amber-400 text-stone-950 px-1.5 py-0.2 rounded font-black">
                          Vet Now
                        </span>
                      </button>
                    )}

                    <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                      {provider.bio}
                    </p>

                    {/* Vehicle / Service Features Badges */}
                    <div className="flex flex-wrap gap-1">
                      {provider.skillsList.slice(0, 3).map((skill, sIdx) => (
                        <span
                          key={sIdx}
                          className="bg-stone-100 text-stone-700 text-[10px] font-semibold px-2 py-0.5 rounded-md border border-stone-200/60"
                        >
                          ✓ {skill}
                        </span>
                      ))}
                    </div>

                    {/* Vehicle Portfolio Preview image if present */}
                    {provider.portfolioShowcase && provider.portfolioShowcase.length > 0 && (
                      <div className="relative rounded-2xl overflow-hidden h-36 border border-stone-200 bg-stone-100 group/img">
                        <img
                          src={provider.portfolioShowcase[0].photoUrl || getTradeSkillPhoto(provider.tradeSkill)}
                          alt={provider.portfolioShowcase[0].title}
                          className="w-full h-full object-cover group-hover/img:scale-105 transition-transform duration-300"
                          onError={(e) => {
                            e.currentTarget.src = getTradeSkillPhoto(provider.tradeSkill);
                          }}
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent flex items-end p-2.5">
                          <span className="text-[10px] font-bold text-white truncate">
                            📷 {provider.portfolioShowcase[0].title}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Rate & Status Bar */}
                    <div className="bg-stone-50 border border-stone-200 rounded-xl p-2.5 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-stone-500 font-bold uppercase block">
                          Estimated Rate
                        </span>
                        <span className="text-stone-900 font-black text-sm">
                          KES {provider.rateKES.toLocaleString()}{' '}
                          <span className="text-[10px] text-stone-500 font-normal">
                            / {provider.pricingModel}
                          </span>
                        </span>
                      </div>

                      <div className="text-right">
                        <span className={`inline-flex items-center gap-1 text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                          provider.availability === 'Available Now'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          <Zap size={10} className={provider.availability === 'Available Now' ? 'text-emerald-600 fill-emerald-600' : 'text-amber-600'} />
                          {provider.availability}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Footer Actions */}
                <div className="p-4 pt-0 gap-2 flex flex-col">
                  <div className="grid grid-cols-2 gap-2">
                    <a
                      href={`tel:${provider.phone}`}
                      className="bg-emerald-800 hover:bg-emerald-900 text-white font-extrabold text-xs py-2 rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <PhoneCall size={13} />
                      <span>Call Driver</span>
                    </a>

                    <a
                      href={`https://wa.me/${provider.whatsapp}?text=${encodeURIComponent(
                        `Jambo ${provider.name}, I found your ${provider.tradeSkill} listing on GLOBALLICA Kenya. Are you available for transport in ${selectedEstate !== 'all' ? selectedEstate : provider.operationalEstate}?`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs py-2 rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <MessageSquare size={13} />
                      <span>WhatsApp</span>
                    </a>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    {onOpenEscrowTracker ? (
                      <button
                        onClick={() => onOpenEscrowTracker(provider)}
                        className="bg-emerald-950 hover:bg-emerald-900 text-amber-300 font-extrabold text-xs py-2 rounded-xl flex items-center justify-center gap-1 transition-all border border-emerald-700 shadow-sm cursor-pointer"
                      >
                        <span>🔒 Escrow Ride</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => onBookTransportMpesa(provider)}
                        className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black text-xs py-2 rounded-xl flex items-center justify-center gap-1 transition-all shadow-sm cursor-pointer"
                      >
                        <span>💚 Book Fare</span>
                      </button>
                    )}

                    <button
                      onClick={() => onSelectProvider && onSelectProvider(provider)}
                      className="bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-xs py-2 rounded-xl flex items-center justify-center gap-1 transition-colors cursor-pointer"
                    >
                      <Eye size={13} />
                      <span>Details & Portfolio</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
