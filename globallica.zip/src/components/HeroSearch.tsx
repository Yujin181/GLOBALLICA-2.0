import React from 'react';
import { Search, MapPin, Filter, Home, Wrench, Truck, Car, Package, Sparkles } from 'lucide-react';
import { KENYAN_LOCATIONS } from '../data/locations';

interface HeroSearchProps {
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  selectedCounty: string;
  setSelectedCounty: (county: string) => void;
  selectedConstituency: string;
  setSelectedConstituency: (constituency: string) => void;
  selectedEstate: string;
  setSelectedEstate: (estate: string) => void;
  activeCategory: string;
  setActiveCategory: (cat: string) => void;
  totalListingsCount: number;
}

export const HeroSearch: React.FC<HeroSearchProps> = ({
  searchQuery,
  setSearchQuery,
  selectedCounty,
  setSelectedCounty,
  selectedConstituency,
  setSelectedConstituency,
  selectedEstate,
  setSelectedEstate,
  activeCategory,
  setActiveCategory,
  totalListingsCount
}) => {
  // Find current county object
  const currentCountyObj = KENYAN_LOCATIONS.find(l => l.county === selectedCounty);
  const constituencies = currentCountyObj ? currentCountyObj.constituencies : [];

  // Find current constituency object
  const currentConstituencyObj = constituencies.find(c => c.name === selectedConstituency);
  const estates = currentConstituencyObj ? currentConstituencyObj.estates : [];

  const handleCountyChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    setSelectedCounty(val);
    setSelectedConstituency('all');
    setSelectedEstate('all');
  };

  const handleConstituencyChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    setSelectedConstituency(val);
    setSelectedEstate('all');
  };

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCounty('all');
    setSelectedConstituency('all');
    setSelectedEstate('all');
    setActiveCategory('all');
  };

  return (
    <div className="w-full max-w-full bg-gradient-to-b from-emerald-900 via-emerald-850 to-emerald-950 text-white py-6 px-3 sm:px-6 lg:px-8 border-b border-emerald-800">
      <div className="w-full max-w-full mx-auto">
        {/* Hero Title */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 bg-emerald-800/80 text-amber-300 px-3 py-1 rounded-full text-xs font-semibold mb-3 border border-emerald-700">
            <Sparkles size={13} />
            <span>Kenyan Hyper-Local Marketplace & Service Finder</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
            What or Where Are You Looking For? <span className="text-amber-400 font-serif italic">GLOBALLICA.</span>
          </h1>
          <p className="text-emerald-200 text-xs sm:text-sm mt-1 max-w-2xl mx-auto">
            Find vacant houses, verified caretaker numbers, Uber-style cabs, lorries for hire, local fundis (plumbers, electricians, mechanics) & cars in Kilimani, Mirema, Pipeline, Roysambu, Nyali, Nakuru & across Kenya.
          </p>
        </div>

        {/* Main Search Card */}
        <div className="bg-white rounded-2xl p-3 sm:p-4 shadow-2xl text-stone-900 border border-emerald-100">
          {/* Top Search Input */}
          <div className="relative mb-3">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-emerald-700">
              <Search size={18} />
            </div>
            <input
              id="hero-search-query"
              name="searchQuery"
              aria-label="Search listings by keyword"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder='e.g., "Lorry for hire", "Uber cab ride", "2BR Mirema", "Plumber Roysambu", "Electrician"'
              className="w-full pl-10 pr-10 py-3 bg-stone-50 rounded-xl border border-stone-200 text-stone-900 placeholder:text-stone-400 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white transition-all font-medium"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-stone-400 hover:text-stone-600 text-xs font-bold"
              >
                Clear
              </button>
            )}
          </div>

          {/* Cascading Location Selectors: County -> Constituency -> Ward/Estate */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 mb-3">
            {/* 1. County Selector */}
            <div>
              <label htmlFor="hero-county-select" className="block text-[11px] font-bold text-stone-600 mb-1 flex items-center gap-1">
                <MapPin size={12} className="text-emerald-600" />
                1. County
              </label>
              <select
                id="hero-county-select"
                name="selectedCounty"
                aria-label="Select County"
                value={selectedCounty}
                onChange={handleCountyChange}
                className="w-full bg-stone-50 border border-stone-200 rounded-lg p-2 text-xs font-semibold text-stone-800 focus:outline-none focus:ring-2 focus:ring-emerald-600 cursor-pointer"
              >
                <option value="all">All Counties (Kenya)</option>
                {KENYAN_LOCATIONS.map(loc => (
                  <option key={loc.county} value={loc.county}>
                    {loc.county}
                  </option>
                ))}
              </select>
            </div>

            {/* 2. Constituency Selector */}
            <div>
              <label htmlFor="hero-constituency-select" className="block text-[11px] font-bold text-stone-600 mb-1 flex items-center gap-1">
                <Filter size={12} className="text-emerald-600" />
                2. Constituency
              </label>
              <select
                id="hero-constituency-select"
                name="selectedConstituency"
                aria-label="Select Constituency"
                value={selectedConstituency}
                onChange={handleConstituencyChange}
                disabled={selectedCounty === 'all'}
                className="w-full bg-stone-50 border border-stone-200 rounded-lg p-2 text-xs font-semibold text-stone-800 focus:outline-none focus:ring-2 focus:ring-emerald-600 disabled:opacity-50 cursor-pointer"
              >
                <option value="all">All Constituencies</option>
                {constituencies.map(c => (
                  <option key={c.name} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            {/* 3. Ward / Estate Selector */}
            <div>
              <label htmlFor="hero-estate-select" className="block text-[11px] font-bold text-stone-600 mb-1 flex items-center gap-1">
                <MapPin size={12} className="text-amber-600" />
                3. Ward / Estate
              </label>
              <select
                id="hero-estate-select"
                name="selectedEstate"
                aria-label="Select Estate or Ward"
                value={selectedEstate}
                onChange={(e) => setSelectedEstate(e.target.value)}
                disabled={selectedConstituency === 'all'}
                className="w-full bg-stone-50 border border-stone-200 rounded-lg p-2 text-xs font-semibold text-stone-800 focus:outline-none focus:ring-2 focus:ring-emerald-600 disabled:opacity-50 cursor-pointer"
              >
                <option value="all">All Estates / Wards</option>
                {estates.map(e => (
                  <option key={e.name} value={e.name}>
                    {e.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Category Quick Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none border-t border-stone-100 pt-3">
            <span className="text-[11px] font-bold text-stone-500 whitespace-nowrap">Categories:</span>

            <button
              onClick={() => setActiveCategory('all')}
              className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                activeCategory === 'all'
                  ? 'bg-emerald-800 text-white shadow'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              All Listings
            </button>

            <button
              onClick={() => setActiveCategory('housing')}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                activeCategory === 'housing'
                  ? 'bg-emerald-800 text-white shadow'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              <Home size={13} className="text-amber-500" />
              <span>Housing & Rentals</span>
            </button>

            <button
              onClick={() => setActiveCategory('services')}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                activeCategory === 'services'
                  ? 'bg-emerald-800 text-white shadow'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              <Wrench size={13} className="text-amber-500" />
              <span>Fundi Directory</span>
            </button>

            <button
              onClick={() => setActiveCategory('transport')}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                activeCategory === 'transport'
                  ? 'bg-emerald-800 text-white shadow'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              <Truck size={13} className="text-amber-500" />
              <span>Transport & Cabs</span>
            </button>

            <button
              onClick={() => setActiveCategory('vehicles')}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                activeCategory === 'vehicles'
                  ? 'bg-emerald-800 text-white shadow'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              <Car size={13} className="text-amber-500" />
              <span>Cars & Vehicles</span>
            </button>

            <button
              onClick={() => setActiveCategory('products')}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                activeCategory === 'products'
                  ? 'bg-emerald-800 text-white shadow'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              <Package size={13} className="text-amber-500" />
              <span>General Goods</span>
            </button>

            {(searchQuery || selectedCounty !== 'all' || selectedConstituency !== 'all' || selectedEstate !== 'all' || activeCategory !== 'all') && (
              <button
                onClick={clearFilters}
                className="ml-auto text-xs text-amber-600 font-bold hover:underline whitespace-nowrap cursor-pointer"
              >
                Reset Filters
              </button>
            )}
          </div>
        </div>

        {/* Popular Estate Chips in Kenya */}
        <div className="flex items-center gap-1.5 mt-3 text-[11px] text-emerald-200 overflow-x-auto whitespace-nowrap scrollbar-none">
          <span className="font-bold text-amber-300">Hot Estates:</span>
          {['Kilimani', 'Mirema', 'Pipeline', 'Roysambu', 'Ruaka', 'Nyali', 'Milimani Nakuru'].map(estate => (
            <button
              key={estate}
              onClick={() => {
                setSearchQuery(estate);
              }}
              className="bg-emerald-800/60 hover:bg-emerald-800 text-emerald-100 px-2 py-0.5 rounded-md border border-emerald-700/60 transition-colors cursor-pointer"
            >
              📍 {estate}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
