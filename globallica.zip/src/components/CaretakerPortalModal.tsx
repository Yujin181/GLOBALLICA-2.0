import React, { useState } from 'react';
import { X, Home, ShieldCheck, Upload, CheckCircle2, DollarSign, MapPin } from 'lucide-react';
import { HousingListing } from '../types';
import { KENYAN_LOCATIONS } from '../data/locations';

interface CaretakerPortalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddHousing: (newHouse: HousingListing) => void;
}

export const CaretakerPortalModal: React.FC<CaretakerPortalModalProps> = ({
  isOpen,
  onClose,
  onAddHousing
}) => {
  if (!isOpen) return null;

  const [caretakerName, setCaretakerName] = useState('Mwangi Maina');
  const [caretakerPhone, setCaretakerPhone] = useState('+254712345678');
  const [title, setTitle] = useState('');
  const [houseType, setHouseType] = useState<HousingListing['houseType']>('1 Bedroom');
  const [rentKES, setRentKES] = useState<number>(18000);
  const [depositTerms, setDepositTerms] = useState('1 Month Deposit + KES 1,500 Water & KPLC Token Agreement');
  const [county, setCounty] = useState('Nairobi');
  const [constituency, setConstituency] = useState('Kasarani / Roysambu');
  const [estate, setEstate] = useState('Mirema');
  const [description, setDescription] = useState('');
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([
    'Borehole Water', 'KPLC Token Meter', 'Wi-Fi Ready', 'CCTV Security'
  ]);
  const [photoUrl, setPhotoUrl] = useState('https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=800&q=80');
  const [lrTitleDeedNo, setLrTitleDeedNo] = useState('LR NO. 209/' + Math.floor(10000 + Math.random() * 90000));
  const [ownerName, setOwnerName] = useState('Mwangi Maina Real Estate');

  const availableAmenities = [
    'Borehole Water', 'KPLC Token Meter', 'Wi-Fi Ready', 'CCTV Security',
    'Parking Space', 'Security Guard', 'Balcony', 'Gym', 'Backup Generator'
  ];

  const toggleAmenity = (amenity: string) => {
    if (selectedAmenities.includes(amenity)) {
      setSelectedAmenities(selectedAmenities.filter(a => a !== amenity));
    } else {
      setSelectedAmenities([...selectedAmenities, amenity]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !estate) return;

    const newHouse: HousingListing = {
      id: `house-${Date.now()}`,
      title,
      houseType,
      rentKES: Number(rentKES),
      depositTerms,
      county,
      constituency,
      estate,
      latitude: -1.2120,
      longitude: 36.8910,
      amenities: selectedAmenities,
      photos: photoUrl && photoUrl.trim().length > 0 ? [photoUrl.trim()] : ['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=800&q=80'],
      description: description || 'Clean spacious vacant house ready for immediate move-in.',
      caretaker: {
        id: `ct-${Date.now()}`,
        name: caretakerName,
        phone: caretakerPhone,
        whatsapp: caretakerPhone.replace('+', ''),
        isVerified: true,
        rating: 5.0,
        reviewCount: 1,
        estateBase: estate,
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
        propertiesCount: 1
      },
      status: 'vacant',
      featured: true,
      createdAt: new Date().toISOString().split('T')[0],
      views: 12,
      vettingInfo: lrTitleDeedNo ? {
        isVetted: true,
        lrTitleDeedNo,
        landRegistryStatus: 'ARDHISASA_VERIFIED',
        registeredOwnerName: ownerName || caretakerName,
        geoGpsCoordinatesVerified: true,
        physicalInspectorName: 'Inspector S. Mutua (GLOBALLICA Anti-Scam Team)',
        verifiedAt: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
      } : undefined
    };

    onAddHousing(newHouse);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-stone-200 my-8 space-y-5 animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-900 text-amber-400 flex items-center justify-center font-bold">
              <Home size={22} />
            </div>
            <div>
              <h2 className="font-black text-xl text-stone-900">Landlord & Caretaker Listing Portal</h2>
              <p className="text-xs text-stone-500">List vacant apartments directly to prospective tenants in Kenya</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-full transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs font-semibold">
          {/* Caretaker Info */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="caretaker-name" className="block text-emerald-900 mb-1 font-bold">Caretaker / Landlord Full Name</label>
              <input
                id="caretaker-name"
                name="caretakerName"
                type="text"
                required
                value={caretakerName}
                onChange={(e) => setCaretakerName(e.target.value)}
                placeholder="e.g. Samuel Mwangi"
                className="w-full bg-white border border-emerald-300 rounded-xl p-2.5 text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="caretaker-phone" className="block text-emerald-900 mb-1 font-bold">Phone Number (M-Pesa / WhatsApp +254...)</label>
              <input
                id="caretaker-phone"
                name="caretakerPhone"
                type="text"
                required
                value={caretakerPhone}
                onChange={(e) => setCaretakerPhone(e.target.value)}
                placeholder="+254712345678"
                className="w-full bg-white border border-emerald-300 rounded-xl p-2.5 text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
              />
            </div>
          </div>

          {/* Title */}
          <div>
            <label htmlFor="caretaker-listing-title" className="block text-stone-700 mb-1 font-bold">Listing Title</label>
            <input
              id="caretaker-listing-title"
              name="title"
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Modern 1BR Master En-Suite with Borehole & Balcony"
              className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
            />
          </div>

          {/* Type & Rent */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="caretaker-house-type" className="block text-stone-700 mb-1 font-bold">House Type</label>
              <select
                id="caretaker-house-type"
                name="houseType"
                value={houseType}
                onChange={(e) => setHouseType(e.target.value as any)}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none cursor-pointer"
              >
                <option value="Bedsitter">Bedsitter</option>
                <option value="Single Room">Single Room</option>
                <option value="1 Bedroom">1 Bedroom</option>
                <option value="2 Bedroom">2 Bedroom</option>
                <option value="3 Bedroom">3 Bedroom</option>
                <option value="Maisonette">Maisonette</option>
                <option value="Commercial">Commercial Space</option>
              </select>
            </div>

            <div>
              <label htmlFor="caretaker-rent" className="block text-stone-700 mb-1 font-bold">Monthly Rent (KES)</label>
              <input
                id="caretaker-rent"
                name="rentKES"
                type="number"
                required
                value={rentKES}
                onChange={(e) => setRentKES(Number(e.target.value))}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
              />
            </div>
          </div>

          {/* Location */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label htmlFor="caretaker-county" className="block text-stone-700 mb-1 font-bold">County</label>
              <select
                id="caretaker-county"
                name="county"
                value={county}
                onChange={(e) => setCounty(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900 cursor-pointer"
              >
                {KENYAN_LOCATIONS.map(l => (
                  <option key={l.county} value={l.county}>{l.county}</option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="caretaker-constituency" className="block text-stone-700 mb-1 font-bold">Constituency</label>
              <input
                id="caretaker-constituency"
                name="constituency"
                type="text"
                value={constituency}
                onChange={(e) => setConstituency(e.target.value)}
                placeholder="e.g. Kasarani / Roysambu"
                className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900"
              />
            </div>

            <div>
              <label htmlFor="caretaker-estate" className="block text-stone-700 mb-1 font-bold">Estate / Ward</label>
              <input
                id="caretaker-estate"
                name="estate"
                type="text"
                required
                value={estate}
                onChange={(e) => setEstate(e.target.value)}
                placeholder="e.g. Mirema, Kilimani"
                className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900"
              />
            </div>
          </div>

          {/* Deposit Terms */}
          <div>
            <label htmlFor="caretaker-deposit-terms" className="block text-stone-700 mb-1 font-bold">Deposit Terms & Utility Agreement</label>
            <input
              id="caretaker-deposit-terms"
              name="depositTerms"
              type="text"
              value={depositTerms}
              onChange={(e) => setDepositTerms(e.target.value)}
              placeholder="e.g. 1 Month Rent + KES 2,000 Water & KPLC Deposit"
              className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900"
            />
          </div>

          {/* Anti-Scam Land Title Deed Vetting Section */}
          <div className="bg-emerald-950 text-white p-4 rounded-2xl border border-amber-400/50 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-extrabold text-xs text-amber-300 flex items-center gap-1.5 uppercase">
                <ShieldCheck size={16} className="text-amber-300" />
                🛡️ Digital Title Deed & Ardhisasa Verification
              </span>
              <span className="bg-amber-400 text-emerald-950 text-[10px] font-black px-2 py-0.5 rounded">
                ANTI-SCAM CLEARANCE
              </span>
            </div>
            <p className="text-[11px] text-emerald-200">
              Provide Title Deed / Land Parcel LR number to get an instant "Ardhisasa Vetted" Badge on your listing and build 100% trust with house hunters.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-amber-200 mb-1">
                  Title Deed LR / Block Parcel No:
                </label>
                <input
                  type="text"
                  value={lrTitleDeedNo}
                  onChange={(e) => setLrTitleDeedNo(e.target.value)}
                  placeholder="e.g. LR NO. 209/18290"
                  className="w-full bg-emerald-900/90 border border-emerald-700 rounded-xl p-2 text-xs font-mono font-bold text-amber-300 focus:ring-2 focus:ring-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-amber-200 mb-1">
                  Registered Title Holder / Landlord Name:
                </label>
                <input
                  type="text"
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  placeholder="e.g. Mwangi Maina Properties"
                  className="w-full bg-emerald-900/90 border border-emerald-700 rounded-xl p-2 text-xs font-bold text-white focus:ring-2 focus:ring-amber-400 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Amenities Selector */}
          <div>
            <label className="block text-stone-700 mb-1.5 font-bold">Select House Amenities</label>
            <div className="flex flex-wrap gap-2">
              {availableAmenities.map(amenity => {
                const isSelected = selectedAmenities.includes(amenity);
                return (
                  <button
                    type="button"
                    key={amenity}
                    onClick={() => toggleAmenity(amenity)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                      isSelected
                        ? 'bg-emerald-800 text-white border-emerald-900 shadow-sm'
                        : 'bg-stone-100 text-stone-600 border-stone-200 hover:bg-stone-200'
                    }`}
                  >
                    {isSelected ? '✓ ' : '+ '}{amenity}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Photo URL */}
          <div>
            <label htmlFor="caretaker-photo-url" className="block text-stone-700 mb-1 font-bold">Photo Image URL</label>
            <input
              id="caretaker-photo-url"
              name="photoUrl"
              type="text"
              value={photoUrl}
              onChange={(e) => setPhotoUrl(e.target.value)}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900"
            />
          </div>

          {/* Description */}
          <div>
            <label htmlFor="caretaker-description" className="block text-stone-700 mb-1 font-bold">House Description & Notes</label>
            <textarea
              id="caretaker-description"
              name="description"
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe house condition, proximity to tarmac, security details..."
              className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900"
            />
          </div>

          {/* Submit CTA */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black py-3 rounded-2xl text-sm shadow-xl transition-transform active:scale-98 cursor-pointer flex items-center justify-center gap-2 border border-amber-300"
            >
              <Home size={18} />
              <span>Publish Vacancy to GLOBALLICA Market</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
