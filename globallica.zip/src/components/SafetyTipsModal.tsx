import React from 'react';
import { X, ShieldCheck, AlertTriangle, PhoneCall, MapPin, Lock, FileText } from 'lucide-react';

interface SafetyTipsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SafetyTipsModal: React.FC<SafetyTipsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-stone-200 my-8 space-y-5 animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500 text-stone-950 flex items-center justify-center font-bold">
              <ShieldCheck size={22} />
            </div>
            <div>
              <h2 className="font-black text-xl text-stone-900">Kenyan Market Trust & Scam Protection</h2>
              <p className="text-xs text-stone-500">Official GLOBALLICA buyer & tenant safety guidelines</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-full transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Safety Rules Checklist */}
        <div className="space-y-3 text-xs">
          <div className="bg-amber-50 border border-amber-200 p-3.5 rounded-2xl flex items-start gap-3">
            <AlertTriangle size={20} className="text-amber-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-amber-900 text-sm">1. Housing: Never Pay Rent Deposit Before Physical Viewing</h4>
              <p className="text-amber-800 text-xs mt-1">
                Do not send large house rent deposits or advance payments to anyone asking for money before you physically visit the apartment building and meet the Caretaker at the premises.
              </p>
            </div>
          </div>

          <div className="bg-emerald-50 border border-emerald-200 p-3.5 rounded-2xl flex items-start gap-3">
            <PhoneCall size={20} className="text-emerald-700 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-emerald-900 text-sm">2. Verify M-Pesa Name Matches Caretaker / Seller Name</h4>
              <p className="text-emerald-800 text-xs mt-1">
                When sending M-Pesa, double-check that the name displayed on your Safaricom prompt matches the Caretaker or Seller profile name registered on GLOBALLICA.
              </p>
            </div>
          </div>

          <div className="bg-stone-50 border border-stone-200 p-3.5 rounded-2xl flex items-start gap-3">
            <MapPin size={20} className="text-stone-700 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-stone-900 text-sm">3. Meet in Safe Public Places for Vehicles & Electronics</h4>
              <p className="text-stone-600 text-xs mt-1">
                When buying cars, laptops, or iPhones, arrange meetings in well-lit public places such as bank halls, shopping malls (e.g. Yaya Centre, Sarit Centre, Garden City, City Mall Nyali), or near police stations.
              </p>
            </div>
          </div>

          <div className="bg-stone-50 border border-stone-200 p-3.5 rounded-2xl flex items-start gap-3">
            <ShieldCheck size={20} className="text-emerald-700 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-stone-900 text-sm">4. Hire Verified Fundis with Ratings</h4>
              <p className="text-stone-600 text-xs mt-1">
                For plumbing, electrical, and house cleaning, look for the "Verified Fundi" badge and check previous customer reviews before agreeing on job rates.
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full bg-emerald-900 text-white font-extrabold py-3 rounded-2xl text-xs hover:bg-emerald-800 cursor-pointer shadow-md"
        >
          I Understand & Agree to Safety Rules
        </button>
      </div>
    </div>
  );
};
