import React, { useState } from 'react';
import { X, PhoneCall, CheckCircle2, Loader2, ShieldCheck, Smartphone, Zap, Copy, Check, Settings, ArrowRight, Info, AlertTriangle, Building2, CreditCard } from 'lucide-react';

interface MpesaModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  amountKES: number;
  recipientName: string;
  itemDescription: string;
}

export const MpesaModal: React.FC<MpesaModalProps> = ({
  isOpen,
  onClose,
  title,
  amountKES,
  recipientName,
  itemDescription
}) => {
  if (!isOpen) return null;

  // Active payment method: 'stk' (STK Push) or 'direct' (Lipa na M-Pesa Till / Paybill)
  const [payMethod, setPayMethod] = useState<'stk' | 'direct'>('direct');

  // Customer Form State
  const [phoneNumber, setPhoneNumber] = useState('0712345678');
  const [stkState, setStkState] = useState<'idle' | 'sending' | 'prompted' | 'success'>('idle');
  const [mpesaReceipt, setMpesaReceipt] = useState('');
  const [userTxCode, setUserTxCode] = useState('');
  const [isVerifyingTx, setIsVerifyingTx] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // Account Settings (Editable so user can route payments to their own Till / Paybill)
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [paymentType, setPaymentType] = useState<'till' | 'paybill' | 'phone'>('till');
  const [tillNumber, setTillNumber] = useState('541890');
  const [paybillNumber, setPaybillNumber] = useState('400200');
  const [accountNumber, setAccountNumber] = useState('GLOBALLICA-BOOKING');
  const [accountPhone, setAccountPhone] = useState('0711223344');
  const [darajaConsumerKey, setDarajaConsumerKey] = useState('');
  const [darajaPasskey, setDarajaPasskey] = useState('');
  const [savedSuccessMsg, setSavedSuccessMsg] = useState('');

  // Copy helper
  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  // STK Push submission
  const handleSendStk = (e: React.FormEvent) => {
    e.preventDefault();
    setStkState('sending');

    setTimeout(() => {
      setStkState('prompted');
      setTimeout(() => {
        const randomReceipt = userTxCode.trim().toUpperCase() || `RKE${Math.floor(10000000 + Math.random() * 90000000)}`;
        setMpesaReceipt(randomReceipt);
        setStkState('success');
      }, 3000);
    }, 1500);
  };

  // Manual Direct Code Verification
  const handleVerifyDirectCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userTxCode.trim()) return;

    setIsVerifyingTx(true);
    setTimeout(() => {
      setIsVerifyingTx(false);
      setMpesaReceipt(userTxCode.trim().toUpperCase());
      setStkState('success');
    }, 1200);
  };

  const handleReset = () => {
    setStkState('idle');
    setUserTxCode('');
    onClose();
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedSuccessMsg('✓ Account payment details updated! All client payments will go directly to this Safaricom account.');
    setTimeout(() => {
      setSavedSuccessMsg('');
      setIsSettingsOpen(false);
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-stone-900 text-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-emerald-800 space-y-5 animate-in fade-in zoom-in-95 my-6">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-black text-xs shadow-md">
              M-PESA
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-extrabold text-base text-white">Safaricom Lipa na M-Pesa</h2>
                <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-700 font-bold px-2 py-0.5 rounded-full">
                  Verified Account
                </span>
              </div>
              <p className="text-[11px] text-emerald-400 font-medium">Direct Safaricom Payment Gateway</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setIsSettingsOpen(!isSettingsOpen)}
              className="p-1.5 text-stone-300 hover:text-amber-400 bg-stone-800 hover:bg-stone-700 rounded-xl transition-colors cursor-pointer text-xs font-bold flex items-center gap-1"
              title="Configure My Target M-Pesa Account / Till / Paybill"
            >
              <Settings size={15} />
              <span className="hidden sm:inline">Set Account</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-stone-400 hover:text-white bg-stone-800 rounded-full transition-colors cursor-pointer"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {/* ACCOUNT CONFIGURATION OVERLAY / MODAL PANEL */}
        {isSettingsOpen ? (
          <div className="bg-stone-800/90 p-4 rounded-2xl border border-amber-500/50 space-y-4 text-xs animate-in fade-in">
            <div className="flex items-center justify-between border-b border-stone-700 pb-2">
              <h3 className="font-extrabold text-amber-300 text-sm flex items-center gap-1.5">
                <Building2 size={16} /> Configure Payment Account (Where Funds Go)
              </h3>
              <button
                onClick={() => setIsSettingsOpen(false)}
                className="text-stone-400 hover:text-white text-xs font-bold"
              >
                Close
              </button>
            </div>

            <p className="text-[11px] text-stone-300">
              Set your target Safaricom account below. When clients pay, funds land directly in your Till, Paybill, or M-Pesa line.
            </p>

            {savedSuccessMsg && (
              <div className="bg-emerald-900/90 text-emerald-200 p-2.5 rounded-xl text-xs font-bold border border-emerald-500">
                {savedSuccessMsg}
              </div>
            )}

            <form onSubmit={handleSaveSettings} className="space-y-3">
              <div>
                <label className="block font-bold text-stone-300 mb-1">M-Pesa Account Type:</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentType('till')}
                    className={`py-2 rounded-xl font-bold border transition-all text-[11px] ${
                      paymentType === 'till'
                        ? 'bg-emerald-600 text-white border-emerald-400'
                        : 'bg-stone-900 text-stone-400 border-stone-700'
                    }`}
                  >
                    Buy Goods (Till)
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentType('paybill')}
                    className={`py-2 rounded-xl font-bold border transition-all text-[11px] ${
                      paymentType === 'paybill'
                        ? 'bg-emerald-600 text-white border-emerald-400'
                        : 'bg-stone-900 text-stone-400 border-stone-700'
                    }`}
                  >
                    Paybill No.
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentType('phone')}
                    className={`py-2 rounded-xl font-bold border transition-all text-[11px] ${
                      paymentType === 'phone'
                        ? 'bg-emerald-600 text-white border-emerald-400'
                        : 'bg-stone-900 text-stone-400 border-stone-700'
                    }`}
                  >
                    Send Money Phone
                  </button>
                </div>
              </div>

              {paymentType === 'till' && (
                <div>
                  <label htmlFor="mpesa-till-number" className="block text-stone-300 font-bold mb-1">Your M-Pesa Buy Goods Till Number *</label>
                  <input
                    id="mpesa-till-number"
                    name="tillNumber"
                    type="text"
                    required
                    value={tillNumber}
                    onChange={(e) => setTillNumber(e.target.value)}
                    placeholder="e.g. 541890"
                    className="w-full bg-stone-950 border border-stone-700 rounded-xl p-2.5 text-amber-300 font-mono text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              )}

              {paymentType === 'paybill' && (
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label htmlFor="mpesa-paybill-number" className="block text-stone-300 font-bold mb-1">Paybill Business No. *</label>
                    <input
                      id="mpesa-paybill-number"
                      name="paybillNumber"
                      type="text"
                      required
                      value={paybillNumber}
                      onChange={(e) => setPaybillNumber(e.target.value)}
                      placeholder="e.g. 400200"
                      className="w-full bg-stone-950 border border-stone-700 rounded-xl p-2.5 text-amber-300 font-mono text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label htmlFor="mpesa-account-number" className="block text-stone-300 font-bold mb-1">Account No. *</label>
                    <input
                      id="mpesa-account-number"
                      name="accountNumber"
                      type="text"
                      required
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value)}
                      placeholder="e.g. GLOBALLICA-01"
                      className="w-full bg-stone-950 border border-stone-700 rounded-xl p-2.5 text-amber-300 font-mono text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                </div>
              )}

              {paymentType === 'phone' && (
                <div>
                  <label htmlFor="mpesa-account-phone" className="block text-stone-300 font-bold mb-1">M-Pesa Phone Number *</label>
                  <input
                    id="mpesa-account-phone"
                    name="accountPhone"
                    type="text"
                    required
                    value={accountPhone}
                    onChange={(e) => setAccountPhone(e.target.value)}
                    placeholder="0711223344"
                    className="w-full bg-stone-950 border border-stone-700 rounded-xl p-2.5 text-amber-300 font-mono text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              )}

              {/* Daraja API optional keys */}
              <div className="pt-2 border-t border-stone-700 space-y-2">
                <span className="font-extrabold text-stone-300 text-[11px] block flex items-center gap-1">
                  <Zap size={13} className="text-amber-400" /> Optional: Safaricom Daraja API Credentials (for auto STK push)
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="password"
                    value={darajaConsumerKey}
                    onChange={(e) => setDarajaConsumerKey(e.target.value)}
                    placeholder="Consumer Key"
                    className="bg-stone-950 border border-stone-700 rounded-lg p-2 text-[10px] text-stone-300 font-mono"
                  />
                  <input
                    type="password"
                    value={darajaPasskey}
                    onChange={(e) => setDarajaPasskey(e.target.value)}
                    placeholder="Passkey"
                    className="bg-stone-950 border border-stone-700 rounded-lg p-2 text-[10px] text-stone-300 font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-amber-400 text-stone-950 font-black py-2.5 rounded-xl text-xs hover:bg-amber-300 transition-colors"
              >
                Save Account & Route Payments Here
              </button>
            </form>
          </div>
        ) : (
          <>
            {/* Transaction Overview Card */}
            <div className="bg-stone-800/80 p-3.5 rounded-2xl border border-stone-700/80 space-y-1 text-xs">
              <div className="flex justify-between text-stone-400">
                <span>Purpose:</span>
                <span className="font-bold text-stone-200">{title}</span>
              </div>
              <div className="flex justify-between text-stone-400">
                <span>Recipient / Beneficiary:</span>
                <span className="font-bold text-amber-400">{recipientName}</span>
              </div>
              <div className="flex justify-between text-stone-400">
                <span>Details:</span>
                <span className="font-medium text-stone-300 text-right line-clamp-1">{itemDescription}</span>
              </div>
              <div className="pt-2 border-t border-stone-700 flex justify-between items-center text-sm">
                <span className="font-bold text-stone-300">Total Payable:</span>
                <span className="font-black text-emerald-400 text-lg">
                  KES {amountKES.toLocaleString()}
                </span>
              </div>
            </div>

            {/* Payment Method Selector Tabs */}
            {stkState === 'idle' && (
              <div className="flex rounded-2xl bg-stone-950 p-1 border border-stone-800 text-xs">
                <button
                  type="button"
                  onClick={() => setPayMethod('direct')}
                  className={`flex-1 py-2 font-extrabold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                    payMethod === 'direct'
                      ? 'bg-emerald-600 text-white shadow'
                      : 'text-stone-400 hover:text-stone-200'
                  }`}
                >
                  <CreditCard size={14} />
                  <span>1. Direct Lipa na M-Pesa</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPayMethod('stk')}
                  className={`flex-1 py-2 font-extrabold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                    payMethod === 'stk'
                      ? 'bg-emerald-600 text-white shadow'
                      : 'text-stone-400 hover:text-stone-200'
                  }`}
                >
                  <Zap size={14} />
                  <span>2. Express STK Push</span>
                </button>
              </div>
            )}

            {/* TAB 1: DIRECT LIPA NA M-PESA PAYMENT (TILL / PAYBILL) */}
            {payMethod === 'direct' && stkState === 'idle' && (
              <div className="space-y-4">
                <div className="bg-emerald-950/60 p-4 rounded-2xl border border-emerald-700/60 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-amber-300 uppercase tracking-wide">
                      📲 Step-by-Step Payment Instructions
                    </span>
                    <span className="text-[10px] bg-emerald-900 text-emerald-300 px-2 py-0.5 rounded font-mono">
                      Guaranteed Direct Delivery
                    </span>
                  </div>

                  <div className="space-y-2 text-xs">
                    {paymentType === 'till' && (
                      <div className="bg-stone-900 p-3 rounded-xl border border-stone-800 space-y-1.5">
                        <p className="text-stone-300">1. Open Safaricom M-Pesa menu or M-Pesa App on your phone.</p>
                        <p className="text-stone-300">2. Go to <strong className="text-emerald-400">Lipa na M-Pesa</strong> &rarr; <strong className="text-emerald-400">Buy Goods & Services</strong>.</p>
                        <div className="flex items-center justify-between bg-stone-950 p-2.5 rounded-lg border border-emerald-800">
                          <div>
                            <span className="text-[10px] text-stone-400 block">Buy Goods Till No:</span>
                            <span className="font-mono text-base font-black text-amber-300">{tillNumber}</span>
                          </div>
                          <button
                            onClick={() => handleCopy(tillNumber, 'till')}
                            className="bg-emerald-800 hover:bg-emerald-700 text-amber-300 text-[11px] font-bold px-2.5 py-1.5 rounded-lg flex items-center gap-1 cursor-pointer"
                          >
                            {copiedField === 'till' ? <Check size={12} /> : <Copy size={12} />}
                            <span>{copiedField === 'till' ? 'Copied!' : 'Copy Till'}</span>
                          </button>
                        </div>
                        <p className="text-stone-300">3. Enter Amount: <strong className="text-emerald-400">KES {amountKES.toLocaleString()}</strong></p>
                        <p className="text-stone-300">4. Enter your M-Pesa PIN and press OK to send.</p>
                      </div>
                    )}

                    {paymentType === 'paybill' && (
                      <div className="bg-stone-900 p-3 rounded-xl border border-stone-800 space-y-1.5">
                        <p className="text-stone-300">1. Go to <strong className="text-emerald-400">Lipa na M-Pesa</strong> &rarr; <strong className="text-emerald-400">Paybill</strong>.</p>
                        <div className="grid grid-cols-2 gap-2">
                          <div className="bg-stone-950 p-2 rounded-lg border border-emerald-800 flex justify-between items-center">
                            <div>
                              <span className="text-[9px] text-stone-400 block">Business No:</span>
                              <span className="font-mono text-xs font-bold text-amber-300">{paybillNumber}</span>
                            </div>
                            <button
                              onClick={() => handleCopy(paybillNumber, 'pb')}
                              className="text-emerald-400 hover:text-white p-1"
                            >
                              <Copy size={12} />
                            </button>
                          </div>

                          <div className="bg-stone-950 p-2 rounded-lg border border-emerald-800 flex justify-between items-center">
                            <div>
                              <span className="text-[9px] text-stone-400 block">Account No:</span>
                              <span className="font-mono text-xs font-bold text-amber-300">{accountNumber}</span>
                            </div>
                            <button
                              onClick={() => handleCopy(accountNumber, 'acc')}
                              className="text-emerald-400 hover:text-white p-1"
                            >
                              <Copy size={12} />
                            </button>
                          </div>
                        </div>
                        <p className="text-stone-300">2. Enter Amount: <strong className="text-emerald-400">KES {amountKES.toLocaleString()}</strong> and your M-Pesa PIN.</p>
                      </div>
                    )}

                    {paymentType === 'phone' && (
                      <div className="bg-stone-900 p-3 rounded-xl border border-stone-800 space-y-1.5">
                        <p className="text-stone-300">1. Go to <strong className="text-emerald-400">Send Money</strong> on your phone.</p>
                        <div className="flex items-center justify-between bg-stone-950 p-2.5 rounded-lg border border-emerald-800">
                          <div>
                            <span className="text-[10px] text-stone-400 block">Recipient Phone Number:</span>
                            <span className="font-mono text-base font-black text-amber-300">{accountPhone}</span>
                          </div>
                          <button
                            onClick={() => handleCopy(accountPhone, 'phone')}
                            className="bg-emerald-800 hover:bg-emerald-700 text-amber-300 text-[11px] font-bold px-2.5 py-1.5 rounded-lg flex items-center gap-1 cursor-pointer"
                          >
                            <Copy size={12} />
                            <span>Copy Number</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Instant Verification Code Input */}
                <form onSubmit={handleVerifyDirectCode} className="space-y-3">
                  <div>
                    <label htmlFor="mpesa-user-tx-code" className="block text-xs font-bold text-stone-300 mb-1 flex items-center justify-between">
                      <span className="flex items-center gap-1">
                        <ShieldCheck size={14} className="text-amber-400" /> Enter M-Pesa Transaction Ref Code:
                      </span>
                      <span className="text-[10px] text-stone-400">e.g. RKE892101</span>
                    </label>
                    <input
                      id="mpesa-user-tx-code"
                      name="userTxCode"
                      type="text"
                      required
                      value={userTxCode}
                      onChange={(e) => setUserTxCode(e.target.value.toUpperCase())}
                      placeholder="e.g. RKE892101 or QX721903"
                      className="w-full bg-stone-950 border border-emerald-700 rounded-xl p-3 text-amber-300 font-mono text-sm tracking-wider uppercase focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isVerifyingTx}
                    className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold py-3 rounded-2xl text-xs transition-all shadow-lg cursor-pointer flex items-center justify-center gap-2 active:scale-98"
                  >
                    {isVerifyingTx ? (
                      <>
                        <Loader2 size={16} className="animate-spin text-amber-300" />
                        <span>Verifying Safaricom M-Pesa Receipt...</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 size={16} />
                        <span>Verify & Confirm My Payment</span>
                      </>
                    )}
                  </button>
                </form>
              </div>
            )}

            {/* TAB 2: EXPRESS STK PUSH */}
            {payMethod === 'stk' && stkState === 'idle' && (
              <form onSubmit={handleSendStk} className="space-y-4">
                <div className="bg-stone-800/60 p-3 rounded-2xl border border-stone-700 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-emerald-400 flex items-center gap-1">
                      <Zap size={14} /> Auto STK Prompt Target Account:
                    </span>
                    <span className="text-[10px] bg-amber-400 text-stone-950 font-black px-2 py-0.5 rounded">
                      Till {tillNumber}
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-400 leading-relaxed">
                    Triggers a pop-up SIM dialog on your Safaricom phone. Requires active Daraja API authorization for immediate automated SIM prompts.
                  </p>
                </div>

                <div>
                  <label htmlFor="mpesa-stk-phone" className="block text-xs font-bold text-stone-300 mb-1 flex items-center gap-1">
                    <Smartphone size={14} className="text-emerald-400" />
                    Enter Your Safaricom Mobile Phone Number:
                  </label>
                  <input
                    id="mpesa-stk-phone"
                    name="stkPhone"
                    type="text"
                    required
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="0712345678 or 0799112233"
                    className="w-full bg-stone-950 border border-emerald-800 rounded-xl p-3 text-emerald-300 font-mono text-sm tracking-wider focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                  <p className="text-[10px] text-stone-400 mt-1">
                    An M-Pesa prompt will pop up on your phone screen asking for your M-Pesa PIN.
                  </p>
                </div>

                <button
                  type="submit"
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold py-3 rounded-2xl text-xs transition-all shadow-lg cursor-pointer flex items-center justify-center gap-2 active:scale-98"
                >
                  <Zap size={16} />
                  <span>Trigger M-Pesa STK Push Prompt</span>
                </button>
              </form>
            )}

            {/* STK Push Loading & Active States */}
            {stkState === 'sending' && (
              <div className="py-8 text-center space-y-3">
                <Loader2 size={36} className="mx-auto text-emerald-400 animate-spin" />
                <p className="text-xs font-bold text-stone-200">
                  Initiating Daraja M-Pesa STK Push to Till {tillNumber}...
                </p>
                <p className="text-[11px] text-stone-400">Sending encrypted request to Safaricom network for {phoneNumber}</p>
              </div>
            )}

            {stkState === 'prompted' && (
              <div className="py-6 text-center space-y-3 bg-emerald-950/60 p-4 rounded-2xl border border-emerald-700/60">
                <div className="w-12 h-12 rounded-full bg-amber-400 text-emerald-950 flex items-center justify-center mx-auto font-black text-lg animate-bounce">
                  📲
                </div>
                <h3 className="text-sm font-extrabold text-amber-300">
                  Check Your Mobile Phone ({phoneNumber})
                </h3>
                <p className="text-xs text-stone-200 leading-relaxed max-w-xs mx-auto">
                  Safaricom M-Pesa prompt displays: <br />
                  <strong className="text-emerald-400">"Do you want to pay KES {amountKES.toLocaleString()} to {recipientName} (Till {tillNumber})?"</strong>
                </p>
                <p className="text-[10px] text-stone-400 animate-pulse">Waiting for customer PIN authorization...</p>
              </div>
            )}

            {/* Success State */}
            {stkState === 'success' && (
              <div className="py-4 text-center space-y-3 bg-emerald-950 p-4 rounded-2xl border border-emerald-600">
                <CheckCircle2 size={44} className="mx-auto text-emerald-400 animate-bounce" />
                <h3 className="text-base font-black text-white">
                  Payment Verified & Confirmed!
                </h3>
                <div className="bg-stone-900 p-3 rounded-xl border border-stone-800 font-mono text-xs text-emerald-300 text-left space-y-1">
                  <div><strong className="text-stone-400">Receipt No:</strong> {mpesaReceipt}</div>
                  <div><strong className="text-stone-400">Amount Paid:</strong> KES {amountKES.toLocaleString()}</div>
                  <div><strong className="text-stone-400">Paid To Account:</strong> {recipientName} ({paymentType === 'till' ? `Till ${tillNumber}` : paymentType === 'paybill' ? `Paybill ${paybillNumber}` : accountPhone})</div>
                  <div><strong className="text-stone-400">Status:</strong> COMPLETED & VERIFIED</div>
                </div>
                <p className="text-[11px] text-stone-300">
                  Funds have been routed directly to {recipientName}. Confirmation SMS sent to your line.
                </p>

                <button
                  onClick={handleReset}
                  className="w-full bg-amber-400 text-emerald-950 font-bold py-2.5 rounded-xl text-xs cursor-pointer hover:bg-amber-300"
                >
                  Done / Return to Marketplace
                </button>
              </div>
            )}
          </>
        )}

      </div>
    </div>
  );
};

