import React, { useState, useRef, useEffect } from 'react';
import { X, Camera, ShieldCheck, CheckCircle2, AlertTriangle, RefreshCw, UserCheck, Lock, Sparkles, Scan, Smartphone, ShieldAlert } from 'lucide-react';
import { ServiceProvider, LiveSelfieVerification } from '../types';

interface LiveSelfieModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetProvider?: ServiceProvider | null;
  allProviders?: ServiceProvider[];
  onSelfieVerified?: (providerId: string, selfieData: LiveSelfieVerification) => void;
}

export const LiveSelfieModal: React.FC<LiveSelfieModalProps> = ({
  isOpen,
  onClose,
  targetProvider,
  allProviders = [],
  onSelfieVerified
}) => {
  const [selectedProviderId, setSelectedProviderId] = useState<string>(targetProvider?.id || allProviders[0]?.id || '');
  const [isScanning, setIsScanning] = useState(false);
  const [scanStep, setScanStep] = useState(0);
  const [matchResult, setMatchResult] = useState<LiveSelfieVerification | null>(
    targetProvider?.liveSelfieVerification || null
  );

  const [useRealCamera, setUseRealCamera] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [capturedPhotoUrl, setCapturedPhotoUrl] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);

  const currentProvider = targetProvider || allProviders.find(p => p.id === selectedProviderId) || targetProvider;

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  const startCamera = async () => {
    setCameraError(null);
    setUseRealCamera(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 640 } }
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        setCameraActive(true);
      }
    } catch (err: any) {
      console.warn('Camera access error or restricted:', err);
      setCameraError('Live web camera unavailable or blocked. Falling back to High-Definition AI Biometric Simulator.');
      setUseRealCamera(false);
      setCameraActive(false);
    }
  };

  // Reset or initialize when provider changes
  useEffect(() => {
    if (currentProvider) {
      setMatchResult(currentProvider.liveSelfieVerification || null);
      setCapturedPhotoUrl(null);
    }
  }, [currentProvider?.id]);

  // Clean up camera stream on unmount or close
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  if (!isOpen) return null;

  const getRoleSensitivity = (tradeSkill?: string): { level: 'HIGH_SENSITIVE' | 'MEDIUM_SENSITIVE' | 'STANDARD'; label: string; badgeColor: string } => {
    if (!tradeSkill) return { level: 'STANDARD', label: 'Standard Role', badgeColor: 'bg-stone-200 text-stone-800' };
    
    if (tradeSkill.includes('Mama Fua') || tradeSkill.includes('Plumber') || tradeSkill.includes('Electrician') || tradeSkill.includes('Carpenter') || tradeSkill.includes('Appliance')) {
      return {
        level: 'HIGH_SENSITIVE',
        label: '🔴 HIGH SENSITIVITY (Indoor Household & Family Access)',
        badgeColor: 'bg-rose-950 text-rose-300 border border-rose-500/60'
      };
    }
    if (tradeSkill.includes('Cab') || tradeSkill.includes('BodaBoda') || tradeSkill.includes('Movers')) {
      return {
        level: 'MEDIUM_SENSITIVE',
        label: '🟡 MEDIUM SENSITIVITY (Passenger & In-Transit Transport)',
        badgeColor: 'bg-amber-950 text-amber-300 border border-amber-500/60'
      };
    }
    return {
      level: 'STANDARD',
      label: '🟢 STANDARD VETTING (General Services)',
      badgeColor: 'bg-emerald-950 text-emerald-300 border border-emerald-500/60'
    };
  };

  const sensitivity = getRoleSensitivity(currentProvider?.tradeSkill);

  const handleExecuteLiveSelfieScan = () => {
    setIsScanning(true);
    setScanStep(1);

    // If real camera is running, capture current frame to data URL
    if (cameraActive && videoRef.current) {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = 320;
        canvas.height = 320;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(videoRef.current, 0, 0, 320, 320);
          setCapturedPhotoUrl(canvas.toDataURL('image/jpeg'));
        }
      } catch (e) {
        console.error('Snapshot error', e);
      }
    } else {
      // Simulate selfie image
      setCapturedPhotoUrl(currentProvider?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80');
    }

    setTimeout(() => setScanStep(2), 1000);
    setTimeout(() => setScanStep(3), 2200);
    setTimeout(() => setScanStep(4), 3300);

    setTimeout(() => {
      setIsScanning(false);
      stopCamera();

      const newMatch: LiveSelfieVerification = {
        isSelfieVerified: true,
        capturedSelfieUrl: capturedPhotoUrl || currentProvider?.avatar,
        matchedScorePercent: 98.7,
        verifiedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ', ' + new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }),
        facialLandmarksCount: 128,
        isOnlineActive: true,
        roleSensitivityLevel: sensitivity.level
      };

      setMatchResult(newMatch);

      if (currentProvider && onSelfieVerified) {
        onSelfieVerified(currentProvider.id, newMatch);
      }
    }, 4200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95 duration-200 my-auto">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-emerald-950 p-5 text-white flex items-center justify-between border-b border-amber-400/30">
          <div className="flex items-center gap-3">
            <div className="bg-amber-400 text-emerald-950 p-2.5 rounded-2xl font-black shadow-md shrink-0">
              <Camera size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-amber-400 text-emerald-950 text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wide">
                  AI BIOMETRIC VERIFICATION
                </span>
                <span className="text-emerald-300 text-xs font-semibold">Zero-Impersonation Guarantee</span>
              </div>
              <h2 className="text-lg sm:text-xl font-extrabold text-white">
                Live AI Selfie & Face Matching
              </h2>
            </div>
          </div>

          <button
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="text-stone-400 hover:text-white p-2 rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        <div className="p-5 space-y-5 max-h-[82vh] overflow-y-auto">
          
          {/* Sensitivity Info Bar */}
          <div className="bg-stone-900 text-stone-200 p-3.5 rounded-2xl border border-stone-800 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-extrabold text-amber-300 flex items-center gap-1.5">
                <ShieldCheck size={16} className="text-amber-300" />
                Why AI Live Selfie Verification?
              </span>
              <span className={`text-[10px] font-black px-2 py-0.5 rounded-md ${sensitivity.badgeColor}`}>
                {sensitivity.label}
              </span>
            </div>
            <p className="text-xs text-stone-300 leading-relaxed">
              Prevents unauthorized account sharing and impersonation. Before accepting indoor house jobs or going online, specialists take a random live selfie that AI matches against their registered onboarding photo.
            </p>
          </div>

          {/* Specialist Selection dropdown if no fixed provider */}
          {!targetProvider && allProviders.length > 0 && (
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Select Specialist / Specialist Account:
              </label>
              <select
                value={selectedProviderId}
                onChange={(e) => {
                  setSelectedProviderId(e.target.value);
                  setMatchResult(null);
                  setCapturedPhotoUrl(null);
                }}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2.5 text-xs font-bold text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
              >
                {allProviders.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.name} - {p.tradeSkill} ({p.operationalEstate}, {p.operationalCounty})
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Current Provider Identity Header Card */}
          {currentProvider && (
            <div className="bg-stone-50 border border-stone-200 rounded-2xl p-4 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <img
                    src={currentProvider.avatar}
                    alt={currentProvider.name}
                    className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-600 shadow-sm"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute -bottom-1 -right-1 bg-emerald-700 text-white text-[9px] font-black p-0.5 rounded-full border border-white">
                    <CheckCircle2 size={12} />
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-extrabold text-stone-900 text-sm">{currentProvider.name}</h3>
                    <span className="bg-amber-100 text-amber-900 font-bold text-[10px] px-2 py-0.5 rounded border border-amber-300">
                      {currentProvider.tradeSkill}
                    </span>
                  </div>
                  <p className="text-xs text-stone-500 font-medium mt-0.5">
                    📍 {currentProvider.operationalEstate}, {currentProvider.operationalCounty} • Tel: {currentProvider.phone}
                  </p>
                  <p className="text-[10px] text-emerald-800 font-bold mt-0.5">
                    Registered Onboarding ID Photo on File
                  </p>
                </div>
              </div>

              {matchResult?.isSelfieVerified && (
                <div className="bg-emerald-100 text-emerald-950 px-3 py-1.5 rounded-xl border border-emerald-300 text-right shrink-0">
                  <span className="font-black text-xs text-emerald-900 block">🟢 ONLINE & VERIFIED</span>
                  <span className="text-[10px] text-emerald-700 font-bold">Matched {matchResult.matchedScorePercent}%</span>
                </div>
              )}
            </div>
          )}

          {/* Camera Frame / Scanning Box */}
          <div className="relative bg-stone-950 rounded-3xl overflow-hidden p-6 border-2 border-emerald-800 flex flex-col items-center justify-center min-h-[280px]">
            
            {/* Live Camera element if active */}
            {cameraActive ? (
              <div className="relative w-52 h-52 rounded-full overflow-hidden border-4 border-amber-400 shadow-2xl">
                <video
                  ref={videoRef}
                  playsInline
                  muted
                  className="w-full h-full object-cover transform scale-x-[-1]"
                />
                {/* Facial Target oval overlay */}
                <div className="absolute inset-0 border-2 border-dashed border-amber-300/80 rounded-full animate-pulse pointer-events-none flex items-center justify-center">
                  <Scan size={36} className="text-amber-400 opacity-60" />
                </div>
              </div>
            ) : (
              /* Simulated Face Comparison UI */
              <div className="grid grid-cols-2 gap-4 w-full max-w-md items-center">
                
                {/* Frame 1: Registered Photo */}
                <div className="flex flex-col items-center space-y-2">
                  <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-2xl overflow-hidden border-2 border-emerald-500 shadow-md">
                    <img
                      src={currentProvider?.avatar}
                      alt="Registered Onboarding"
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-1 left-1 bg-black/70 text-emerald-300 text-[9px] font-mono px-1.5 py-0.5 rounded">
                      ID REGISTRATION
                    </div>
                  </div>
                  <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider">
                    Onboarding Reference
                  </span>
                </div>

                {/* Frame 2: Live Selfie Capture */}
                <div className="flex flex-col items-center space-y-2">
                  <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-2xl overflow-hidden border-2 border-amber-400 bg-stone-900 shadow-md flex items-center justify-center">
                    {capturedPhotoUrl ? (
                      <img
                        src={capturedPhotoUrl}
                        alt="Captured Live Selfie"
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="text-center p-2 text-stone-500">
                        <Camera size={28} className="mx-auto mb-1 text-amber-400/80 animate-bounce" />
                        <span className="text-[10px] font-bold text-stone-400 block">Ready for Live Snap</span>
                      </div>
                    )}

                    {/* Scanning Beam Animation when active */}
                    {isScanning && (
                      <div className="absolute inset-x-0 h-1 bg-amber-400 shadow-[0_0_15px_#f59e0b] animate-[bounce_1.5s_infinite]" />
                    )}

                    <div className="absolute top-1 left-1 bg-amber-400 text-emerald-950 text-[9px] font-black px-1.5 py-0.5 rounded">
                      LIVE SELFIE
                    </div>
                  </div>
                  <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wider">
                    3D AI Biometric Scan
                  </span>
                </div>
              </div>
            )}

            {/* AI Scanning progress log overlay */}
            {isScanning && (
              <div className="mt-4 w-full max-w-md bg-emerald-950/90 text-amber-300 p-3 rounded-2xl border border-amber-400/50 text-xs font-mono space-y-1">
                <div className="flex items-center gap-2 font-bold text-white">
                  <div className="w-2.5 h-2.5 bg-amber-400 rounded-full animate-ping" />
                  <span>AI Facial Match Engine Running...</span>
                </div>

                <div className={`transition-opacity ${scanStep >= 1 ? 'opacity-100 text-emerald-300' : 'opacity-40'}`}>
                  {scanStep >= 1 ? '✅' : '⏳'} 1. Mapping 128 Facial Biometric Mesh Landmarks...
                </div>
                <div className={`transition-opacity ${scanStep >= 2 ? 'opacity-100 text-emerald-300' : 'opacity-40'}`}>
                  {scanStep >= 2 ? '✅' : '⏳'} 2. Liveness Check: Non-static depth & reflection pass...
                </div>
                <div className={`transition-opacity ${scanStep >= 3 ? 'opacity-100 text-emerald-300' : 'opacity-40'}`}>
                  {scanStep >= 3 ? '✅' : '⏳'} 3. Cross-referencing vector embeddings with ID Registration...
                </div>
                <div className={`transition-opacity ${scanStep >= 4 ? 'opacity-100 text-amber-300 font-bold' : 'opacity-40'}`}>
                  {scanStep >= 4 ? '✅' : '⏳'} 4. High Confidence Biometric Match Confirmed!
                </div>
              </div>
            )}

            {/* Camera error notification */}
            {cameraError && (
              <div className="mt-3 bg-rose-950/80 border border-rose-500/50 text-rose-200 text-[11px] p-2 rounded-xl text-center">
                {cameraError}
              </div>
            )}

            {/* Camera Toggle Button */}
            {!isScanning && (
              <div className="mt-4 flex items-center gap-3">
                {!cameraActive ? (
                  <button
                    type="button"
                    onClick={startCamera}
                    className="bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold px-3 py-1.5 rounded-xl text-xs border border-stone-600 transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <Camera size={14} className="text-amber-400" />
                    <span>Open Device Camera</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={stopCamera}
                    className="bg-rose-900 hover:bg-rose-800 text-rose-200 font-bold px-3 py-1.5 rounded-xl text-xs transition-colors cursor-pointer"
                  >
                    Close Web Camera
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Scan Results Card if verified */}
          {matchResult?.isSelfieVerified && !isScanning && (
            <div className="bg-emerald-950 text-white p-4 rounded-2xl border-2 border-amber-400 shadow-md space-y-2">
              <div className="flex items-center justify-between border-b border-amber-400/40 pb-2">
                <div className="flex items-center gap-2">
                  <ShieldCheck size={20} className="text-amber-300" />
                  <span className="font-black text-sm text-amber-300 uppercase">
                    🛡️ AI LIVE SELFIE VERIFIED & MATCHED
                  </span>
                </div>
                <span className="bg-amber-400 text-emerald-950 font-black text-[10px] px-2.5 py-1 rounded-lg">
                  PASSED BIOMETRICS
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs pt-1">
                <div className="bg-emerald-900/80 p-2.5 rounded-xl border border-emerald-700">
                  <span className="text-[10px] text-emerald-300 font-semibold block">Facial Match Score:</span>
                  <span className="font-mono font-bold text-amber-300 text-sm">
                    {matchResult.matchedScorePercent}% Confidence
                  </span>
                </div>

                <div className="bg-emerald-900/80 p-2.5 rounded-xl border border-emerald-700">
                  <span className="text-[10px] text-emerald-300 font-semibold block">Duty Shift Status:</span>
                  <span className="font-bold text-emerald-200 text-xs">
                    🟢 Cleared Online / Ready for Jobs
                  </span>
                </div>
              </div>

              <p className="text-[10px] text-emerald-200/90 italic pt-1 text-center">
                Biometrics Verified at {matchResult.verifiedAt} • GLOBALLICA Anti-Impersonation Pass Active
              </p>
            </div>
          )}

          {/* Action Button */}
          {!isScanning && (
            <button
              type="button"
              onClick={handleExecuteLiveSelfieScan}
              disabled={!currentProvider}
              className="w-full bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black py-3.5 rounded-2xl text-xs transition-all shadow-lg active:scale-98 cursor-pointer flex items-center justify-center gap-2 border border-amber-500"
            >
              <Camera size={18} className="text-emerald-950" />
              <span>
                {matchResult?.isSelfieVerified ? '📸 Re-take Random AI Live Selfie' : '📸 Snap Live AI Selfie & Match Biometrics'}
              </span>
            </button>
          )}

          {/* Footer Close */}
          <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
            <span className="text-[11px] text-stone-500 font-medium">
              🔒 Biometric data is processed encrypted locally and never sold.
            </span>
            <button
              onClick={() => {
                stopCamera();
                onClose();
              }}
              className="bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold px-4 py-2 rounded-xl text-xs transition-colors cursor-pointer"
            >
              Close Verification
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
