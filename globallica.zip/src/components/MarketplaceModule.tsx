import React, { useState } from 'react';
import { ProductListing, RBACRole } from '../types';
import { ShoppingBag, Car, PhoneCall, MessageSquare, ShieldCheck, MapPin, Tag, PlusCircle, CheckCircle, AlertCircle, QrCode } from 'lucide-react';
import { getProductCategoryPhoto } from '../utils/categoryImages';

interface MarketplaceModuleProps {
  products: ProductListing[];
  onSelectProduct: (prod: ProductListing) => void;
  onToggleStatus: (prodId: string) => void;
  onOpenSellerPortal: () => void;
  onOpenNtsaVerification?: () => void;
  currentRole: RBACRole;
}

export const MarketplaceModule: React.FC<MarketplaceModuleProps> = ({
  products,
  onSelectProduct,
  onToggleStatus,
  onOpenSellerPortal,
  onOpenNtsaVerification,
  currentRole
}) => {
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [conditionFilter, setConditionFilter] = useState<string>('all');

  const filtered = products.filter(p => {
    if (categoryFilter !== 'all' && p.category !== categoryFilter) return false;
    if (conditionFilter !== 'all' && p.condition !== conditionFilter) return false;
    return true;
  });

  return (
    <div className="w-full max-w-full space-y-6">
      {/* Marketplace Banner */}
      <div className="w-full max-w-full bg-gradient-to-r from-emerald-900 via-stone-900 to-emerald-950 text-white p-4 sm:p-5 rounded-2xl shadow-lg border border-emerald-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-amber-400 text-emerald-950 font-black px-2 py-0.5 rounded text-[10px] uppercase">
              🚗 Cars & General Goods Marketplace
            </span>
            <span className="text-emerald-200 text-xs font-semibold">Verified Kenyan Sellers</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            Buy & Sell Cars, Electronics, Furniture & Goods in Kenya
          </h2>
          <p className="text-emerald-200 text-xs mt-1">
            Deals on imported Toyota Prados, smart TVs, sofa sets, iPhones & solar power tools. Chat directly with verified sellers via WhatsApp.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onOpenNtsaVerification && (
            <button
              onClick={onOpenNtsaVerification}
              className="bg-stone-900 hover:bg-black text-amber-300 font-black px-3.5 py-2.5 rounded-xl text-xs border border-amber-400/50 shadow transition-all cursor-pointer flex items-center gap-1.5"
            >
              <QrCode size={15} className="text-amber-400" />
              <span>NTSA Logbook Scanner</span>
            </button>
          )}

          <button
            onClick={onOpenSellerPortal}
            className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-extrabold px-4 py-2.5 rounded-xl text-xs shadow-lg transition-all active:scale-95 shrink-0 cursor-pointer flex items-center gap-2"
          >
            <PlusCircle size={16} />
            <span>Post Ad / Sell Your Item</span>
          </button>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-stone-200 space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-bold text-xs text-stone-700 flex items-center gap-1.5">
            <ShoppingBag size={15} className="text-emerald-700" />
            Marketplace Categories:
          </span>

          <select
            id="marketplace-condition-filter"
            name="conditionFilter"
            aria-label="Filter products by condition"
            value={conditionFilter}
            onChange={(e) => setConditionFilter(e.target.value)}
            className="bg-stone-50 border border-stone-200 rounded-lg px-2.5 py-1 text-xs font-semibold text-stone-800 focus:ring-2 focus:ring-emerald-600 focus:outline-none cursor-pointer"
          >
            <option value="all">All Conditions</option>
            <option value="Brand New">Brand New</option>
            <option value="Foreign Used (Import)">Foreign Used (Import)</option>
            <option value="Kenyan Used">Kenyan Used</option>
          </select>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setCategoryFilter('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              categoryFilter === 'all'
                ? 'bg-emerald-800 text-white shadow'
                : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
            }`}
          >
            All Products ({products.length})
          </button>

          {[
            { cat: 'Vehicles', icon: '🚗' },
            { cat: 'Electronics & Phones', icon: '📱' },
            { cat: 'Home & Furniture', icon: '🛋️' },
            { cat: 'Farm & Agribusiness', icon: '🌾' },
            { cat: 'Tools & Building', icon: '🛠️' }
          ].map(c => (
            <button
              key={c.cat}
              onClick={() => setCategoryFilter(c.cat)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                categoryFilter === c.cat
                  ? 'bg-emerald-800 text-white shadow'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              <span>{c.icon}</span>
              <span>{c.cat}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      {filtered.length === 0 ? (
        <div className="bg-stone-50 border border-dashed border-stone-300 rounded-2xl p-8 text-center text-stone-500 space-y-2">
          <ShoppingBag size={36} className="mx-auto text-stone-400" />
          <h3 className="font-bold text-stone-700">No items matching selected category</h3>
          <p className="text-xs">Try switching category or condition filters.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((item) => {
            const sellerWaLink = `https://wa.me/${item.sellerWhatsapp}?text=${encodeURIComponent(
              `Jambo ${item.sellerName}, I am interested in your item "${item.title}" listed for KES ${item.priceKES.toLocaleString()} on GLOBALLICA. Is it still available?`
            )}`;

            return (
              <div
                key={item.id}
                className={`bg-white rounded-2xl border ${
                  item.status === 'Sold' ? 'border-stone-300 opacity-75' : 'border-stone-200'
                } overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between group`}
              >
                <div>
                  {/* Photo */}
                  <div 
                    onClick={() => onSelectProduct(item)}
                    className="relative h-48 bg-stone-100 overflow-hidden cursor-pointer"
                  >
                    <img
                      src={item.photos?.[0] || getProductCategoryPhoto(item.category)}
                      alt={item.title}
                      onError={(e) => {
                        e.currentTarget.src = getProductCategoryPhoto(item.category);
                      }}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />

                    {/* Condition Badge */}
                    <div className="absolute top-3 left-3 bg-stone-900/80 text-white text-[10px] font-bold px-2.5 py-1 rounded-lg backdrop-blur-sm">
                      {item.condition}
                    </div>

                    {/* Status Pill */}
                    <div className="absolute top-3 right-3">
                      {item.status === 'Available' ? (
                        <span className="bg-emerald-600 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-md shadow">
                          ✓ Available
                        </span>
                      ) : (
                        <span className="bg-red-600 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-md shadow">
                          ✕ SOLD
                        </span>
                      )}
                    </div>

                    {/* Price Tag */}
                    <div className="absolute bottom-3 left-3 bg-emerald-950/90 text-white px-3 py-1 rounded-xl shadow-md border border-emerald-700">
                      <span className="text-[10px] font-bold text-amber-400 block">
                        KES {item.priceKES.toLocaleString()} {item.isNegotiable && '(Negotiable)'}
                      </span>
                    </div>

                    {/* Location */}
                    <div className="absolute bottom-3 right-3 bg-black/60 text-white text-[10px] px-2 py-0.5 rounded flex items-center gap-1 backdrop-blur-sm">
                      <MapPin size={10} className="text-amber-400" />
                      <span>{item.estate}, {item.county}</span>
                    </div>
                  </div>

                  {/* Body Info */}
                  <div className="p-4 space-y-2">
                    <h3 
                      onClick={() => onSelectProduct(item)}
                      className="font-bold text-stone-900 text-sm sm:text-base line-clamp-2 hover:text-emerald-700 cursor-pointer transition-colors leading-snug"
                    >
                      {item.title}
                    </h3>

                    <p className="text-xs text-stone-600 line-clamp-2">
                      {item.description}
                    </p>

                    {/* Seller details */}
                    <div className="pt-2 flex items-center justify-between text-xs text-stone-500">
                      <div className="flex items-center gap-1 flex-wrap">
                        <span className="font-semibold text-stone-800">{item.sellerName}</span>
                        {item.isSellerVerified && (
                          <span title="Verified Seller">
                            <ShieldCheck size={14} className="text-emerald-600" />
                          </span>
                        )}
                        {item.category === 'Vehicles' && (
                          <span className="inline-flex items-center gap-0.5 bg-amber-100 text-amber-900 border border-amber-300 text-[9px] font-black px-1.5 py-0.2 rounded-full">
                            <QrCode size={9} className="text-amber-700" /> NTSA LOGBOOK
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] bg-stone-100 px-2 py-0.5 rounded font-bold">
                        {item.category}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Footer Controls & Seller Inventory Status Toggle */}
                <div className="p-4 pt-0 space-y-2">
                  {/* Seller Role Inventory Management Toggle */}
                  {currentRole === 'seller' && (
                    <button
                      onClick={() => onToggleStatus(item.id)}
                      className="w-full bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold py-1.5 px-2 rounded-xl transition-colors border border-stone-300 flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Tag size={13} />
                      <span>
                        Seller Control: Mark as {item.status === 'Available' ? 'SOLD' : 'AVAILABLE'}
                      </span>
                    </button>
                  )}

                  {/* Contact Seller Buttons */}
                  <div className="grid grid-cols-2 gap-2">
                    <a
                      href={`tel:${item.sellerPhone}`}
                      className="flex items-center justify-center gap-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2 px-3 rounded-xl text-xs transition-colors shadow-sm cursor-pointer"
                    >
                      <PhoneCall size={14} />
                      <span>Call Seller</span>
                    </a>

                    <a
                      href={sellerWaLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 px-3 rounded-xl text-xs transition-colors shadow-sm cursor-pointer"
                    >
                      <MessageSquare size={14} />
                      <span>WhatsApp</span>
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
