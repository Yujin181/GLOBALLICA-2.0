import React, { useState } from 'react';
import { X, Wrench, HardHat, DollarSign, Camera, FileText, Send, CheckCircle2, AlertCircle, Sparkles, MessageSquare, Plus, Trash2, ShieldCheck, ArrowRight, Clock, MapPin, Phone, Building2, ChevronRight, UserCheck, RefreshCw, Upload } from 'lucide-react';
import { JobBrief, ContractorBid, NegotiationMessage, ServiceProvider, ItemizedQuote } from '../types';

interface ContractorNegotiationModalProps {
  isOpen: boolean;
  onClose: () => void;
  jobBriefs: JobBrief[];
  contractorBids: ContractorBid[];
  negotiationMessages: NegotiationMessage[];
  allProviders: ServiceProvider[];
  onAddJobBrief: (brief: JobBrief) => void;
  onAddBid: (bid: ContractorBid) => void;
  onSendMessage: (msg: NegotiationMessage) => void;
  onUpdateBidStatus: (bidId: string, status: ContractorBid['status'], updatedQuoteKES?: number) => void;
  onUpdateBriefStatus: (briefId: string, status: JobBrief['status']) => void;
  onOpenEscrowForBid?: (brief: JobBrief, bid: ContractorBid) => void;
}

export const ContractorNegotiationModal: React.FC<ContractorNegotiationModalProps> = ({
  isOpen,
  onClose,
  jobBriefs = [],
  contractorBids = [],
  negotiationMessages = [],
  allProviders = [],
  onAddJobBrief,
  onAddBid,
  onSendMessage,
  onUpdateBidStatus,
  onUpdateBriefStatus,
  onOpenEscrowForBid
}) => {
  const [activeTab, setActiveTab] = useState<'POST_BRIEF' | 'BRIEFS_LIST' | 'CHAT_NEGOTIATE'>('BRIEFS_LIST');

  // Selected brief & bid for chat/bidding
  const [selectedBriefId, setSelectedBriefId] = useState<string>(jobBriefs[0]?.id || '');
  const [selectedBidId, setSelectedBidId] = useState<string>(contractorBids[0]?.id || '');

  // Contractor mode toggle (Switch between Client view & Contractor bidding view)
  const [userRole, setUserRole] = useState<'CLIENT' | 'CONTRACTOR'>('CLIENT');
  const [actingContractorId, setActingContractorId] = useState<string>(allProviders[0]?.id || 'f-3');

  // New Brief Form State
  const [briefTitle, setBriefTitle] = useState('');
  const [briefCategory, setBriefCategory] = useState<JobBrief['category']>('Electrical Wiring & Solar');
  const [briefLocation, setBriefLocation] = useState('Kitisuru, Nairobi');
  const [briefCounty, setBriefCounty] = useState('Nairobi');
  const [budgetKES, setBudgetKES] = useState<number>(300000);
  const [isBudgetNegotiable, setIsBudgetNegotiable] = useState(true);
  const [briefDescription, setBriefDescription] = useState('');
  const [clientName, setClientName] = useState('Dr. Kamau Njuguna');
  const [clientPhone, setClientPhone] = useState('+254722998877');
  const [photoUrls, setPhotoUrls] = useState<string[]>([
    'https://images.unsplash.com/photo-1508873696983-2df515122519?auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=800&q=80'
  ]);
  const [newPhotoInput, setNewPhotoInput] = useState('');

  // New Bid Form State (Contractor)
  const [bidQuoteAmount, setBidQuoteAmount] = useState<number>(270000);
  const [timelineEstimate, setTimelineEstimate] = useState('7 Working Days');
  const [materialsIncluded, setMaterialsIncluded] = useState(true);
  const [itemizedItems, setItemizedItems] = useState<ItemizedQuote[]>([
    { description: 'Labor & EPRA Certified Testing', costKES: 70000 },
    { description: 'High-Capacity Inverter & Battery Bank', costKES: 160000 },
    { description: 'Heavy Copper Wiring & Distribution Panel', costKES: 40000 }
  ]);
  const [newItemDesc, setNewItemDesc] = useState('');
  const [newItemCost, setNewItemCost] = useState<number>(10000);
  const [bidNotes, setBidNotes] = useState('Includes 2-Year warranty and site cleanup.');

  // Chat input state
  const [chatInputText, setChatInputText] = useState('');
  const [isCounterOffer, setIsCounterOffer] = useState(false);
  const [counterAmount, setCounterAmount] = useState<number>(250000);

  const activeBrief = jobBriefs.find(b => b.id === selectedBriefId) || jobBriefs[0];
  const activeBidsForBrief = contractorBids.filter(b => b.briefId === activeBrief?.id);
  const activeBid = contractorBids.find(b => b.id === selectedBidId) || activeBidsForBrief[0];
  const activeMessages = negotiationMessages.filter(m => m.briefId === activeBrief?.id && m.bidId === activeBid?.id);

  const activeContractor = allProviders.find(p => p.id === actingContractorId) || allProviders[0];

  if (!isOpen) return null;

  const handleAddPhoto = () => {
    if (newPhotoInput.trim()) {
      setPhotoUrls([...photoUrls, newPhotoInput.trim()]);
      setNewPhotoInput('');
    }
  };

  const handleRemovePhoto = (idx: number) => {
    setPhotoUrls(photoUrls.filter((_, i) => i !== idx));
  };

  const handleAddItemizedRow = () => {
    if (newItemDesc.trim() && newItemCost > 0) {
      setItemizedItems([...itemizedItems, { description: newItemDesc.trim(), costKES: newItemCost }]);
      setNewItemDesc('');
      setNewItemCost(10000);
    }
  };

  const handleRemoveItemizedRow = (idx: number) => {
    setItemizedItems(itemizedItems.filter((_, i) => i !== idx));
  };

  const handlePostJobBrief = (e: React.FormEvent) => {
    e.preventDefault();
    if (!briefTitle.trim() || !briefDescription.trim()) return;

    const newBrief: JobBrief = {
      id: `brief-${Date.now()}`,
      title: briefTitle,
      category: briefCategory,
      location: briefLocation,
      county: briefCounty,
      budgetEstimateKES: budgetKES,
      isBudgetNegotiable,
      photos: photoUrls.length > 0 ? photoUrls : ['https://images.unsplash.com/photo-1541888946425-d0fbb186a5b3?auto=format&fit=crop&w=800&q=80'],
      description: briefDescription,
      clientName,
      clientPhone,
      status: 'OPEN_FOR_BIDS',
      createdAt: new Date().toISOString().split('T')[0],
      bidsCount: 0
    };

    onAddJobBrief(newBrief);
    setSelectedBriefId(newBrief.id);
    setActiveTab('BRIEFS_LIST');
    setBriefTitle('');
    setBriefDescription('');
  };

  const handleSubmitBid = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeBrief || !activeContractor) return;

    const totalFromItemized = itemizedItems.reduce((sum, item) => sum + item.costKES, 0);
    const finalQuote = totalFromItemized > 0 ? totalFromItemized : bidQuoteAmount;

    const newBid: ContractorBid = {
      id: `bid-${Date.now()}`,
      briefId: activeBrief.id,
      contractorId: activeContractor.id,
      contractorName: activeContractor.name,
      contractorSkill: activeContractor.tradeSkill,
      contractorAvatar: activeContractor.avatar,
      contractorPhone: activeContractor.phone,
      isContractorVerified: activeContractor.isVerified || (activeContractor.vettingInfo?.isVetted ?? true),
      quoteAmountKES: finalQuote,
      timelineEstimate,
      materialsIncluded,
      itemizedBreakdown: itemizedItems,
      notes: bidNotes,
      status: 'PENDING',
      submittedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    onAddBid(newBid);
    onUpdateBriefStatus(activeBrief.id, 'UNDER_NEGOTIATION');
    setSelectedBidId(newBid.id);
    
    // Automatically post initial quote message in chat
    const initialMsg: NegotiationMessage = {
      id: `msg-${Date.now()}`,
      briefId: activeBrief.id,
      bidId: newBid.id,
      senderType: 'CONTRACTOR',
      senderName: activeContractor.name,
      text: `Jambo ${activeBrief.clientName}! I submitted a detailed itemized quote of KES ${finalQuote.toLocaleString()} with a ${timelineEstimate} timeline. Let me know if you would like to discuss adjustments.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    onSendMessage(initialMsg);

    setActiveTab('CHAT_NEGOTIATE');
  };

  const handleSendChatMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInputText.trim() && !isCounterOffer) return;
    if (!activeBrief || !activeBid) return;

    const senderName = userRole === 'CLIENT' ? activeBrief.clientName : (activeContractor?.name || 'Contractor');

    const newMsg: NegotiationMessage = {
      id: `msg-${Date.now()}`,
      briefId: activeBrief.id,
      bidId: activeBid.id,
      senderType: userRole,
      senderName,
      text: chatInputText.trim() || (isCounterOffer ? `Proposed counteroffer: KES ${counterAmount.toLocaleString()}` : ''),
      proposedQuoteAmountKES: isCounterOffer ? counterAmount : undefined,
      isCounterOffer,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    onSendMessage(newMsg);

    if (isCounterOffer) {
      onUpdateBidStatus(activeBid.id, 'COUNTERED', counterAmount);
    }

    setChatInputText('');
    setIsCounterOffer(false);
  };

  const handleAcceptBidOffer = (bid: ContractorBid, agreedAmount?: number) => {
    const finalAmount = agreedAmount || bid.quoteAmountKES;
    onUpdateBidStatus(bid.id, 'ACCEPTED', finalAmount);
    onUpdateBriefStatus(bid.briefId, 'CONTRACT_AWARDED');

    // System message
    const sysMsg: NegotiationMessage = {
      id: `msg-${Date.now()}`,
      briefId: bid.briefId,
      bidId: bid.id,
      senderType: 'CLIENT',
      senderName: 'SYSTEM / CLIENT',
      text: `🎉 OFFER ACCEPTED! Agreed total quote is KES ${finalAmount.toLocaleString()}. Proceeding to GLOBALLICA Escrow deposit.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    onSendMessage(sysMsg);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto w-screen h-screen">
      <div className="bg-white rounded-2xl sm:rounded-3xl w-full max-w-[96vw] lg:max-w-5xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95 duration-200 my-auto">
        
        {/* Top Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-emerald-950 p-5 text-white flex items-center justify-between border-b border-amber-400/30">
          <div className="flex items-center gap-3">
            <div className="bg-amber-400 text-emerald-950 p-2.5 rounded-2xl font-black shadow-md shrink-0">
              <HardHat size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-amber-400 text-emerald-950 text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wide">
                  MAJOR PROJECTS & CONTRACTORS
                </span>
                <span className="text-emerald-300 text-xs font-semibold">Bidding & Live Quote Negotiation</span>
              </div>
              <h2 className="text-lg sm:text-xl font-extrabold text-white">
                Construction, Wiring & Heavy Jobs Marketplace
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-stone-400 hover:text-white p-2 rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tab Bar & Role Switcher */}
        <div className="bg-stone-900 px-5 pt-3 border-b border-stone-800 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 overflow-x-auto">
            <button
              onClick={() => setActiveTab('BRIEFS_LIST')}
              className={`px-4 py-2.5 rounded-t-xl text-xs font-extrabold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'BRIEFS_LIST'
                  ? 'bg-amber-400 text-emerald-950 shadow-md'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/60'
              }`}
            >
              <Building2 size={14} />
              <span>Project Briefs ({jobBriefs.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('POST_BRIEF')}
              className={`px-4 py-2.5 rounded-t-xl text-xs font-extrabold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'POST_BRIEF'
                  ? 'bg-amber-400 text-emerald-950 shadow-md'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/60'
              }`}
            >
              <Plus size={14} />
              <span>+ Post Project Brief</span>
            </button>

            <button
              onClick={() => setActiveTab('CHAT_NEGOTIATE')}
              className={`px-4 py-2.5 rounded-t-xl text-xs font-extrabold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'CHAT_NEGOTIATE'
                  ? 'bg-amber-400 text-emerald-950 shadow-md'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/60'
              }`}
            >
              <MessageSquare size={14} />
              <span>In-Chat Negotiation {activeBidsForBrief.length > 0 ? `(${activeBidsForBrief.length} Bids)` : ''}</span>
            </button>
          </div>

          {/* Perspective Switcher */}
          <div className="flex items-center gap-2 bg-stone-800 p-1 rounded-xl border border-stone-700">
            <span className="text-[10px] text-stone-400 font-bold px-1.5 uppercase">Simulate Role:</span>
            <button
              type="button"
              onClick={() => setUserRole('CLIENT')}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-black cursor-pointer transition-colors ${
                userRole === 'CLIENT'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              Client (House Owner)
            </button>
            <button
              type="button"
              onClick={() => setUserRole('CONTRACTOR')}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-black cursor-pointer transition-colors ${
                userRole === 'CONTRACTOR'
                  ? 'bg-amber-400 text-emerald-950 shadow-xs'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              Verified Contractor
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 max-h-[78vh] overflow-y-auto space-y-5">

          {/* TAB 1: PROJECT BRIEFS LIST */}
          {activeTab === 'BRIEFS_LIST' && (
            <div className="space-y-4">
              <div className="bg-stone-900 text-stone-200 p-4 rounded-2xl border border-stone-800 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-extrabold text-amber-300 text-sm flex items-center gap-1.5">
                    <Sparkles size={16} className="text-amber-300" />
                    Major Construction, Wiring & Installation Briefs
                  </h3>
                  <p className="text-stone-300 text-[11px] mt-0.5">
                    Clients upload photo briefs, blueprints, and budgets. Certified contractors submit detailed itemized quotes and negotiate terms securely.
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('POST_BRIEF')}
                  className="bg-amber-400 hover:bg-amber-300 text-emerald-950 px-4 py-2 rounded-xl text-xs font-black shadow cursor-pointer shrink-0 border border-amber-500"
                >
                  + Post Job Brief with Photos
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {jobBriefs.map(brief => {
                  const bids = contractorBids.filter(b => b.briefId === brief.id);
                  const isSelected = brief.id === selectedBriefId;

                  return (
                    <div
                      key={brief.id}
                      onClick={() => setSelectedBriefId(brief.id)}
                      className={`bg-white border-2 rounded-2xl overflow-hidden shadow-sm transition-all cursor-pointer flex flex-col justify-between ${
                        isSelected ? 'border-amber-400 ring-2 ring-amber-400/30' : 'border-stone-200 hover:border-emerald-600'
                      }`}
                    >
                      <div className="p-4 space-y-3">
                        
                        {/* Status & Category */}
                        <div className="flex items-center justify-between gap-2">
                          <span className="bg-emerald-100 text-emerald-950 text-[10px] font-extrabold px-2 py-0.5 rounded border border-emerald-300">
                            {brief.category}
                          </span>
                          <span className={`text-[10px] font-black px-2 py-0.5 rounded uppercase ${
                            brief.status === 'OPEN_FOR_BIDS'
                              ? 'bg-amber-100 text-amber-950 border border-amber-300'
                              : brief.status === 'UNDER_NEGOTIATION'
                              ? 'bg-blue-100 text-blue-900 border border-blue-300'
                              : 'bg-emerald-900 text-amber-300'
                          }`}>
                            ● {brief.status.replace('_', ' ')}
                          </span>
                        </div>

                        {/* Title */}
                        <h3 className="font-extrabold text-stone-900 text-sm leading-snug">
                          {brief.title}
                        </h3>

                        {/* Photo Thumbnail Strip */}
                        {brief.photos.length > 0 && (
                          <div className="flex items-center gap-1.5 overflow-x-auto py-1">
                            {brief.photos.map((img, i) => (
                              <img
                                key={i}
                                src={img}
                                alt="Site photo"
                                className="w-16 h-12 rounded-lg object-cover border border-stone-200 shrink-0"
                                referrerPolicy="no-referrer"
                              />
                            ))}
                            <span className="text-[10px] text-stone-400 font-bold px-1">
                              📸 {brief.photos.length} Photos
                            </span>
                          </div>
                        )}

                        <p className="text-xs text-stone-600 line-clamp-2">
                          {brief.description}
                        </p>

                        {/* Metadata */}
                        <div className="grid grid-cols-2 gap-2 text-[11px] bg-stone-50 p-2.5 rounded-xl border border-stone-100">
                          <div>
                            <span className="text-stone-400 font-bold block text-[10px]">Estimated Budget</span>
                            <span className="font-black text-emerald-900">KES {brief.budgetEstimateKES.toLocaleString()}</span>
                            {brief.isBudgetNegotiable && <span className="text-[9px] text-amber-700 block font-semibold">(Negotiable)</span>}
                          </div>
                          <div>
                            <span className="text-stone-400 font-bold block text-[10px]">Location</span>
                            <span className="font-bold text-stone-800">📍 {brief.location}</span>
                          </div>
                        </div>

                      </div>

                      {/* Card Footer Actions */}
                      <div className="bg-stone-50 p-3 border-t border-stone-100 flex items-center justify-between text-xs">
                        <span className="font-bold text-stone-700 flex items-center gap-1">
                          <HardHat size={14} className="text-amber-600" />
                          <span>{bids.length} Bids Submitted</span>
                        </span>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedBriefId(brief.id);
                            if (bids.length > 0) setSelectedBidId(bids[0].id);
                            setActiveTab('CHAT_NEGOTIATE');
                          }}
                          className="bg-emerald-950 hover:bg-emerald-900 text-amber-300 font-extrabold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          <span>View Bids & Negotiate</span>
                          <ChevronRight size={14} />
                        </button>
                      </div>

                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: POST NEW JOB BRIEF */}
          {activeTab === 'POST_BRIEF' && (
            <form onSubmit={handlePostJobBrief} className="space-y-4">
              
              <div className="bg-stone-900 text-stone-200 p-4 rounded-2xl border border-stone-800 text-xs space-y-1">
                <h3 className="font-extrabold text-amber-300 text-sm flex items-center gap-1.5">
                  <Camera size={16} className="text-amber-300" />
                  Post a Detailed Job Brief with Site Photos
                </h3>
                <p className="text-stone-300 text-[11px]">
                  Describe your project requirements, upload photos of the site/blueprint, and set an estimated budget. Verified contractors across Kenya will respond with itemized quotes.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-800 mb-1">Project Title / Scope Name</label>
                <input
                  type="text"
                  required
                  value={briefTitle}
                  onChange={(e) => setBriefTitle(e.target.value)}
                  placeholder="e.g. 3-Phase Electrical Installation & Solar Inverter Wiring"
                  className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3.5 py-2.5 text-xs font-bold text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-800 mb-1">Trade Category</label>
                  <select
                    value={briefCategory}
                    onChange={(e) => setBriefCategory(e.target.value as any)}
                    className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs font-bold text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                  >
                    <option value="Construction & Masonry">Construction & Masonry</option>
                    <option value="Electrical Wiring & Solar">Electrical Wiring & Solar</option>
                    <option value="Plumbing & Drainage">Plumbing & Drainage</option>
                    <option value="Roofing & Steelwork">Roofing & Steelwork</option>
                    <option value="Painting & Interior Fitout">Painting & Interior Fitout</option>
                    <option value="Borehole & Irrigation">Borehole & Irrigation</option>
                    <option value="Other Major Work">Other Major Work</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-800 mb-1">Site Location / Estate</label>
                  <input
                    type="text"
                    required
                    value={briefLocation}
                    onChange={(e) => setBriefLocation(e.target.value)}
                    placeholder="e.g. Kitisuru, Nairobi"
                    className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs font-bold text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-800 mb-1">Estimated Budget (KES)</label>
                  <input
                    type="number"
                    required
                    min={5000}
                    value={budgetKES}
                    onChange={(e) => setBudgetKES(Number(e.target.value))}
                    className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs font-bold text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                  />
                </div>
              </div>

              {/* Photos Section */}
              <div className="bg-stone-50 border border-stone-200 rounded-2xl p-4 space-y-3">
                <label className="block text-xs font-extrabold text-stone-900 uppercase tracking-wide flex items-center gap-1.5">
                  <Camera size={15} className="text-emerald-800" />
                  Site & Blueprint Photos
                </label>

                <div className="flex flex-wrap gap-2 items-center">
                  {photoUrls.map((url, idx) => (
                    <div key={idx} className="relative group">
                      <img
                        src={url}
                        alt="Brief Photo"
                        className="w-20 h-20 rounded-xl object-cover border-2 border-emerald-600 shadow-xs"
                        referrerPolicy="no-referrer"
                      />
                      <button
                        type="button"
                        onClick={() => handleRemovePhoto(idx)}
                        className="absolute -top-1.5 -right-1.5 bg-red-600 text-white rounded-full p-1 shadow-md hover:bg-red-700 transition-colors"
                      >
                        <X size={12} />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={newPhotoInput}
                    onChange={(e) => setNewPhotoInput(e.target.value)}
                    placeholder="Paste Photo URL (or use default site photos)..."
                    className="flex-1 bg-white border border-stone-200 rounded-xl px-3 py-2 text-xs font-bold text-stone-900 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleAddPhoto}
                    className="bg-emerald-950 text-amber-300 font-extrabold px-3 py-2 rounded-xl text-xs hover:bg-emerald-900 transition-colors cursor-pointer"
                  >
                    + Add Photo
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-800 mb-1">Detailed Requirements & Scope</label>
                <textarea
                  required
                  rows={4}
                  value={briefDescription}
                  onChange={(e) => setBriefDescription(e.target.value)}
                  placeholder="Describe electrical specs, material brands required, completion timeline, and any special access considerations..."
                  className="w-full bg-stone-50 border border-stone-200 rounded-xl p-3 text-xs font-bold text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black py-3 rounded-2xl text-xs transition-all shadow-md active:scale-98 cursor-pointer flex items-center justify-center gap-2 border border-amber-500"
              >
                <Sparkles size={18} className="text-emerald-950" />
                <span>Publish Project Brief to Contractor Network</span>
              </button>

            </form>
          )}

          {/* TAB 3: IN-CHAT NEGOTIATION & BIDDING */}
          {activeTab === 'CHAT_NEGOTIATE' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
              
              {/* Left Column: Bids Overview / Bid Submission (4 cols) */}
              <div className="lg:col-span-4 space-y-4">
                
                {/* Active Brief Card */}
                <div className="bg-stone-900 text-white rounded-2xl p-3.5 border border-amber-400/30 space-y-2">
                  <span className="bg-amber-400 text-emerald-950 text-[9px] font-black px-1.5 py-0.5 rounded uppercase">
                    ACTIVE PROJECT BRIEF
                  </span>
                  <h4 className="font-extrabold text-xs text-amber-300">{activeBrief?.title}</h4>
                  <p className="text-[11px] text-stone-300 font-medium">
                    📍 {activeBrief?.location} • Budget: <span className="font-bold text-white">KES {activeBrief?.budgetEstimateKES.toLocaleString()}</span>
                  </p>
                </div>

                {/* Submitting Contractor Bid Form if in Contractor Mode */}
                {userRole === 'CONTRACTOR' && (
                  <div className="bg-stone-50 border-2 border-amber-400/80 rounded-2xl p-3.5 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-black text-xs text-stone-900 flex items-center gap-1">
                        <HardHat size={15} className="text-amber-600" />
                        Submit Contractor Quote
                      </span>
                      <span className="text-[9px] bg-emerald-950 text-amber-300 font-extrabold px-1.5 py-0.5 rounded">
                        VERIFIED CONTRACTOR
                      </span>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-stone-700 mb-0.5">Estimated Timeline</label>
                      <input
                        type="text"
                        value={timelineEstimate}
                        onChange={(e) => setTimelineEstimate(e.target.value)}
                        className="w-full bg-white border border-stone-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-stone-900"
                      />
                    </div>

                    {/* Itemized breakdown inputs */}
                    <div className="space-y-1.5">
                      <span className="block text-[10px] font-extrabold text-stone-800 uppercase">Itemized Quote Breakdown</span>
                      {itemizedItems.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between text-[11px] bg-white p-1.5 rounded-lg border border-stone-200">
                          <span className="font-medium text-stone-800">{item.description}</span>
                          <div className="flex items-center gap-1">
                            <span className="font-bold text-emerald-900">KES {item.costKES.toLocaleString()}</span>
                            <button
                              type="button"
                              onClick={() => handleRemoveItemizedRow(idx)}
                              className="text-stone-400 hover:text-red-600"
                            >
                              <X size={12} />
                            </button>
                          </div>
                        </div>
                      ))}

                      <div className="flex items-center gap-1">
                        <input
                          type="text"
                          placeholder="Item (e.g. Solar Cables)"
                          value={newItemDesc}
                          onChange={(e) => setNewItemDesc(e.target.value)}
                          className="flex-1 bg-white border border-stone-200 rounded-lg px-2 py-1 text-[11px]"
                        />
                        <input
                          type="number"
                          value={newItemCost}
                          onChange={(e) => setNewItemCost(Number(e.target.value))}
                          className="w-16 bg-white border border-stone-200 rounded-lg px-2 py-1 text-[11px]"
                        />
                        <button
                          type="button"
                          onClick={handleAddItemizedRow}
                          className="bg-emerald-950 text-amber-300 px-2 py-1 rounded-lg text-[10px] font-black"
                        >
                          + Add
                        </button>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-stone-200 flex items-center justify-between">
                      <span className="text-[10px] font-bold text-stone-600">Total Quote Amount:</span>
                      <span className="text-sm font-black text-emerald-900">
                        KES {itemizedItems.reduce((s, x) => s + x.costKES, 0).toLocaleString()}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={handleSubmitBid}
                      className="w-full bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black py-2 rounded-xl text-xs shadow-sm cursor-pointer border border-amber-500"
                    >
                      Submit Itemized Bid to Client
                    </button>
                  </div>
                )}

                {/* Bids List for this Brief */}
                <div className="space-y-2">
                  <span className="block text-xs font-extrabold text-stone-800 uppercase tracking-wide">
                    Contractor Bids Received ({activeBidsForBrief.length})
                  </span>

                  {activeBidsForBrief.map(bid => {
                    const isSelected = bid.id === activeBid?.id;

                    return (
                      <div
                        key={bid.id}
                        onClick={() => setSelectedBidId(bid.id)}
                        className={`p-3 rounded-2xl border-2 transition-all cursor-pointer space-y-2 ${
                          isSelected
                            ? 'bg-amber-50 border-amber-400 shadow-sm'
                            : 'bg-white border-stone-200 hover:border-emerald-600'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <img
                              src={bid.contractorAvatar}
                              alt={bid.contractorName}
                              className="w-8 h-8 rounded-full object-cover border border-emerald-600 shrink-0"
                              referrerPolicy="no-referrer"
                            />
                            <div>
                              <h5 className="font-extrabold text-stone-900 text-xs">{bid.contractorName}</h5>
                              <span className="text-[10px] text-stone-500 font-medium">{bid.contractorSkill}</span>
                            </div>
                          </div>

                          <div className="text-right shrink-0">
                            <span className="font-black text-emerald-900 text-xs block">
                              KES {bid.quoteAmountKES.toLocaleString()}
                            </span>
                            <span className="text-[9px] text-stone-400 font-bold block">{bid.timelineEstimate}</span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-[10px]">
                          <span className={`font-black px-2 py-0.5 rounded ${
                            bid.status === 'ACCEPTED'
                              ? 'bg-emerald-900 text-amber-300'
                              : bid.status === 'COUNTERED'
                              ? 'bg-blue-100 text-blue-900'
                              : 'bg-stone-200 text-stone-800'
                          }`}>
                            ● {bid.status}
                          </span>
                          <span className="text-emerald-800 font-bold">Open Chat Negotiation →</span>
                        </div>
                      </div>
                    );
                  })}
                </div>

              </div>

              {/* Right Column: Negotiation Chat (8 cols) */}
              <div className="lg:col-span-8 bg-stone-50 border border-stone-200 rounded-2xl p-4 flex flex-col justify-between min-h-[480px]">
                
                {activeBid ? (
                  <>
                    {/* Chat Header */}
                    <div className="bg-white p-3 rounded-xl border border-stone-200 flex items-center justify-between gap-3 shadow-2xs">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={activeBid.contractorAvatar}
                          alt={activeBid.contractorName}
                          className="w-10 h-10 rounded-xl object-cover border-2 border-emerald-600"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <div className="flex items-center gap-1.5">
                            <h4 className="font-black text-stone-900 text-xs">{activeBid.contractorName}</h4>
                            {activeBid.isContractorVerified && (
                              <span className="bg-emerald-100 text-emerald-900 text-[9px] font-black px-1.5 py-0.5 rounded flex items-center gap-0.5 border border-emerald-300">
                                <ShieldCheck size={11} className="text-emerald-700" /> NCA Verified
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-stone-500 font-medium">
                            Timeline: {activeBid.timelineEstimate} • Tel: {activeBid.contractorPhone}
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-[9px] text-stone-400 uppercase font-bold block">Current Quote</span>
                        <span className="font-black text-emerald-950 text-sm">
                          KES {activeBid.quoteAmountKES.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    {/* Itemized Quote Card inside Chat Header */}
                    {activeBid.itemizedBreakdown.length > 0 && (
                      <div className="bg-stone-100 p-2.5 rounded-xl border border-stone-200 text-xs my-2 space-y-1">
                        <span className="font-extrabold text-[10px] text-stone-700 uppercase block">
                          Contractor Itemized Breakdown:
                        </span>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 text-[11px]">
                          {activeBid.itemizedBreakdown.map((item, i) => (
                            <div key={i} className="flex items-center justify-between bg-white px-2 py-1 rounded border border-stone-200">
                              <span className="text-stone-700 font-medium">{item.description}</span>
                              <span className="font-bold text-emerald-900">KES {item.costKES.toLocaleString()}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Chat Messages Feed */}
                    <div className="flex-1 overflow-y-auto space-y-3 py-3 px-1 my-2 max-h-[320px]">
                      {activeMessages.map((msg) => {
                        const isMe = (userRole === 'CLIENT' && msg.senderType === 'CLIENT') || (userRole === 'CONTRACTOR' && msg.senderType === 'CONTRACTOR');

                        return (
                          <div
                            key={msg.id}
                            className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                          >
                            <span className="text-[10px] text-stone-400 font-bold mb-0.5 px-1">
                              {msg.senderName} • {msg.timestamp}
                            </span>

                            <div className={`p-3 rounded-2xl max-w-sm text-xs shadow-2xs space-y-2 ${
                              isMe
                                ? 'bg-emerald-950 text-white rounded-tr-none'
                                : 'bg-white text-stone-800 rounded-tl-none border border-stone-200'
                            }`}>
                              <p className="leading-relaxed">{msg.text}</p>

                              {/* Counteroffer Badge/Card inside message */}
                              {msg.isCounterOffer && msg.proposedQuoteAmountKES && (
                                <div className="bg-amber-400 text-emerald-950 p-2.5 rounded-xl border border-amber-500 font-black space-y-1.5 shadow-sm">
                                  <div className="flex items-center justify-between text-[11px]">
                                    <span>💰 PROPOSED COUNTEROFFER:</span>
                                    <span className="text-sm">KES {msg.proposedQuoteAmountKES.toLocaleString()}</span>
                                  </div>

                                  {/* Action Buttons on Counteroffer */}
                                  {activeBid.status !== 'ACCEPTED' && (
                                    <div className="flex items-center gap-2 pt-1 border-t border-emerald-950/20">
                                      <button
                                        type="button"
                                        onClick={() => {
                                          handleAcceptBidOffer(activeBid, msg.proposedQuoteAmountKES);
                                          if (onOpenEscrowForBid && activeBrief) {
                                            onOpenEscrowForBid(activeBrief, activeBid);
                                          }
                                        }}
                                        className="flex-1 bg-emerald-950 text-amber-300 py-1 px-2 rounded-lg text-[10px] font-black hover:bg-emerald-900 transition-colors cursor-pointer"
                                      >
                                        ✓ Accept & Escrow KES {msg.proposedQuoteAmountKES.toLocaleString()}
                                      </button>
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Chat Controls Footer */}
                    <form onSubmit={handleSendChatMessage} className="bg-white p-3 rounded-xl border border-stone-200 space-y-2">
                      
                      {/* Counteroffer Toggle Row */}
                      <div className="flex items-center justify-between bg-stone-50 p-2 rounded-lg border border-stone-200 text-xs">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={isCounterOffer}
                            onChange={(e) => setIsCounterOffer(e.target.checked)}
                            className="rounded border-stone-300 text-amber-500 focus:ring-amber-400"
                          />
                          <span className="font-bold text-stone-800 text-[11px]">
                            Attach Official Counteroffer Amount
                          </span>
                        </label>

                        {isCounterOffer && (
                          <div className="flex items-center gap-1">
                            <span className="text-[10px] font-bold text-stone-500">Proposed KES:</span>
                            <input
                              type="number"
                              value={counterAmount}
                              onChange={(e) => setCounterAmount(Number(e.target.value))}
                              className="w-24 bg-white border border-stone-300 rounded px-2 py-0.5 text-xs font-black text-emerald-950"
                            />
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={chatInputText}
                          onChange={(e) => setChatInputText(e.target.value)}
                          placeholder={isCounterOffer ? "Add message explaining your counteroffer terms..." : "Type negotiation message or question..."}
                          className="flex-1 bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                        />
                        <button
                          type="submit"
                          className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm border border-amber-500"
                        >
                          <Send size={14} />
                          <span>Send</span>
                        </button>
                      </div>

                      {/* Accept Bid Button if not accepted yet */}
                      {activeBid.status !== 'ACCEPTED' && userRole === 'CLIENT' && (
                        <div className="pt-2 border-t border-stone-100 flex items-center justify-between">
                          <span className="text-[10px] text-stone-500 font-semibold">
                            Ready to finalize contractor agreement?
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              handleAcceptBidOffer(activeBid);
                              if (onOpenEscrowForBid && activeBrief) {
                                onOpenEscrowForBid(activeBrief, activeBid);
                              }
                            }}
                            className="bg-emerald-950 hover:bg-emerald-900 text-amber-300 font-black px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
                          >
                            <CheckCircle2 size={14} className="text-amber-300" />
                            <span>Accept Full Quote & Deposit Escrow (KES {activeBid.quoteAmountKES.toLocaleString()})</span>
                          </button>
                        </div>
                      )}

                    </form>
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-center space-y-2 text-stone-500 py-12">
                    <MessageSquare size={36} className="text-stone-300" />
                    <p className="font-bold text-xs">Select a contractor bid from the left to begin live chat negotiation.</p>
                  </div>
                )}

              </div>

            </div>
          )}

          {/* Footer close */}
          <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
            <span className="text-[11px] text-stone-500 font-medium">
              🔒 GLOBALLICA Escrow holds project funds until milestones are inspected & verified.
            </span>
            <button
              onClick={onClose}
              className="bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold px-4 py-2 rounded-xl text-xs transition-colors cursor-pointer"
            >
              Close Window
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
