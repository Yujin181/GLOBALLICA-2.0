import React, { useState } from 'react';
import { ServiceProvider } from '../types';
import { Wrench, PhoneCall, MessageSquare, ShieldCheck, MapPin, Star, UserCheck, CheckCircle, Clock, Zap, PlusCircle, Filter, Camera, Images, Eye, Film, Video, RefreshCw, HardHat, FileText } from 'lucide-react';
import { KENYAN_LOCATIONS, calculateDistanceKm } from '../data/locations';
import { getTradeSkillPhoto } from '../utils/categoryImages';

interface ServiceProvidersModuleProps {
  fundis: ServiceProvider[];
  selectedEstate: string;
  selectedCounty: string;
  onOpenFundiPortal: () => void;
  onOpenMediaPortal?: () => void;
  onOpenNtsaVerification?: () => void;
  onOpenDigitalVetting?: (fundi?: ServiceProvider) => void;
  onOpenEscrowTracker?: (fundi?: ServiceProvider) => void;
  onOpenLiveSelfie?: (fundi?: ServiceProvider) => void;
  onOpenSubscriptions?: (fundi?: ServiceProvider) => void;
  onOpenContractorNegotiation?: () => void;
  onHireFundiMpesa: (fundi: ServiceProvider) => void;
  onSelectFundi?: (fundi: ServiceProvider) => void;
}

export const ServiceProvidersModule: React.FC<ServiceProvidersModuleProps> = ({
  fundis,
  selectedEstate,
  selectedCounty,
  onOpenFundiPortal,
  onOpenMediaPortal,
  onOpenNtsaVerification,
  onOpenDigitalVetting,
  onOpenEscrowTracker,
  onOpenLiveSelfie,
  onOpenSubscriptions,
  onOpenContractorNegotiation,
  onHireFundiMpesa,
  onSelectFundi
}) => {
  const [selectedTrade, setSelectedTrade] = useState<string>('all');
  const [availabilityOnly, setAvailabilityOnly] = useState<boolean>(false);

  // Determine latitude/longitude of search estate if selected
  let searchLat = -1.2891; // default Nairobi Kilimani
  let searchLng = 36.7886;

  if (selectedEstate !== 'all') {
    for (const countyObj of KENYAN_LOCATIONS) {
      for (const constObj of countyObj.constituencies) {
        const foundEstate = constObj.estates.find(e => e.name === selectedEstate);
        if (foundEstate) {
          searchLat = foundEstate.lat;
          searchLng = foundEstate.lng;
          break;
        }
      }
    }
  }

  // Calculate distance for all fundis based on selected location
  const fundisWithDistance = fundis.map(f => {
    const dist = calculateDistanceKm(searchLat, searchLng, f.latitude, f.longitude);
    return { ...f, distanceKm: dist };
  });

  // Filter fundis
  const filtered = fundisWithDistance.filter(f => {
    if (selectedTrade !== 'all' && f.tradeSkill !== selectedTrade) return false;
    if (availabilityOnly && f.availability !== 'Available Now') return false;
    if (selectedCounty !== 'all') {
      const normSel = selectedCounty.replace(/^\d+:\s*/, '').trim().toLowerCase();
      const normCounty = (f.operationalCounty || '').replace(/^\d+:\s*/, '').trim().toLowerCase();
      if (normCounty !== normSel && !normCounty.includes(normSel) && !normSel.includes(normCounty)) return false;
    }
    return true;
  }).sort((a, b) => (a.distanceKm || 0) - (b.distanceKm || 0)); // Sort by closest distance!

  return (
    <div className="w-full max-w-full space-y-6">
      {/* Local Services Hero Banner */}
      <div className="w-full max-w-full bg-gradient-to-r from-emerald-950 via-emerald-900 to-amber-950 text-white p-4 sm:p-5 rounded-2xl shadow-lg border border-emerald-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-amber-400 text-emerald-950 font-black px-2 py-0.5 rounded text-[10px] uppercase">
              🛠️ Local Fundi Geolocation Directory
            </span>
            <span className="text-amber-300 text-xs font-bold">Closest Verified Mechanics & Plumbers</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            Find Nearby Fundis, Cabs, Lorries & Riders in {selectedEstate !== 'all' ? selectedEstate : 'Your Estate'}
          </h2>
          <p className="text-emerald-200 text-xs mt-1">
            Need a Cab / Uber ride, Lorry for hire, Plumber, Electrician, Mama Fua, or Boda Rider? Connect instantly with verified neighborhood drivers & fundis with real customer ratings.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {onOpenContractorNegotiation && (
            <button
              onClick={() => onOpenContractorNegotiation()}
              className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black px-3.5 py-2 rounded-xl text-xs shadow-md transition-all active:scale-95 cursor-pointer flex items-center gap-1.5 border border-amber-500 animate-pulse"
            >
              <HardHat size={16} className="text-emerald-950" />
              <span>🏗️ Major Jobs & Contractor Bidding</span>
            </button>
          )}

          {onOpenSubscriptions && (
            <button
              onClick={() => onOpenSubscriptions()}
              className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black px-3 py-2 rounded-xl text-xs shadow-md transition-all active:scale-95 cursor-pointer flex items-center gap-1.5 border border-amber-500"
            >
              <RefreshCw size={16} className="text-emerald-950" />
              <span>🔁 Domestic Help Subscriptions</span>
            </button>
          )}

          {onOpenLiveSelfie && (
            <button
              onClick={() => onOpenLiveSelfie()}
              className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black px-3 py-2 rounded-xl text-xs shadow-md transition-all active:scale-95 cursor-pointer flex items-center gap-1.5 border border-amber-500"
            >
              <Camera size={16} className="text-emerald-950" />
              <span>📸 AI Live Selfie Verification</span>
            </button>
          )}

          {onOpenDigitalVetting && (
            <button
              onClick={() => onOpenDigitalVetting()}
              className="bg-emerald-800 hover:bg-emerald-700 text-amber-300 border border-amber-400/50 font-extrabold px-3 py-2 rounded-xl text-xs shadow transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
            >
              <ShieldCheck size={16} className="text-amber-300" />
              <span>Digital Vetting (ID/DCI)</span>
            </button>
          )}

          {onOpenEscrowTracker && (
            <button
              onClick={() => onOpenEscrowTracker()}
              className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black px-3 py-2 rounded-xl text-xs shadow transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
            >
              <ShieldCheck size={16} />
              <span>Escrow Job Payments</span>
            </button>
          )}

          <button
            onClick={onOpenFundiPortal}
            className="bg-stone-900 hover:bg-stone-800 text-white font-extrabold px-3 py-2 rounded-xl text-xs shadow transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
          >
            <UserCheck size={16} />
            <span>New Fundi Reg</span>
          </button>

          {onOpenMediaPortal && (
            <button
              onClick={onOpenMediaPortal}
              className="bg-stone-900 hover:bg-stone-800 text-amber-300 border border-amber-400/40 font-extrabold px-3 py-2 rounded-xl text-xs shadow transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
            >
              <Film size={16} className="text-red-400" />
              <span>Attach Media</span>
            </button>
          )}
        </div>
      </div>

      {/* Major Jobs & Bidding Banner */}
      {onOpenContractorNegotiation && (
        <div className="bg-gradient-to-r from-stone-900 via-stone-850 to-stone-900 text-white p-4 rounded-2xl border border-amber-400/40 shadow-md flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="bg-amber-400 text-emerald-950 p-2.5 rounded-xl font-black shrink-0">
              <HardHat size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-xs text-amber-300 uppercase tracking-wide">
                  🏗️ BIG JOBS, WIRING & CONSTRUCTION
                </span>
                <span className="bg-emerald-900 text-amber-300 text-[10px] font-extrabold px-2 py-0.5 rounded border border-emerald-700">
                  Negotiation Chat & Counteroffers
                </span>
              </div>
              <p className="text-xs text-stone-300 mt-0.5">
                Posting a major building project, solar setup, or 3-phase electrical job? Post your brief with photos, receive itemized contractor quotes, and negotiate counteroffers in chat!
              </p>
            </div>
          </div>

          <button
            onClick={() => onOpenContractorNegotiation()}
            className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black px-4 py-2.5 rounded-xl text-xs shadow transition-all active:scale-95 cursor-pointer shrink-0 border border-amber-500 flex items-center gap-1.5"
          >
            <FileText size={16} />
            <span>Post Job Brief & View Bids</span>
          </button>
        </div>
      )}

      {/* Trades Filter Strip */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-stone-200 space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-bold text-xs text-stone-700 flex items-center gap-1.5">
            <Wrench size={15} className="text-emerald-700" />
            Select Trade Skill:
          </span>

          <label htmlFor="fundi-availability-only" className="flex items-center gap-2 text-xs font-bold text-stone-700 cursor-pointer">
            <input
              id="fundi-availability-only"
              name="availabilityOnly"
              aria-label="Show Available Now Only"
              type="checkbox"
              checked={availabilityOnly}
              onChange={(e) => setAvailabilityOnly(e.target.checked)}
              className="accent-emerald-700 rounded cursor-pointer"
            />
            <span className="text-emerald-800">Show "Available Now" Only</span>
          </label>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setSelectedTrade('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              selectedTrade === 'all'
                ? 'bg-emerald-800 text-white shadow'
                : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
            }`}
          >
            All Trades ({fundis.length})
          </button>

          {[
            { skill: 'Cab / Taxi Ride (Uber Style)', icon: '🚖' },
            { skill: 'Lorry / Truck For Hire', icon: '🚛' },
            { skill: 'Plumber', icon: '🚰' },
            { skill: 'Electrician', icon: '⚡' },
            { skill: 'Mama Fua / House Cleaner', icon: '🧹' },
            { skill: 'BodaBoda / Delivery', icon: '🛵' },
            { skill: 'Fundi / Carpenter', icon: '🪚' },
            { skill: 'Auto Mechanic', icon: '🔧' },
            { skill: 'Movers', icon: '📦' },
            { skill: 'Mason / Painter', icon: '🧱' }
          ].map(t => (
            <button
              key={t.skill}
              onClick={() => setSelectedTrade(t.skill)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                selectedTrade === t.skill
                  ? 'bg-emerald-800 text-white shadow'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              <span>{t.icon}</span>
              <span>{t.skill}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Fundis Cards */}
      {filtered.length === 0 ? (
        <div className="bg-stone-50 border border-dashed border-stone-300 rounded-2xl p-8 text-center text-stone-500 space-y-2">
          <Wrench size={36} className="mx-auto text-stone-400" />
          <h3 className="font-bold text-stone-700">No Fundis matching your filter criteria</h3>
          <p className="text-xs">Try unchecking "Available Now" or selecting another trade skill.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((fundi) => {
            const fundiWaLink = `https://wa.me/${fundi.whatsapp}?text=${encodeURIComponent(
              `Jambo ${fundi.name}, I need a ${fundi.tradeSkill} in ${selectedEstate !== 'all' ? selectedEstate : fundi.operationalEstate}, ${fundi.operationalCounty}. Are you free to come over?`
            )}`;

            return (
              <div
                key={fundi.id}
                className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between p-5 space-y-4"
              >
                {/* Header Profile Info */}
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <img
                          src={fundi.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'}
                          alt={fundi.name}
                          onError={(e) => {
                            e.currentTarget.src = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80';
                          }}
                          className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-600 shadow-sm"
                          referrerPolicy="no-referrer"
                        />
                        {fundi.availability === 'Available Now' && (
                          <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-white rounded-full animate-pulse" title="Available Now" />
                        )}
                      </div>

                      <div>
                        <div className="flex items-center gap-1.5">
                          <h3 className="font-extrabold text-stone-900 text-sm sm:text-base leading-tight">
                            {fundi.name}
                          </h3>
                          {fundi.isVerified && (
                            <span title="Verified Fundi Badge">
                              <ShieldCheck size={16} className="text-emerald-600 shrink-0" />
                            </span>
                          )}
                        </div>

                        <span className="inline-block bg-amber-100 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded-md border border-amber-300 mt-1">
                          {fundi.tradeSkill}
                        </span>
                      </div>
                    </div>

                    {/* Geolocation Distance Tag */}
                    <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2 text-right shrink-0">
                      <div className="text-[10px] font-bold text-emerald-800 flex items-center gap-1 justify-end">
                        <MapPin size={11} className="text-emerald-700" />
                        <span>{fundi.distanceKm !== undefined ? `${fundi.distanceKm} km` : 'Near'}</span>
                      </div>
                      <span className="text-[9px] text-stone-500 block font-semibold">
                        {fundi.operationalEstate}
                      </span>
                    </div>
                  </div>

                  {/* Status & Badge Row */}
                  <div className="mt-3 flex items-center justify-between text-xs bg-stone-50 p-2 rounded-xl border border-stone-200/60">
                    <div className="flex items-center gap-1">
                      <Star size={14} className="text-amber-500 fill-amber-500" />
                      <span className="font-bold text-stone-900">{fundi.rating}</span>
                      <span className="text-stone-500 text-[11px]">({fundi.reviewsCount} reviews • {fundi.completedJobsCount} jobs)</span>
                    </div>

                    <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                      fundi.availability === 'Available Now'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      ● {fundi.availability}
                    </span>
                  </div>

                  {/* Digital Anti-Scam Vetting Badge or Vetting Trigger */}
                  {fundi.vettingInfo?.isVetted ? (
                    <div className="mt-2.5 bg-emerald-950 text-emerald-300 p-2 rounded-xl border border-amber-400/60 flex items-center justify-between text-[11px]">
                      <span className="font-extrabold flex items-center gap-1">
                        <ShieldCheck size={14} className="text-amber-300" />
                        <span>🛡️ IPRS ID & DCI Good Conduct Verified</span>
                      </span>
                      <span className="text-[10px] text-amber-300 font-mono font-bold">
                        ID: {fundi.vettingInfo.nationalIdNo}
                      </span>
                    </div>
                  ) : onOpenDigitalVetting && (
                    <button
                      type="button"
                      onClick={() => onOpenDigitalVetting(fundi)}
                      className="mt-2.5 w-full bg-stone-900 hover:bg-stone-800 text-amber-300 border border-stone-700 p-2 rounded-xl text-[11px] font-bold flex items-center justify-between transition-colors cursor-pointer"
                    >
                      <span className="flex items-center gap-1">
                        <ShieldCheck size={13} className="text-amber-400" /> Run Digital Vetting / DCI Check
                      </span>
                      <span className="text-[10px] bg-amber-400 text-stone-950 px-1.5 py-0.5 rounded font-black">
                        Vet Now
                      </span>
                    </button>
                  )}

                  {/* Subscribe & Auto-Book Escrow Button */}
                  {onOpenSubscriptions && (
                    <button
                      type="button"
                      onClick={() => onOpenSubscriptions(fundi)}
                      className="mt-2 w-full bg-emerald-950 hover:bg-emerald-900 text-amber-300 border border-amber-400/40 p-2 rounded-xl text-[11px] font-extrabold flex items-center justify-between transition-colors cursor-pointer shadow-xs"
                    >
                      <span className="flex items-center gap-1.5">
                        <RefreshCw size={13} className="text-amber-300" /> Subscribe & Auto-Book Help
                      </span>
                      <span className="text-[10px] bg-amber-400 text-emerald-950 px-2 py-0.5 rounded font-black">
                        Auto-Escrow
                      </span>
                    </button>
                  )}

                  {/* AI Live Selfie Verification Badge / Trigger */}
                  {fundi.liveSelfieVerification?.isSelfieVerified ? (
                    <div className="mt-2 bg-gradient-to-r from-emerald-950 to-emerald-900 text-amber-300 p-2 rounded-xl border border-emerald-600 flex items-center justify-between text-[11px]">
                      <span className="font-extrabold flex items-center gap-1">
                        <Camera size={13} className="text-amber-300" />
                        <span>📸 AI Live Selfie Face Matched</span>
                      </span>
                      <span className="text-[10px] bg-amber-400 text-emerald-950 font-black px-1.5 py-0.5 rounded">
                        {fundi.liveSelfieVerification.matchedScorePercent}% MATCH
                      </span>
                    </div>
                  ) : onOpenLiveSelfie && (
                    <button
                      type="button"
                      onClick={() => onOpenLiveSelfie(fundi)}
                      className="mt-2 w-full bg-stone-100 hover:bg-stone-200 text-stone-900 border border-stone-300 p-2 rounded-xl text-[11px] font-bold flex items-center justify-between transition-colors cursor-pointer"
                    >
                      <span className="flex items-center gap-1">
                        <Camera size={13} className="text-emerald-800" /> Require AI Live Selfie Verification
                      </span>
                      <span className="text-[10px] bg-emerald-800 text-amber-300 px-1.5 py-0.5 rounded font-black">
                        Verify Face
                      </span>
                    </button>
                  )}

                  {/* Bio Description */}
                  <p className="text-xs text-stone-600 mt-3 line-clamp-3 leading-relaxed">
                    {fundi.bio}
                  </p>

                  {/* Specific Skills Pills */}
                  <div className="mt-3 flex flex-wrap gap-1">
                    {fundi.skillsList.slice(0, 3).map((skill) => (
                      <span key={skill} className="bg-stone-100 text-stone-700 text-[10px] font-semibold px-2 py-0.5 rounded-md">
                        ✓ {skill}
                      </span>
                    ))}
                  </div>

                  {/* Job Showcase Portfolio Preview Bar */}
                  {fundi.portfolioShowcase && fundi.portfolioShowcase.length > 0 && (
                    <div className="mt-3 pt-2.5 border-t border-stone-100">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-[10px] font-bold text-stone-700 flex items-center gap-1">
                          <Camera size={12} className="text-emerald-700" />
                          <span>Showcase ({fundi.portfolioShowcase.length} Jobs)</span>
                          {fundi.portfolioShowcase.some(s => s.videoUrl) && (
                            <span className="bg-red-100 text-red-700 text-[9px] font-extrabold px-1.5 py-0.2 rounded-md flex items-center gap-0.5">
                              <Video size={10} /> Videos
                            </span>
                          )}
                        </span>
                        <button
                          onClick={() => onSelectFundi && onSelectFundi(fundi)}
                          className="text-[10px] text-emerald-800 font-extrabold hover:underline flex items-center gap-0.5 cursor-pointer"
                        >
                          <span>View Media</span>
                          <Eye size={11} />
                        </button>
                      </div>

                      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                        {fundi.portfolioShowcase.map((showcase) => (
                          <div
                            key={showcase.id}
                            onClick={() => onSelectFundi && onSelectFundi(fundi)}
                            className="relative w-16 h-12 rounded-lg overflow-hidden shrink-0 border border-stone-200 cursor-pointer group bg-black"
                            title={showcase.title}
                          >
                            <img
                              src={showcase.photoUrl || getTradeSkillPhoto(fundi.tradeSkill)}
                              alt={showcase.title}
                              onError={(e) => {
                                e.currentTarget.src = getTradeSkillPhoto(fundi.tradeSkill);
                              }}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform opacity-90"
                              referrerPolicy="no-referrer"
                            />
                            {showcase.videoUrl && (
                              <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                                <div className="w-5 h-5 rounded-full bg-red-600 text-white flex items-center justify-center shadow">
                                  <Video size={10} />
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Footer Pricing & Direct Call / WhatsApp */}
                <div className="pt-3 border-t border-stone-100 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-stone-400 block">Rate Model</span>
                      <span className="text-sm font-black text-emerald-900">
                        KES {fundi.rateKES.toLocaleString()} <span className="text-[10px] font-bold text-stone-500">/ {fundi.pricingModel}</span>
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {onOpenEscrowTracker && (
                        <button
                          type="button"
                          onClick={() => onOpenEscrowTracker(fundi)}
                          className="bg-emerald-950 hover:bg-emerald-900 text-amber-300 font-extrabold px-2.5 py-1.5 rounded-xl text-xs transition-all border border-emerald-700 shadow-sm cursor-pointer flex items-center gap-1"
                          title="Pay via GLOBALLICA Escrow with Release Code"
                        >
                          <span>🔒 Escrow</span>
                        </button>
                      )}

                      <button
                        onClick={() => onHireFundiMpesa(fundi)}
                        className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black px-3 py-1.5 rounded-xl text-xs transition-all shadow-sm cursor-pointer border border-amber-300"
                      >
                        Book & Pay
                      </button>
                    </div>
                  </div>

                  {/* Contact Buttons */}
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <a
                      href={`tel:${fundi.phone}`}
                      className="flex items-center justify-center gap-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2 px-3 rounded-xl text-xs transition-colors shadow-sm cursor-pointer"
                    >
                      <PhoneCall size={14} />
                      <span>Call Fundi</span>
                    </a>

                    <a
                      href={fundiWaLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 px-3 rounded-xl text-xs transition-colors shadow-sm cursor-pointer"
                    >
                      <MessageSquare size={14} />
                      <span>WhatsApp</span>
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
