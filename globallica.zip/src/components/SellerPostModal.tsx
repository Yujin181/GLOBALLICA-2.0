import React, { useState, useEffect } from 'react';
import { X, PlusCircle, ShoppingBag, Car, Tag, ShieldCheck, Phone, QrCode } from 'lucide-react';
import { ProductListing } from '../types';
import { useAuth } from '../context/AuthContext';
import { getProductCategoryPhoto } from '../utils/categoryImages';

interface SellerPostModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddProduct: (prod: ProductListing) => void;
  onOpenNtsaVerification?: () => void;
}

export const SellerPostModal: React.FC<SellerPostModalProps> = ({
  isOpen,
  onClose,
  onAddProduct,
  onOpenNtsaVerification
}) => {
  const { userProfile, currentUser } = useAuth();

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ProductListing['category']>('Vehicles');
  const [priceKES, setPriceKES] = useState<number>(4500000);
  const [condition, setCondition] = useState<ProductListing['condition']>('Foreign Used (Import)');
  const [county, setCounty] = useState('Nairobi');
  const [estate, setEstate] = useState('Kilimani');
  const [sellerName, setSellerName] = useState('Mvule Motors');
  const [sellerPhone, setSellerPhone] = useState('+254712001122');
  const [photoUrl, setPhotoUrl] = useState('https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=800&q=80');
  const [description, setDescription] = useState('');

  // Automatically update suggested photoUrl when user picks a different category
  const handleCategoryChange = (newCat: ProductListing['category']) => {
    setCategory(newCat);
    setPhotoUrl(getProductCategoryPhoto(newCat));
  };

  useEffect(() => {
    if (userProfile) {
      if (userProfile.displayName) setSellerName(userProfile.displayName);
      if (userProfile.phoneNumber) setSellerPhone(userProfile.phoneNumber);
      if (userProfile.county) setCounty(userProfile.county.split(':')[1]?.trim() || userProfile.county);
      if (userProfile.estate) setEstate(userProfile.estate);
    }
  }, [userProfile]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !estate) return;

    const newProd: ProductListing = {
      id: `prod-${Date.now()}`,
      title,
      category,
      priceKES: Number(priceKES),
      isNegotiable: true,
      condition,
      county,
      estate,
      photos: photoUrl && photoUrl.trim().length > 0 ? [photoUrl.trim()] : [getProductCategoryPhoto(category)],
      description: description || 'Clean item ready for immediate pick-up or delivery.',
      sellerName,
      sellerPhone,
      sellerWhatsapp: sellerPhone.replace('+', ''),
      isSellerVerified: true,
      status: 'Available',
      featured: true,
      createdAt: new Date().toISOString().split('T')[0]
    };

    onAddProduct(newProd);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-stone-200 my-8 space-y-5 animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-900 text-amber-400 flex items-center justify-center font-bold">
              <PlusCircle size={22} />
            </div>
            <div>
              <h2 className="font-black text-xl text-stone-900">Post Vehicle or Product Ad</h2>
              <p className="text-xs text-stone-500">Sell your car, electronics, furniture, or goods across Kenya</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-full transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs font-semibold">
          {/* Seller details */}
          <div className="bg-stone-50 border border-stone-200 rounded-2xl p-3 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="seller-name-input" className="block text-stone-800 mb-1 font-bold">Seller Name / Shop</label>
              <input
                id="seller-name-input"
                name="sellerName"
                type="text"
                required
                value={sellerName}
                onChange={(e) => setSellerName(e.target.value)}
                className="w-full bg-white border border-stone-300 rounded-xl p-2.5 text-stone-900"
              />
            </div>

            <div>
              <label htmlFor="seller-phone-input" className="block text-stone-800 mb-1 font-bold">Phone Number (+254...)</label>
              <input
                id="seller-phone-input"
                name="sellerPhone"
                type="text"
                required
                value={sellerPhone}
                onChange={(e) => setSellerPhone(e.target.value)}
                className="w-full bg-white border border-stone-300 rounded-xl p-2.5 text-stone-900"
              />
            </div>
          </div>

          {/* Title */}
          <div>
            <label htmlFor="seller-ad-title" className="block text-stone-700 mb-1 font-bold">Ad Title</label>
            <input
              id="seller-ad-title"
              name="title"
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Toyota Prado TXL 2017 Pearl White or Samsung 55 Inch Smart TV"
              className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900"
            />
          </div>

          {/* Category & Condition */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="seller-category-select" className="block text-stone-700 mb-1 font-bold">Category</label>
              <select
                id="seller-category-select"
                name="category"
                value={category}
                onChange={(e) => handleCategoryChange(e.target.value as any)}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900 cursor-pointer"
              >
                <option value="Vehicles">Vehicles & Cars</option>
                <option value="Electronics & Phones">Electronics & Phones</option>
                <option value="Home & Furniture">Home & Furniture</option>
                <option value="Farm & Agribusiness">Farm & Agribusiness</option>
                <option value="Tools & Building">Tools & Building</option>
              </select>
            </div>

            <div>
              <label htmlFor="seller-condition-select" className="block text-stone-700 mb-1 font-bold">Condition</label>
              <select
                id="seller-condition-select"
                name="condition"
                value={condition}
                onChange={(e) => setCondition(e.target.value as any)}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900 cursor-pointer"
              >
                <option value="Brand New">Brand New</option>
                <option value="Foreign Used (Import)">Foreign Used (Import)</option>
                <option value="Kenyan Used">Kenyan Used</option>
              </select>
            </div>
          </div>

          {/* NTSA Logbook Verification Prompt for Vehicles */}
          {category === 'Vehicles' && (
            <div className="bg-emerald-950 text-white p-3.5 rounded-2xl border border-amber-400/50 flex items-center justify-between gap-3">
              <div className="space-y-0.5">
                <div className="flex items-center gap-1.5 text-amber-300 font-extrabold text-xs">
                  <QrCode size={15} />
                  <span>NTSA Strict Logbook QR Verification</span>
                </div>
                <p className="text-[11px] text-emerald-200">
                  Scan your vehicle's NTSA logbook QR code to get an authentic <strong>🛡️ NTSA TIMS VERIFIED</strong> badge for buyer trust.
                </p>
              </div>

              {onOpenNtsaVerification && (
                <button
                  type="button"
                  onClick={onOpenNtsaVerification}
                  className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black text-xs px-3 py-2 rounded-xl shrink-0 transition-transform active:scale-95 cursor-pointer"
                >
                  Scan QR Code
                </button>
              )}
            </div>
          )}

          {/* Price & Estate */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="seller-price-input" className="block text-stone-700 mb-1 font-bold">Price in KES</label>
              <input
                id="seller-price-input"
                name="priceKES"
                type="number"
                required
                value={priceKES}
                onChange={(e) => setPriceKES(Number(e.target.value))}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900"
              />
            </div>

            <div>
              <label htmlFor="seller-estate-input" className="block text-stone-700 mb-1 font-bold">Estate / Location</label>
              <input
                id="seller-estate-input"
                name="estate"
                type="text"
                required
                value={estate}
                onChange={(e) => setEstate(e.target.value)}
                placeholder="e.g. Kilimani, Nairobi CBD"
                className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900"
              />
            </div>
          </div>

          {/* Photo */}
          <div>
            <label htmlFor="seller-photo-url" className="block text-stone-700 mb-1 font-bold">Photo Image URL</label>
            <input
              id="seller-photo-url"
              name="photoUrl"
              type="text"
              value={photoUrl}
              onChange={(e) => setPhotoUrl(e.target.value)}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900"
            />
          </div>

          {/* Description */}
          <div>
            <label htmlFor="seller-description-input" className="block text-stone-700 mb-1 font-bold">Description & Specs</label>
            <textarea
              id="seller-description-input"
              name="description"
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Provide specs, year of manufacture, mileage, condition..."
              className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900"
            />
          </div>

          {/* Submit */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black py-3 rounded-2xl text-sm shadow-xl transition-transform active:scale-98 cursor-pointer flex items-center justify-center gap-2 border border-amber-300"
            >
              <ShoppingBag size={18} />
              <span>Post Listing to GLOBALLICA Market</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
