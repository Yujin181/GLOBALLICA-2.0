import React from 'react';
import { Home, Wrench, ShoppingBag, Truck, PlusCircle } from 'lucide-react';

interface MobileNavProps {
  activeCategory: string;
  setActiveCategory: (cat: string) => void;
  onOpenCaretakerPortal: () => void;
  onOpenFundiPortal: () => void;
  onOpenSellerPortal: () => void;
  onOpenArchitectureModal: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  activeCategory,
  setActiveCategory,
  onOpenCaretakerPortal,
  onOpenFundiPortal,
  onOpenSellerPortal,
  onOpenArchitectureModal
}) => {
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-emerald-950 text-white border-t border-emerald-800 shadow-2xl px-2 py-2">
      <div className="grid grid-cols-5 items-center justify-between text-center text-[10px]">
        <button
          onClick={() => setActiveCategory('housing')}
          className={`flex flex-col items-center gap-1 py-1 px-1 rounded-lg transition-all ${
            activeCategory === 'housing' ? 'text-amber-400 font-bold' : 'text-emerald-200'
          }`}
        >
          <Home size={18} />
          <span>Housing</span>
        </button>

        <button
          onClick={() => setActiveCategory('services')}
          className={`flex flex-col items-center gap-1 py-1 px-1 rounded-lg transition-all ${
            activeCategory === 'services' ? 'text-amber-400 font-bold' : 'text-emerald-200'
          }`}
        >
          <Wrench size={18} />
          <span>Fundis</span>
        </button>

        <button
          onClick={onOpenSellerPortal}
          className="flex flex-col items-center justify-center -mt-5"
        >
          <div className="w-12 h-12 rounded-full bg-amber-400 text-emerald-950 flex items-center justify-center shadow-lg border-2 border-emerald-950 hover:scale-105 active:scale-95 transition-transform">
            <PlusCircle size={24} />
          </div>
          <span className="text-amber-300 font-bold text-[9px] mt-0.5">Post Ad</span>
        </button>

        <button
          onClick={() => setActiveCategory('transport')}
          className={`flex flex-col items-center gap-1 py-1 px-1 rounded-lg transition-all ${
            activeCategory === 'transport' ? 'text-amber-400 font-bold' : 'text-emerald-200'
          }`}
        >
          <Truck size={18} />
          <span>Transport</span>
        </button>

        <button
          onClick={() => setActiveCategory('marketplace')}
          className={`flex flex-col items-center gap-1 py-1 px-1 rounded-lg transition-all ${
            activeCategory === 'marketplace' ? 'text-amber-400 font-bold' : 'text-emerald-200'
          }`}
        >
          <ShoppingBag size={18} />
          <span>Market</span>
        </button>
      </div>
    </div>
  );
};
