import React, { useState, useEffect } from 'react';
import { X, Wrench, ShieldCheck, UserCheck, MapPin, DollarSign, QrCode } from 'lucide-react';
import { ServiceProvider } from '../types';
import { KENYAN_LOCATIONS } from '../data/locations';
import { useAuth } from '../context/AuthContext';
import { getTradeSkillPhoto } from '../utils/categoryImages';

interface FundiOnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddFundi: (fundi: ServiceProvider) => void;
  onOpenNtsaVerification?: () => void;
}

export const FundiOnboardingModal: React.FC<FundiOnboardingModalProps> = ({
  isOpen,
  onClose,
  onAddFundi,
  onOpenNtsaVerification
}) => {
  const { userProfile } = useAuth();

  const [name, setName] = useState('John "Master" Otieno');
  const [phone, setPhone] = useState('+254711223344');
  const [tradeSkill, setTradeSkill] = useState<ServiceProvider['tradeSkill']>('Plumber');
  const [county, setCounty] = useState('Nairobi');
  const [estate, setEstate] = useState('Roysambu');
  const [pricingModel, setPricingModel] = useState<ServiceProvider['pricingModel']>('Per Job');
  const [rateKES, setRateKES] = useState<number>(1500);
  const [bio, setBio] = useState('Experienced plumber providing emergency leak repair, instant shower installation, and drainage clearing in Roysambu & Kasarani.');
  const [skills, setSkills] = useState('Instant Shower Installation, Burst Pipe Repair, Unblocking Sinks');
  const [showcaseTitle, setShowcaseTitle] = useState('4-Stage Instant Shower & Concealed Piping');
  const [showcaseDesc, setShowcaseDesc] = useState('Completed instant shower fitting and PPR water piping in 2BR apartment.');
  const [showcasePhoto, setShowcasePhoto] = useState('https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=600&q=80');

  const handleTradeSkillChange = (newTrade: ServiceProvider['tradeSkill']) => {
    setTradeSkill(newTrade);
    setShowcasePhoto(getTradeSkillPhoto(newTrade));
  };

  useEffect(() => {
    if (userProfile) {
      if (userProfile.displayName) setName(userProfile.displayName);
      if (userProfile.phoneNumber) setPhone(userProfile.phoneNumber);
      if (userProfile.county) setCounty(userProfile.county.split(':')[1]?.trim() || userProfile.county);
      if (userProfile.estate) setEstate(userProfile.estate);
    }
  }, [userProfile]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !estate) return;

    const newFundi: ServiceProvider = {
      id: `fundi-${Date.now()}`,
      name,
      phone,
      whatsapp: phone.replace('+', ''),
      tradeSkill,
      operationalCounty: county,
      operationalEstate: estate,
      latitude: -1.2185,
      longitude: 36.8860,
      pricingModel,
      rateKES: Number(rateKES),
      availability: 'Available Now',
      isVerified: true,
      badge: 'Verified Fundi',
      rating: 5.0,
      reviewsCount: 1,
      avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=200&q=80',
      bio,
      skillsList: skills.split(',').map(s => s.trim()),
      completedJobsCount: 1,
      portfolioShowcase: [
        {
          id: `showcase-${Date.now()}`,
          title: showcaseTitle || 'Recent Job Showcase',
          description: showcaseDesc || 'Verified work completed for local resident.',
          photoUrl: showcasePhoto && showcasePhoto.trim().length > 0 ? showcasePhoto.trim() : getTradeSkillPhoto(tradeSkill),
          completedDate: 'Recent',
          location: estate
        }
      ]
    };

    onAddFundi(newFundi);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-stone-200 my-8 space-y-5 animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400 text-emerald-950 flex items-center justify-center font-bold">
              <UserCheck size={22} />
            </div>
            <div>
              <h2 className="font-black text-xl text-stone-900">Fundi & Service Provider Onboarding</h2>
              <p className="text-xs text-stone-500">Register your trade skill to receive customer calls in your estate</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-full transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs font-semibold">
          {/* Name & Phone */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="fundi-full-name" className="block text-stone-700 mb-1 font-bold">Your Full Name / Brand</label>
              <input
                id="fundi-full-name"
                name="name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="fundi-phone" className="block text-stone-700 mb-1 font-bold">Phone Number (+254...)</label>
              <input
                id="fundi-phone"
                name="phone"
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
              />
            </div>
          </div>

          {/* Trade Skill & Pricing */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="fundi-trade-skill" className="block text-stone-700 mb-1 font-bold">Select Your Primary Trade</label>
              <select
                id="fundi-trade-skill"
                name="tradeSkill"
                value={tradeSkill}
                onChange={(e) => handleTradeSkillChange(e.target.value as any)}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900 cursor-pointer"
              >
                <option value="Plumber">Plumber</option>
                <option value="Electrician">Electrician</option>
                <option value="Cab / Taxi Ride (Uber Style)">Cab / Taxi Driver (Uber Style)</option>
                <option value="Lorry / Truck For Hire">Lorry / Heavy Truck Owner for Hire</option>
                <option value="BodaBoda / Delivery">BodaBoda / Delivery Rider</option>
                <option value="Auto Mechanic">Auto Mechanic</option>
                <option value="Fundi / Carpenter">Fundi / Carpenter</option>
                <option value="Mama Fua / House Cleaner">Mama Fua / House Cleaner</option>
                <option value="Mason / Painter">Mason / Painter</option>
                <option value="Movers">Movers & Haulage</option>
                <option value="Appliance Repair">Appliance Repair</option>
              </select>
            </div>

            {/* NTSA Logbook QR Verification Banner for Cabs & Lorries */}
            {(tradeSkill === 'Cab / Taxi Ride (Uber Style)' || tradeSkill === 'Lorry / Truck For Hire') && (
              <div className="sm:col-span-2 bg-emerald-950 text-white p-3.5 rounded-2xl border border-amber-400/50 flex items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-1.5 text-amber-300 font-extrabold text-xs">
                    <QrCode size={15} />
                    <span>NTSA Logbook QR Code Digital Verification</span>
                  </div>
                  <p className="text-[11px] text-emerald-200">
                    Verify your Cab/Lorry logbook via NTSA QR scanning to receive a verified <strong>🛡️ NTSA TIMS LOGBOOK</strong> badge on your driver profile.
                  </p>
                </div>

                {onOpenNtsaVerification && (
                  <button
                    type="button"
                    onClick={onOpenNtsaVerification}
                    className="bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black text-xs px-3 py-2 rounded-xl shrink-0 transition-transform active:scale-95 cursor-pointer"
                  >
                    Scan Logbook QR
                  </button>
                )}
              </div>
            )}

            <div>
              <label htmlFor="fundi-pricing-model" className="block text-stone-700 mb-1 font-bold">Pricing Model</label>
              <select
                id="fundi-pricing-model"
                name="pricingModel"
                value={pricingModel}
                onChange={(e) => setPricingModel(e.target.value as any)}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900 cursor-pointer"
              >
                <option value="Per Job">Per Job</option>
                <option value="Per Hour">Per Hour</option>
                <option value="Negotiable">Negotiable</option>
              </select>
            </div>
          </div>

          {/* Rate & Base Estate */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="fundi-rate" className="block text-stone-700 mb-1 font-bold">Base Rate (KES)</label>
              <input
                id="fundi-rate"
                name="rateKES"
                type="number"
                required
                value={rateKES}
                onChange={(e) => setRateKES(Number(e.target.value))}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900"
              />
            </div>

            <div>
              <label htmlFor="fundi-estate" className="block text-stone-700 mb-1 font-bold">Operational Estate / Ward</label>
              <input
                id="fundi-estate"
                name="estate"
                type="text"
                required
                value={estate}
                onChange={(e) => setEstate(e.target.value)}
                placeholder="e.g. Roysambu, Kilimani, Westlands"
                className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900"
              />
            </div>
          </div>

          {/* Skills List */}
          <div>
            <label htmlFor="fundi-skills" className="block text-stone-700 mb-1 font-bold">Specific Skills (comma separated)</label>
            <input
              id="fundi-skills"
              name="skills"
              type="text"
              value={skills}
              onChange={(e) => setSkills(e.target.value)}
              placeholder="e.g. Instant Shower Installation, Burst Pipe Repair, Solar Panels"
              className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900"
            />
          </div>

          {/* Bio */}
          <div>
            <label htmlFor="fundi-bio" className="block text-stone-700 mb-1 font-bold">Profile Bio & Experience</label>
            <textarea
              id="fundi-bio"
              name="bio"
              rows={2}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl p-2.5 text-stone-900"
            />
          </div>

          {/* Job Showcase Photo & Portfolio */}
          <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-2xl space-y-2">
            <span className="font-extrabold text-emerald-950 text-xs block">📸 Showcase Your Past Completed Job (Optional)</span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <label htmlFor="fundi-showcase-title" className="block text-[11px] text-stone-700 mb-0.5">Job Title</label>
                <input
                  id="fundi-showcase-title"
                  name="showcaseTitle"
                  type="text"
                  value={showcaseTitle}
                  onChange={(e) => setShowcaseTitle(e.target.value)}
                  placeholder="e.g. Instant Shower Installation"
                  className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-900 text-xs"
                />
              </div>
              <div>
                <label htmlFor="fundi-showcase-photo" className="block text-[11px] text-stone-700 mb-0.5">Photo URL or Image Link</label>
                <input
                  id="fundi-showcase-photo"
                  name="showcasePhoto"
                  type="url"
                  value={showcasePhoto}
                  onChange={(e) => setShowcasePhoto(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-900 text-xs"
                />
              </div>
            </div>
            <div>
              <label htmlFor="fundi-showcase-desc" className="block text-[11px] text-stone-700 mb-0.5">Brief Work Description</label>
              <input
                id="fundi-showcase-desc"
                name="showcaseDesc"
                type="text"
                value={showcaseDesc}
                onChange={(e) => setShowcaseDesc(e.target.value)}
                placeholder="e.g. Installed 4-stage instant shower and concealed PPR piping"
                className="w-full bg-white border border-stone-200 rounded-lg p-2 text-stone-900 text-xs"
              />
            </div>
          </div>

          {/* Submit CTA */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black py-3 rounded-2xl text-sm shadow-xl transition-transform active:scale-98 cursor-pointer flex items-center justify-center gap-2 border border-amber-300"
            >
              <Wrench size={18} />
              <span>Join GLOBALLICA Local Fundi Directory</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
