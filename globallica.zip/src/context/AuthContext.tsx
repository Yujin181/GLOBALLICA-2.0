import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged, firebaseSignOut, auth, getUserProfile, UserProfile, saveUserProfile } from '../lib/firebase';

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  isAuthModalOpen: boolean;
  openAuthModal: () => void;
  closeAuthModal: () => void;
  signOutUser: () => Promise<void>;
  setUserProfile: React.Dispatch<React.SetStateAction<UserProfile | null>>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  currentUser: null,
  userProfile: null,
  loading: true,
  isAuthModalOpen: false,
  openAuthModal: () => {},
  closeAuthModal: () => {},
  signOutUser: async () => {},
  setUserProfile: () => {},
  refreshProfile: async () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);

  const refreshProfile = async () => {
    if (currentUser) {
      const profile = await getUserProfile(currentUser.uid);
      if (profile) {
        setUserProfile(profile);
      } else {
        // Create default profile if missing
        const newProf: UserProfile = {
          uid: currentUser.uid,
          phoneNumber: currentUser.phoneNumber || 'Unspecified',
          displayName: currentUser.displayName || `User ${currentUser.phoneNumber?.slice(-4) || 'Account'}`,
          role: 'resident',
          verifiedPhone: true,
          createdAt: new Date().toISOString()
        };
        await saveUserProfile(newProf);
        setUserProfile(newProf);
      }
    } else {
      setUserProfile(null);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        const profile = await getUserProfile(user.uid);
        if (profile) {
          setUserProfile(profile);
        } else {
          const defaultProf: UserProfile = {
            uid: user.uid,
            phoneNumber: user.phoneNumber || '+254700000000',
            displayName: user.displayName || `Fundi ${user.phoneNumber?.slice(-4) || 'Member'}`,
            role: 'fundi',
            verifiedPhone: true,
            createdAt: new Date().toISOString()
          };
          await saveUserProfile(defaultProf);
          setUserProfile(defaultProf);
        }
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signOutUser = async () => {
    try {
      await firebaseSignOut(auth);
      setCurrentUser(null);
      setUserProfile(null);
    } catch (err) {
      console.error("Sign out error:", err);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        loading,
        isAuthModalOpen,
        openAuthModal: () => setIsAuthModalOpen(true),
        closeAuthModal: () => setIsAuthModalOpen(false),
        signOutUser,
        setUserProfile,
        refreshProfile
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
