export interface WardEstate {
  name: string;
  lat: number;
  lng: number;
}

export interface Constituency {
  name: string;
  estates: WardEstate[];
}

export interface CountyLocation {
  county: string;
  constituencies: Constituency[];
}

export const KENYAN_LOCATIONS: CountyLocation[] = [
  {
    county: '001: Mombasa',
    constituencies: [
      {
        name: 'Nyali',
        estates: [
          { name: 'Nyali Estate', lat: -4.0322, lng: 39.6918 },
          { name: 'Bamburi', lat: -4.0080, lng: 39.7120 },
          { name: 'Links Road', lat: -4.0280, lng: 39.6980 },
          { name: 'Kisauni', lat: -4.0200, lng: 39.6750 },
          { name: 'Frere Town', lat: -4.0380, lng: 39.6800 }
        ]
      },
      {
        name: 'Mvita',
        estates: [
          { name: 'Mombasa Island CBD', lat: -4.0547, lng: 39.6636 },
          { name: 'Tudor', lat: -4.0410, lng: 39.6610 },
          { name: 'Tononoka', lat: -4.0500, lng: 39.6600 },
          { name: 'Ganjoni', lat: -4.0620, lng: 39.6680 }
        ]
      },
      {
        name: 'Likoni',
        estates: [
          { name: 'Likoni Ferry', lat: -4.0820, lng: 39.6620 },
          { name: 'Shelly Beach', lat: -4.0950, lng: 39.6720 },
          { name: 'Mtongwe', lat: -4.0880, lng: 39.6450 }
        ]
      },
      {
        name: 'Changamwe & Jomvu',
        estates: [
          { name: 'Changamwe Town', lat: -4.0290, lng: 39.6250 },
          { name: 'Mikindani', lat: -4.0150, lng: 39.6200 },
          { name: 'Miritini', lat: -3.9980, lng: 39.5950 }
        ]
      },
      {
        name: 'Kisauni',
        estates: [
          { name: 'Magogoni', lat: -4.0110, lng: 39.6820 },
          { name: 'Mwakirunge', lat: -3.9520, lng: 39.6880 }
        ]
      }
    ]
  },
  {
    county: '002: Kwale',
    constituencies: [
      {
        name: 'Msambweni',
        estates: [
          { name: 'Diani Beach', lat: -4.2797, lng: 39.5947 },
          { name: 'Ukunda Town', lat: -4.2882, lng: 39.5684 },
          { name: 'Msambweni Town', lat: -4.4711, lng: 39.4789 }
        ]
      },
      {
        name: 'Matuga',
        estates: [
          { name: 'Kwale Town CBD', lat: -4.1738, lng: 39.4521 },
          { name: 'Tiwi', lat: -4.2381, lng: 39.5788 },
          { name: 'Waa', lat: -4.1950, lng: 39.6100 }
        ]
      },
      {
        name: 'Lunga Lunga & Kinango',
        estates: [
          { name: 'Lunga Lunga Border', lat: -4.5512, lng: 39.1231 },
          { name: 'Kinango Town', lat: -4.1350, lng: 39.3180 },
          { name: 'Vanga', lat: -4.6530, lng: 39.2180 }
        ]
      }
    ]
  },
  {
    county: '003: Kilifi',
    constituencies: [
      {
        name: 'Malindi',
        estates: [
          { name: 'Malindi Town CBD', lat: -3.2192, lng: 40.1169 },
          { name: 'Watamu Beach', lat: -3.3520, lng: 40.0170 },
          { name: 'Casuarina', lat: -3.2350, lng: 40.1310 }
        ]
      },
      {
        name: 'Kilifi North & South',
        estates: [
          { name: 'Kilifi Town CBD', lat: -3.6300, lng: 39.8530 },
          { name: 'Mtwapa', lat: -3.9450, lng: 39.7420 },
          { name: 'Vipingo', lat: -3.8180, lng: 39.8100 },
          { name: 'Kikambala', lat: -3.8820, lng: 39.7750 }
        ]
      },
      {
        name: 'Magarini, Ganze & Rabai',
        estates: [
          { name: 'Kaloleni', lat: -3.8050, lng: 39.6520 },
          { name: 'Rabai', lat: -3.9310, lng: 39.5620 },
          { name: 'Ganze Town', lat: -3.4500, lng: 39.7500 }
        ]
      }
    ]
  },
  {
    county: '004: Tana River',
    constituencies: [
      {
        name: 'Garsen, Galole & Bura',
        estates: [
          { name: 'Hola Town CBD', lat: -1.5031, lng: 40.0312 },
          { name: 'Garsen Town', lat: -2.2680, lng: 40.1150 },
          { name: 'Bura Town', lat: -1.0850, lng: 39.9520 }
        ]
      }
    ]
  },
  {
    county: '005: Lamu',
    constituencies: [
      {
        name: 'Lamu West & East',
        estates: [
          { name: 'Lamu Old Town CBD', lat: -2.2686, lng: 40.9020 },
          { name: 'Shela Village', lat: -2.2950, lng: 40.9120 },
          { name: 'Mpeketoni Town', lat: -2.3920, lng: 40.6920 },
          { name: 'Kiwayu Island', lat: -2.0120, lng: 41.1620 }
        ]
      }
    ]
  },
  {
    county: '006: Taita-Taveta',
    constituencies: [
      {
        name: 'Voi, Wundanyi & Taveta',
        estates: [
          { name: 'Voi Town CBD', lat: -3.3962, lng: 38.5562 },
          { name: 'Taveta Town', lat: -3.3980, lng: 37.6810 },
          { name: 'Wundanyi Town', lat: -3.4020, lng: 38.3620 },
          { name: 'Mwatate', lat: -3.5050, lng: 38.3750 }
        ]
      }
    ]
  },
  {
    county: '007: Garissa',
    constituencies: [
      {
        name: 'Garissa Township & Dadaab',
        estates: [
          { name: 'Garissa CBD', lat: -0.4532, lng: 39.6460 },
          { name: 'Dadaab Town', lat: 0.0820, lng: 40.3120 },
          { name: 'Masalani', lat: -1.6850, lng: 40.1310 }
        ]
      }
    ]
  },
  {
    county: '008: Wajir',
    constituencies: [
      {
        name: 'Wajir East, West, North & South',
        estates: [
          { name: 'Wajir Town CBD', lat: 1.7471, lng: 40.0573 },
          { name: 'Buna Town', lat: 2.7620, lng: 39.5120 },
          { name: 'Habaswein', lat: 1.0120, lng: 39.4880 }
        ]
      }
    ]
  },
  {
    county: '009: Mandera',
    constituencies: [
      {
        name: 'Mandera East, West & Elwak',
        estates: [
          { name: 'Mandera Town CBD', lat: 3.9373, lng: 41.8569 },
          { name: 'Elwak Town', lat: 2.8020, lng: 40.9280 },
          { name: 'Rhamu Town', lat: 3.9210, lng: 41.2210 }
        ]
      }
    ]
  },
  {
    county: '010: Marsabit',
    constituencies: [
      {
        name: 'Saku, Moyale & Laisamis',
        estates: [
          { name: 'Marsabit Town CBD', lat: 2.3283, lng: 37.9899 },
          { name: 'Moyale Border Town', lat: 3.5180, lng: 39.0550 },
          { name: 'Loiyangalani', lat: 2.7520, lng: 36.7150 }
        ]
      }
    ]
  },
  {
    county: '011: Isiolo',
    constituencies: [
      {
        name: 'Isiolo North & South',
        estates: [
          { name: 'Isiolo Town CBD', lat: 0.3546, lng: 37.5823 },
          { name: 'Garbatulla', lat: 0.3250, lng: 38.5180 },
          { name: 'Merti Town', lat: 1.0520, lng: 38.6650 }
        ]
      }
    ]
  },
  {
    county: '012: Meru',
    constituencies: [
      {
        name: 'Imenti North & South',
        estates: [
          { name: 'Meru Town CBD', lat: 0.0467, lng: 37.6556 },
          { name: 'Makutano (Meru)', lat: 0.0580, lng: 37.6490 },
          { name: 'Nkubu Town', lat: -0.0620, lng: 37.6630 }
        ]
      },
      {
        name: 'Tigania & Igembe',
        estates: [
          { name: 'Maua Town', lat: 0.2320, lng: 37.9410 },
          { name: 'Mikinduri', lat: 0.1280, lng: 37.8120 },
          { name: 'Timau', lat: 0.0820, lng: 37.2410 }
        ]
      }
    ]
  },
  {
    county: '013: Tharaka-Nithi',
    constituencies: [
      {
        name: 'Maara, Chuka & Tharaka',
        estates: [
          { name: 'Chuka Town CBD', lat: -0.3328, lng: 37.6481 },
          { name: 'Kathwana (County HQ)', lat: -0.3890, lng: 37.8120 },
          { name: 'Chogoria Town', lat: -0.2310, lng: 37.6250 }
        ]
      }
    ]
  },
  {
    county: '014: Embu',
    constituencies: [
      {
        name: 'Manyatta, Runyenjes & Mbeere',
        estates: [
          { name: 'Embu Town CBD', lat: -0.5383, lng: 37.4583 },
          { name: 'Runyenjes Town', lat: -0.4180, lng: 37.5620 },
          { name: 'Kiritiri Town', lat: -0.7620, lng: 37.6520 }
        ]
      }
    ]
  },
  {
    county: '015: Kitui',
    constituencies: [
      {
        name: 'Kitui Central, Mwingi & South',
        estates: [
          { name: 'Kitui Town CBD', lat: -1.3670, lng: 38.0106 },
          { name: 'Mwingi Town', lat: -0.9320, lng: 38.0610 },
          { name: 'Mutomo Town', lat: -1.8420, lng: 38.2120 }
        ]
      }
    ]
  },
  {
    county: '016: Machakos',
    constituencies: [
      {
        name: 'Mavoko (Syokimau / Athi River)',
        estates: [
          { name: 'Syokimau', lat: -1.3611, lng: 36.9389 },
          { name: 'Athi River Town', lat: -1.4550, lng: 36.9800 },
          { name: 'Mlolongo', lat: -1.3850, lng: 36.9300 },
          { name: 'Daystar University Area', lat: -1.4420, lng: 37.0120 }
        ]
      },
      {
        name: 'Machakos Town & Kangundo',
        estates: [
          { name: 'Machakos Town CBD', lat: -1.5167, lng: 37.2667 },
          { name: 'Tala Town', lat: -1.2420, lng: 37.3210 },
          { name: 'Kangundo Town', lat: -1.2980, lng: 37.3510 },
          { name: 'Matuu Town', lat: -1.1410, lng: 37.5420 }
        ]
      }
    ]
  },
  {
    county: '017: Makueni',
    constituencies: [
      {
        name: 'Makueni, Kaiti, Kibwezi & Kilome',
        estates: [
          { name: 'Wote Town CBD', lat: -1.7808, lng: 37.6288 },
          { name: 'Kibwezi Town', lat: -2.4180, lng: 37.9620 },
          { name: 'Sultan Hamud', lat: -2.0210, lng: 37.3710 },
          { name: 'Emali Town', lat: -2.0820, lng: 37.4620 }
        ]
      }
    ]
  },
  {
    county: '018: Nyandarua',
    constituencies: [
      {
        name: 'Ol Kalou, Kinangop & Kipipiri',
        estates: [
          { name: 'Ol Kalou Town CBD', lat: -0.2711, lng: 36.3789 },
          { name: 'Engineer Town', lat: -0.6380, lng: 36.5810 },
          { name: 'Njabini', lat: -0.7320, lng: 36.6620 },
          { name: 'Mairo Inya', lat: -0.1250, lng: 36.3120 }
        ]
      }
    ]
  },
  {
    county: '019: Nyeri',
    constituencies: [
      {
        name: 'Nyeri Town',
        estates: [
          { name: 'Nyeri CBD', lat: -0.4201, lng: 36.9476 },
          { name: 'King\'ong\'o', lat: -0.4110, lng: 36.9580 },
          { name: 'Skuta', lat: -0.4350, lng: 36.9380 }
        ]
      },
      {
        name: 'Karatina & Othaya',
        estates: [
          { name: 'Karatina Town CBD', lat: -0.4811, lng: 37.1289 },
          { name: 'Othaya Town', lat: -0.5420, lng: 36.9480 },
          { name: 'Mukurweini', lat: -0.5620, lng: 37.0520 }
        ]
      }
    ]
  },
  {
    county: '020: Kirinyaga',
    constituencies: [
      {
        name: 'Kirinyaga Central, Mwea & Gichugu',
        estates: [
          { name: 'Kerugoya Town CBD', lat: -0.4989, lng: 37.2811 },
          { name: 'Wang\'uru (Mwea)', lat: -0.6820, lng: 37.3520 },
          { name: 'Kutus Town (County HQ)', lat: -0.5610, lng: 37.3180 },
          { name: 'Sagana Town', lat: -0.6650, lng: 37.2080 }
        ]
      }
    ]
  },
  {
    county: '021: Murang\'a',
    constituencies: [
      {
        name: 'Maragua, Kiharu & Thika Borders',
        estates: [
          { name: 'Murang\'a Town CBD', lat: -0.7210, lng: 37.1520 },
          { name: 'Kenol Town', lat: -0.9120, lng: 37.1280 },
          { name: 'Maragua Town', lat: -0.7820, lng: 37.1350 },
          { name: 'Kangema', lat: -0.6850, lng: 36.9620 }
        ]
      }
    ]
  },
  {
    county: '022: Kiambu',
    constituencies: [
      {
        name: 'Ruiru & Juja',
        estates: [
          { name: 'Ruiru Town CBD', lat: -1.1470, lng: 36.9610 },
          { name: 'Membley Estate', lat: -1.1680, lng: 36.9450 },
          { name: 'Kahawa Sukari', lat: -1.1890, lng: 36.9230 },
          { name: 'Kahawa Wendani', lat: -1.1960, lng: 36.9180 },
          { name: 'Juja Town', lat: -1.1020, lng: 37.0120 },
          { name: 'Kalimoni', lat: -1.0920, lng: 37.0250 }
        ]
      },
      {
        name: 'Kiambaa & Ruaka',
        estates: [
          { name: 'Ruaka Town', lat: -1.2058, lng: 36.7761 },
          { name: 'Banana Hill', lat: -1.1710, lng: 36.7520 },
          { name: 'Muchatha', lat: -1.1920, lng: 36.7680 },
          { name: 'Lower Kabete', lat: -1.2420, lng: 36.7350 }
        ]
      },
      {
        name: 'Kiambu Town & Kikuyu',
        estates: [
          { name: 'Kiambu Town CBD', lat: -1.1714, lng: 36.8356 },
          { name: 'Kirigiti', lat: -1.1630, lng: 36.8420 },
          { name: 'Kikuyu Town', lat: -1.2540, lng: 36.6640 },
          { name: 'Thogoto', lat: -1.2650, lng: 36.6710 }
        ]
      },
      {
        name: 'Thika Town & Gatundu',
        estates: [
          { name: 'Thika Town CBD', lat: -1.0333, lng: 37.0694 },
          { name: 'Landless / Nkurumah', lat: -1.0420, lng: 37.0980 },
          { name: 'Gatundu Town', lat: -1.0020, lng: 36.9020 }
        ]
      }
    ]
  },
  {
    county: '023: Turkana',
    constituencies: [
      {
        name: 'Turkana Central, North & South',
        estates: [
          { name: 'Lodwar Town CBD', lat: 3.1191, lng: 35.5973 },
          { name: 'Kakuma Town', lat: 3.7120, lng: 34.8580 },
          { name: 'Lokichogio', lat: 4.2050, lng: 34.3510 },
          { name: 'Lokichar', lat: 2.3820, lng: 35.6520 }
        ]
      }
    ]
  },
  {
    county: '024: West Pokot',
    constituencies: [
      {
        name: 'Kapenguria, Sigor & Kacheliba',
        estates: [
          { name: 'Kapenguria CBD', lat: 1.2411, lng: 35.1128 },
          { name: 'Makutano (Pokot)', lat: 1.2320, lng: 35.1250 },
          { name: 'Chepareria', lat: 1.3120, lng: 35.2020 }
        ]
      }
    ]
  },
  {
    county: '025: Samburu',
    constituencies: [
      {
        name: 'Samburu West, North & East',
        estates: [
          { name: 'Maralal Town CBD', lat: 1.0967, lng: 36.6981 },
          { name: 'Archer\'s Post', lat: 0.6520, lng: 37.6780 },
          { name: 'Baragoi', lat: 1.7820, lng: 36.7820 }
        ]
      }
    ]
  },
  {
    county: '026: Trans-Nzoia',
    constituencies: [
      {
        name: 'Saboti, Kiminini & Cherangany',
        estates: [
          { name: 'Kitale Town CBD', lat: 1.0157, lng: 35.0062 },
          { name: 'Kiminini Town', lat: 0.8820, lng: 34.9120 },
          { name: 'Endebess', lat: 1.0820, lng: 34.8520 }
        ]
      }
    ]
  },
  {
    county: '027: Uasin Gishu',
    constituencies: [
      {
        name: 'Ainabkoi & Kapseret (Eldoret)',
        estates: [
          { name: 'Eldoret CBD', lat: 0.5143, lng: 35.2698 },
          { name: 'Elgon View', lat: 0.5010, lng: 35.2750 },
          { name: 'Pioneer Estate', lat: 0.5050, lng: 35.2810 },
          { name: 'Annex / Langas', lat: 0.4880, lng: 35.2880 },
          { name: 'Kimumu / University', lat: 0.5520, lng: 35.2950 }
        ]
      },
      {
        name: 'Turbo & Moiben',
        estates: [
          { name: 'Turbo Town', lat: 0.6350, lng: 35.0520 },
          { name: 'Moiben Town', lat: 0.6520, lng: 35.4120 }
        ]
      }
    ]
  },
  {
    county: '028: Elgeyo-Marakwet',
    constituencies: [
      {
        name: 'Keiyo North/South & Marakwet',
        estates: [
          { name: 'Iten Town (Home of Champions)', lat: 0.6722, lng: 35.5083 },
          { name: 'Kapsowar Town', lat: 0.9820, lng: 35.5620 },
          { name: 'Fluorspar / Tambach', lat: 0.5980, lng: 35.5310 }
        ]
      }
    ]
  },
  {
    county: '029: Nandi',
    constituencies: [
      {
        name: 'Emgwen, Mosop, Aldai & Tinderet',
        estates: [
          { name: 'Kapsabet Town CBD', lat: 0.2042, lng: 35.1022 },
          { name: 'Nandi Hills Town', lat: 0.1080, lng: 35.1820 },
          { name: 'Mosoriot', lat: 0.3320, lng: 35.1720 }
        ]
      }
    ]
  },
  {
    county: '030: Baringo',
    constituencies: [
      {
        name: 'Baringo Central, Eldama Ravine & Baringo North',
        estates: [
          { name: 'Kabarnet Town CBD', lat: 0.4919, lng: 35.7431 },
          { name: 'Eldama Ravine Town', lat: 0.0520, lng: 35.7280 },
          { name: 'Marigat Town', lat: 0.4720, lng: 35.9820 }
        ]
      }
    ]
  },
  {
    county: '031: Laikipia',
    constituencies: [
      {
        name: 'Laikipia East & West',
        estates: [
          { name: 'Nanyuki Town CBD', lat: 0.0167, lng: 37.0722 },
          { name: 'Nyahururu Town', lat: 0.0420, lng: 36.3620 },
          { name: 'Rumuruti Town (County HQ)', lat: 0.2680, lng: 36.5380 }
        ]
      }
    ]
  },
  {
    county: '032: Nakuru',
    constituencies: [
      {
        name: 'Nakuru East & West',
        estates: [
          { name: 'Nakuru City CBD', lat: -0.2833, lng: 36.0667 },
          { name: 'Milimani Estate', lat: -0.2780, lng: 36.0680 },
          { name: 'Section 58', lat: -0.2850, lng: 36.0820 },
          { name: 'Free Area', lat: -0.2920, lng: 36.0950 },
          { name: 'Kaptembwa / Njoro', lat: -0.3010, lng: 36.0250 }
        ]
      },
      {
        name: 'Naivasha & Gilgil',
        estates: [
          { name: 'Naivasha Town CBD', lat: -0.7167, lng: 36.4333 },
          { name: 'Moi South Lake Road', lat: -0.7820, lng: 36.3820 },
          { name: 'Gilgil Town', lat: -0.4920, lng: 36.2880 }
        ]
      }
    ]
  },
  {
    county: '033: Narok',
    constituencies: [
      {
        name: 'Narok North, South, East & West',
        estates: [
          { name: 'Narok Town CBD', lat: -1.0833, lng: 35.8667 },
          { name: 'Kilgoris Town', lat: -1.0120, lng: 34.8820 },
          { name: 'Maasai Mara Gate Area', lat: -1.4820, lng: 35.1280 }
        ]
      }
    ]
  },
  {
    county: '034: Kajiado',
    constituencies: [
      {
        name: 'Kajiado East (Kitengela / Athi Triangle)',
        estates: [
          { name: 'Kitengela Town CBD', lat: -1.4780, lng: 36.9580 },
          { name: 'Acacia Estate', lat: -1.4920, lng: 36.9450 },
          { name: 'Isinya Town', lat: -1.6820, lng: 36.8520 }
        ]
      },
      {
        name: 'Kajiado North (Rongai / Ngong / Kiserian)',
        estates: [
          { name: 'Ongata Rongai CBD', lat: -1.3960, lng: 36.7590 },
          { name: 'Ngong Town', lat: -1.3610, lng: 36.6560 },
          { name: 'Kiserian Town', lat: -1.4390, lng: 36.6850 }
        ]
      }
    ]
  },
  {
    county: '035: Kericho',
    constituencies: [
      {
        name: 'Ainamoi, Belgut, Bureti & Kipkelion',
        estates: [
          { name: 'Kericho Town CBD', lat: -0.3689, lng: 35.2863 },
          { name: 'Litein Town', lat: -0.5820, lng: 35.1880 },
          { name: 'Kipkelion Town', lat: -0.2180, lng: 35.4680 }
        ]
      }
    ]
  },
  {
    county: '036: Bomet',
    constituencies: [
      {
        name: 'Bomet Central, Sotik, Chepalungu & Konoin',
        estates: [
          { name: 'Bomet Town CBD', lat: -0.7811, lng: 35.3411 },
          { name: 'Sotik Town', lat: -0.6820, lng: 35.1180 },
          { name: 'Mugango / Silibwet', lat: -0.7520, lng: 35.3280 }
        ]
      }
    ]
  },
  {
    county: '037: Kakamega',
    constituencies: [
      {
        name: 'Lurambi & Kakamega Central',
        estates: [
          { name: 'Kakamega City CBD', lat: 0.2827, lng: 34.7519 },
          { name: 'Keffinco Estate', lat: 0.2910, lng: 34.7580 },
          { name: 'Amalemba', lat: 0.2750, lng: 34.7420 },
          { name: 'Milimani Kakamega', lat: 0.2880, lng: 34.7480 }
        ]
      },
      {
        name: 'Mumias & Malava',
        estates: [
          { name: 'Mumias Town CBD', lat: 0.3347, lng: 34.4878 },
          { name: 'Malava Town', lat: 0.4420, lng: 34.8520 }
        ]
      }
    ]
  },
  {
    county: '038: Vihiga',
    constituencies: [
      {
        name: 'Sabatia, Vihiga, Hamisi & Luanda',
        estates: [
          { name: 'Mbale Town (County HQ)', lat: 0.0811, lng: 34.7211 },
          { name: 'Luanda Town', lat: 0.0020, lng: 34.5980 },
          { name: 'Chavakali Town', lat: 0.1280, lng: 34.7210 }
        ]
      }
    ]
  },
  {
    county: '039: Bungoma',
    constituencies: [
      {
        name: 'Kanduyi & Kimilili',
        estates: [
          { name: 'Bungoma Town CBD', lat: 0.5636, lng: 34.5606 },
          { name: 'Kimilili Town', lat: 0.7820, lng: 34.7180 },
          { name: 'Webuye Town', lat: 0.6080, lng: 34.7710 },
          { name: 'Sirisia', lat: 0.7320, lng: 34.4820 }
        ]
      }
    ]
  },
  {
    county: '040: Busia',
    constituencies: [
      {
        name: 'Matayos, Nambale, Teso & Samia',
        estates: [
          { name: 'Busia Border Town CBD', lat: 0.4608, lng: 34.1115 },
          { name: 'Malaba Border Town', lat: 0.6380, lng: 34.2780 },
          { name: 'Port Victoria', lat: 0.1020, lng: 33.9820 }
        ]
      }
    ]
  },
  {
    county: '041: Siaya',
    constituencies: [
      {
        name: 'Alego Usonga, Bondo, Gem & Rarieda',
        estates: [
          { name: 'Siaya Town CBD', lat: 0.0607, lng: 34.2878 },
          { name: 'Bondo Town', lat: -0.0980, lng: 34.2780 },
          { name: 'Ugunja Town', lat: 0.1820, lng: 34.2980 },
          { name: 'Ngiya', lat: 0.0380, lng: 34.3680 }
        ]
      }
    ]
  },
  {
    county: '042: Kisumu',
    constituencies: [
      {
        name: 'Kisumu Central',
        estates: [
          { name: 'Kisumu City CBD', lat: -0.0917, lng: 34.7680 },
          { name: 'Milimani Kisumu', lat: -0.1080, lng: 34.7520 },
          { name: 'Riat Hills', lat: -0.0520, lng: 34.7610 },
          { name: 'Kondele', lat: -0.0820, lng: 34.7780 },
          { name: 'Mamboleo', lat: -0.0650, lng: 34.7880 }
        ]
      },
      {
        name: 'Kisumu East & Nyando',
        estates: [
          { name: 'Ahero Town', lat: -0.1780, lng: 34.9210 },
          { name: 'Maseno Town', lat: -0.0020, lng: 34.6020 }
        ]
      }
    ]
  },
  {
    county: '043: Homa Bay',
    constituencies: [
      {
        name: 'Homa Bay Town, Mbita, Ndhiwa & Karachuonyo',
        estates: [
          { name: 'Homa Bay Town CBD', lat: -0.5272, lng: 34.4571 },
          { name: 'Mbita Point', lat: -0.4320, lng: 34.2080 },
          { name: 'Oyugis Town', lat: -0.5180, lng: 34.7380 }
        ]
      }
    ]
  },
  {
    county: '044: Migori',
    constituencies: [
      {
        name: 'Suna East/West, Kuria & Rongo',
        estates: [
          { name: 'Migori Town CBD', lat: -1.0634, lng: 34.4731 },
          { name: 'Rongo Town', lat: -0.7620, lng: 34.6080 },
          { name: 'Isebania Border Town', lat: -1.2420, lng: 34.4780 },
          { name: 'Kehancha Town', lat: -1.2020, lng: 34.6210 }
        ]
      }
    ]
  },
  {
    county: '045: Kisii',
    constituencies: [
      {
        name: 'Kitutu Chache & Nyaribari',
        estates: [
          { name: 'Kisii City CBD', lat: -0.6817, lng: 34.7667 },
          { name: 'Nyanchwa Estate', lat: -0.6720, lng: 34.7750 },
          { name: 'Mosocho', lat: -0.6550, lng: 34.7410 },
          { name: 'Daraja Mbili', lat: -0.6890, lng: 34.7610 }
        ]
      },
      {
        name: 'Ogembo & Bobasi',
        estates: [
          { name: 'Ogembo Town', lat: -0.8020, lng: 34.7210 },
          { name: 'Nyamache', lat: -0.8320, lng: 34.8210 }
        ]
      }
    ]
  },
  {
    county: '046: Nyamira',
    constituencies: [
      {
        name: 'Nyamira Town, Borabu & West Mugirango',
        estates: [
          { name: 'Nyamira Town CBD', lat: -0.5633, lng: 34.9358 },
          { name: 'Keroka Town', lat: -0.7780, lng: 34.9450 },
          { name: 'Nyyamaiya', lat: -0.5280, lng: 34.9120 }
        ]
      }
    ]
  },
  {
    county: '047: Nairobi',
    constituencies: [
      {
        name: 'Westlands',
        estates: [
          { name: 'Kilimani', lat: -1.2891, lng: 36.7886 },
          { name: 'Lavington', lat: -1.2815, lng: 36.7692 },
          { name: 'Parklands', lat: -1.2612, lng: 36.8123 },
          { name: 'Westlands Central', lat: -1.2682, lng: 36.8058 },
          { name: 'Kileleshwa', lat: -1.2828, lng: 36.7936 },
          { name: 'Riverside Drive', lat: -1.2750, lng: 36.8020 }
        ]
      },
      {
        name: 'Roysambu & Kasarani',
        estates: [
          { name: 'Roysambu', lat: -1.2185, lng: 36.8860 },
          { name: 'Mirema Drive', lat: -1.2120, lng: 36.8910 },
          { name: 'Kasarani Town', lat: -1.2220, lng: 36.8980 },
          { name: 'Clay City / Hunters', lat: -1.2150, lng: 36.9050 },
          { name: 'Kahawa West', lat: -1.1890, lng: 36.9010 },
          { name: 'Zimmerman', lat: -1.2090, lng: 36.8920 }
        ]
      },
      {
        name: 'Embakasi (East, West, North, Central, South)',
        estates: [
          { name: 'Pipeline', lat: -1.3162, lng: 36.8970 },
          { name: 'Donholm', lat: -1.3060, lng: 36.8890 },
          { name: 'Nyayo Estate Embakasi', lat: -1.3190, lng: 36.9050 },
          { name: 'Tassia', lat: -1.3120, lng: 36.9020 },
          { name: 'Fedha Estate', lat: -1.3110, lng: 36.8940 },
          { name: 'Utawala', lat: -1.2820, lng: 36.9680 },
          { name: 'Imara Daima', lat: -1.3280, lng: 36.8720 },
          { name: 'Jacaranda Estate', lat: -1.2910, lng: 36.9120 }
        ]
      },
      {
        name: 'Starehe, Langata & Dagoretti',
        estates: [
          { name: 'Nairobi CBD', lat: -1.2864, lng: 36.8172 },
          { name: 'South B', lat: -1.3092, lng: 36.8378 },
          { name: 'South C', lat: -1.3180, lng: 36.8280 },
          { name: 'Pangani', lat: -1.2720, lng: 36.8380 },
          { name: 'Karen', lat: -1.3200, lng: 36.7000 },
          { name: 'Langata Estate', lat: -1.3320, lng: 36.7820 },
          { name: 'Ngong Road / Adams Arc', lat: -1.3010, lng: 36.7810 },
          { name: 'Riruta Satellite', lat: -1.2980, lng: 36.7420 }
        ]
      },
      {
        name: 'Kamukunji, Makadara & Mathare',
        estates: [
          { name: 'Buruburu', lat: -1.2850, lng: 36.8720 },
          { name: 'Eastleigh', lat: -1.2750, lng: 36.8520 },
          { name: 'Jericho / Maringo', lat: -1.2920, lng: 36.8650 },
          { name: 'Mathare 4A / 10', lat: -1.2580, lng: 36.8580 }
        ]
      }
    ]
  }
];

// Helper formula: Haversine distance in KM
export function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}
