import { ServiceProvider, ProductListing, HousingListing, CaretakerInfo } from '../types';
import { KENYAN_LOCATIONS } from './locations';

// Helper function to extract normalized county name (e.g. "001: Mombasa" -> "mombasa")
export const normalizeCountyName = (countyStr: string): string => {
  if (!countyStr) return '';
  return countyStr.replace(/^\d+:\s*/, '').trim().toLowerCase();
};

const AVATARS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=200&q=80'
];

const SKILL_SETS = {
  Plumber: ['Borehole & Booster Pumps', 'PPR & PVC Pipe Fitting', 'Hot Water Instant Shower', 'Drain Unclogging'],
  Electrician: ['EPRA Token Rewiring', 'Solar & Battery Backup', 'CCTV System Setup', 'Circuit Breaker Fixes'],
  'Auto Mechanic': ['Engine Diagnostics', 'Brake Pad Replacement', 'Suspension Overhaul', 'Diesel Injection Repair'],
  'Solar & Borehole Tech': ['Solar Water Heaters', 'Submersible Borehole Pumps', 'Hybrid Inverters', 'Drip Irrigation Setup'],
  'Fundi / Carpenter': ['Kitchen Cabinets', 'Custom Mahogany Beds', 'Door & Lock Fitting', 'Roof Truss Repair'],
  'Mama Fua / House Cleaner': ['Sofa Steam Cleaning', 'Move-In Deep Cleaning', 'Laundry & Ironing', 'Tile Scrubbing'],
  'BodaBoda / Delivery': ['Gas Cylinder Delivery', 'Express Parcel Dispatch', 'Passenger Rides', 'Shopping Errands'],
  'Cab / Taxi Ride (Uber Style)': ['Airport & Inter-City Rides', '24/7 Estate Pickup (Uber Style)', 'AC Comfort Sedan / Saloon', 'M-Pesa Fare Payment'],
  'Lorry / Truck For Hire': ['House Relocation & Furniture', 'Construction Building Materials', '3-Ton / 5-Ton / 10-Ton Tipper', 'Commercial Freight & Logistics']
};

export function generateAllCountyData(): {
  generatedFundis: ServiceProvider[];
  generatedProducts: ProductListing[];
  generatedHousing: HousingListing[];
} {
  const fundis: ServiceProvider[] = [];
  const products: ProductListing[] = [];
  const housing: HousingListing[] = [];

  KENYAN_LOCATIONS.forEach((locObj, idx) => {
    const rawCounty = locObj.county; // e.g. "001: Mombasa"
    const countyClean = rawCounty.replace(/^\d+:\s*/, ''); // "Mombasa"
    const constituency = locObj.constituencies[0]?.name || 'Central';
    const estateObj = locObj.constituencies[0]?.estates[0] || { name: `${countyClean} CBD`, lat: -1.2891, lng: 36.7886 };
    const estateName = estateObj.name;
    const lat = estateObj.lat;
    const lng = estateObj.lng;

    const basePhone = 700000000 + (idx * 1000) + 100;

    // --- Business 1: Water, Plumbing & Solar Enterprise ---
    fundis.push({
      id: `fundi-county-${idx}-1`,
      name: `${countyClean} Pro Plumbers & Solar Solutions`,
      phone: `+254${basePhone}`,
      whatsapp: `254${basePhone}`,
      tradeSkill: 'Plumber',
      operationalCounty: rawCounty,
      operationalEstate: estateName,
      latitude: lat,
      longitude: lng,
      pricingModel: 'Per Job',
      rateKES: 1500,
      availability: 'Available Now',
      isVerified: true,
      badge: 'Top Rated',
      rating: 4.9,
      reviewsCount: 35 + (idx % 20),
      avatar: AVATARS[idx % AVATARS.length],
      bio: `Licensed water engineering & plumbing experts serving ${countyClean} County and surrounding areas. Borehole pump installation, hot instant shower wiring, PPR pipe repairs, and tank connections.`,
      skillsList: SKILL_SETS.Plumber,
      completedJobsCount: 80 + (idx * 3),
      portfolioShowcase: [
        {
          id: `job-${idx}-1`,
          title: `Borehole Water Pump & Piping Setup in ${estateName}`,
          description: `Installed 2,000L plastic water tank with automatic float switch and 1.0HP pressure booster pump for residential tenants in ${countyClean}.`,
          photoUrl: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=600&q=80',
          completedDate: 'July 2026',
          location: `${estateName}, ${countyClean}`
        }
      ]
    });

    // --- Business 2: Certified Electrical & Solar Power Tech ---
    fundis.push({
      id: `fundi-county-${idx}-2`,
      name: `${countyClean} Electrical & Solar Engineers`,
      phone: `+254${basePhone + 1}`,
      whatsapp: `254${basePhone + 1}`,
      tradeSkill: 'Electrician',
      operationalCounty: rawCounty,
      operationalEstate: estateName,
      latitude: lat + 0.002,
      longitude: lng + 0.002,
      pricingModel: 'Per Hour',
      rateKES: 1200,
      availability: 'Available Now',
      isVerified: true,
      badge: 'Super Pro',
      rating: 5.0,
      reviewsCount: 42 + (idx % 15),
      avatar: AVATARS[(idx + 2) % AVATARS.length],
      bio: `EPRA certified electrical contractors in ${countyClean}. Fault finding, KPLC Token Meter rewiring, solar panel installation, CCTV setup, and socket replacement. 24/7 emergency response.`,
      skillsList: SKILL_SETS.Electrician,
      completedJobsCount: 110 + (idx * 2),
      portfolioShowcase: [
        {
          id: `job-${idx}-2`,
          title: `5kW Solar Inverter & Battery Installation in ${countyClean}`,
          description: `Mounted 6 solar panels and 5kVA hybrid inverter system to ensure uninterrupted power for local business in ${estateName}.`,
          photoUrl: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&w=600&q=80',
          completedDate: 'June 2026',
          location: `${estateName}, ${countyClean}`
        }
      ]
    });

    // --- Business 3: Auto & Heavy Machinery Garage / Mechanic ---
    fundis.push({
      id: `fundi-county-${idx}-3`,
      name: `Master Auto Repair & Diesel Clinic (${countyClean})`,
      phone: `+254${basePhone + 2}`,
      whatsapp: `254${basePhone + 2}`,
      tradeSkill: 'Auto Mechanic',
      operationalCounty: rawCounty,
      operationalEstate: estateName,
      latitude: lat - 0.002,
      longitude: lng - 0.002,
      pricingModel: 'Per Job',
      rateKES: 2500,
      availability: 'Available Now',
      isVerified: true,
      badge: 'Verified Fundi',
      rating: 4.8,
      reviewsCount: 28 + (idx % 25),
      avatar: AVATARS[(idx + 4) % AVATARS.length],
      bio: `Expert motor vehicle diagnostics, suspension overhaul, clutch replacement, and engine tuning in ${countyClean}. Emergency breakdown towing and roadside assistance available.`,
      skillsList: SKILL_SETS['Auto Mechanic'],
      completedJobsCount: 95 + (idx * 4),
      portfolioShowcase: [
        {
          id: `job-${idx}-3`,
          title: `Computer Diagnostics & Suspension Service in ${countyClean}`,
          description: `Full brake overhaul, suspension bush replacement, and oil change for commercial 4x4 pickup.`,
          photoUrl: 'https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?auto=format&fit=crop&w=600&q=80',
          completedDate: 'July 2026',
          location: `${estateName}, ${countyClean}`
        }
      ]
    });

    // --- Business 3B: Express Uber-Style Cab / Taxi Transport ---
    fundis.push({
      id: `fundi-county-${idx}-cab`,
      name: `${countyClean} Express Cab & Taxi Rides (Uber Style)`,
      phone: `+254${basePhone + 6}`,
      whatsapp: `254${basePhone + 6}`,
      tradeSkill: 'Cab / Taxi Ride (Uber Style)',
      operationalCounty: rawCounty,
      operationalEstate: estateName,
      latitude: lat + 0.001,
      longitude: lng - 0.001,
      pricingModel: 'Per Job',
      rateKES: 500,
      availability: 'Available Now',
      isVerified: true,
      badge: 'Super Pro',
      rating: 4.9,
      reviewsCount: 52 + (idx % 30),
      avatar: AVATARS[(idx + 1) % AVATARS.length],
      bio: `24/7 Air Conditioned Saloon & SUV Taxi Rides across ${countyClean} and neighboring towns. Airport drops, SGR terminal transfers, and estate Uber-style pickups. Clean sedan with M-Pesa.`,
      skillsList: SKILL_SETS['Cab / Taxi Ride (Uber Style)'],
      completedJobsCount: 140 + (idx * 5),
      portfolioShowcase: [
        {
          id: `job-${idx}-cab`,
          title: `Airport & Estate Taxi Drop-Off in ${countyClean}`,
          description: `Prompt 24/7 pickup from ${estateName} with full air conditioning, luggage assistance, and instant M-Pesa receipt.`,
          photoUrl: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&w=600&q=80',
          completedDate: 'July 2026',
          location: `${estateName}, ${countyClean}`
        }
      ]
    });

    // --- Business 3C: Lorries & Heavy Haulage Trucks For Hire ---
    fundis.push({
      id: `fundi-county-${idx}-lorry`,
      name: `${countyClean} Lorries & Movers Transport (3-Ton / 10-Ton)`,
      phone: `+254${basePhone + 7}`,
      whatsapp: `254${basePhone + 7}`,
      tradeSkill: 'Lorry / Truck For Hire',
      operationalCounty: rawCounty,
      operationalEstate: estateName,
      latitude: lat - 0.003,
      longitude: lng + 0.003,
      pricingModel: 'Per Job',
      rateKES: 4500,
      availability: 'Available Now',
      isVerified: true,
      badge: 'Top Rated',
      rating: 4.8,
      reviewsCount: 40 + (idx % 18),
      avatar: AVATARS[(idx + 3) % AVATARS.length],
      bio: `Commercial Lorries and Tipper Trucks for hire in ${countyClean}. Heavy house relocation, furniture moving, building sand/ballast delivery, and bulk cargo logistics across Kenya.`,
      skillsList: SKILL_SETS['Lorry / Truck For Hire'],
      completedJobsCount: 105 + (idx * 3),
      portfolioShowcase: [
        {
          id: `job-${idx}-lorry`,
          title: `House Moving & Heavy Goods Transport in ${countyClean}`,
          description: `5-ton covered lorry with loaders provided for 3BR house relocation from ${estateName} to new estate.`,
          photoUrl: 'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=600&q=80',
          completedDate: 'July 2026',
          location: `${estateName}, ${countyClean}`
        }
      ]
    });

    // --- Business 4: Registered Merchant / Store (Farm, Solar & Hardware) ---
    products.push({
      id: `prod-county-${idx}-1`,
      title: `Heavy Duty 3.0HP Solar & Petrol Water Pump (${countyClean} Store)`,
      category: 'Farm & Agribusiness',
      subCategory: 'Irrigation & Farming',
      priceKES: 32500,
      isNegotiable: true,
      condition: 'Brand New',
      county: rawCounty,
      estate: estateName,
      photos: [
        'https://images.unsplash.com/photo-1508873696983-2df515122519?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&w=800&q=80'
      ],
      description: `High-pressure water pump for irrigation, dam pumping, and farm use. Fuel efficient engine, pumps up to 35,000L per hour. Available at ${countyClean} Agribusiness Depot with 1 year warranty.`,
      sellerName: `${countyClean} Agrovet & Farm Equipment Depot`,
      sellerPhone: `+254${basePhone + 3}`,
      sellerWhatsapp: `254${basePhone + 3}`,
      isSellerVerified: true,
      status: 'Available',
      featured: idx % 3 === 0,
      createdAt: '2026-07-22'
    });

    // --- Business 5: Registered Merchant / Store (Solar, Cars or Electronics) ---
    products.push({
      id: `prod-county-${idx}-2`,
      title: `3.5kW Hybrid Solar System with Lithium Battery (${countyClean})`,
      category: 'Tools & Building',
      subCategory: 'Solar & Electrical',
      priceKES: 125000,
      isNegotiable: true,
      condition: 'Brand New',
      county: rawCounty,
      estate: estateName,
      photos: [
        'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=800&q=80'
      ],
      description: `Complete hybrid solar package. Powers lights, TV, fridge, laptops, and water dispenser. Free delivery and technical guidance within ${countyClean} County.`,
      sellerName: `${countyClean} Green Energy & Solar Centre`,
      sellerPhone: `+254${basePhone + 4}`,
      sellerWhatsapp: `254${basePhone + 4}`,
      isSellerVerified: true,
      status: 'Available',
      featured: idx % 2 === 0,
      createdAt: '2026-07-23'
    });

    // --- Business 6: Real Estate Property & Caretaker Hub ---
    const caretakerInfo: CaretakerInfo = {
      id: `ct-county-${idx}`,
      name: `Caretaker ${countyClean} Property Services`,
      phone: `+254${basePhone + 5}`,
      whatsapp: `254${basePhone + 5}`,
      isVerified: true,
      rating: 4.8,
      reviewCount: 19 + idx,
      estateBase: `${estateName}, ${countyClean}`,
      avatar: AVATARS[(idx + 1) % AVATARS.length],
      propertiesCount: 6 + (idx % 10)
    };

    housing.push({
      id: `house-county-${idx}`,
      title: `Modern Executive 2 Bedroom Apartment with Balcony & Borehole Water`,
      houseType: '2 Bedroom',
      rentKES: 22000 + ((idx * 500) % 18000),
      depositTerms: '1 Month Rent + KES 2,000 Water Meter Deposit',
      county: rawCounty,
      constituency: constituency,
      estate: estateName,
      latitude: lat,
      longitude: lng,
      amenities: ['Borehole Water', 'Wi-Fi Ready', 'CCTV Security', 'KPLC Token Meter', 'Parking Space', 'Security Guard'],
      photos: [
        'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1484154218962-a197022b5858?auto=format&fit=crop&w=800&q=80'
      ],
      description: `Newly built spacious 2BR apartment in ${estateName}, ${countyClean}. Features constant borehole water, KPLC token meter, tiled floors, instant shower, and security guard at gate.`,
      caretaker: caretakerInfo,
      status: 'vacant',
      featured: idx % 4 === 0,
      createdAt: '2026-07-21',
      views: 150 + (idx * 12)
    });
  });

  return {
    generatedFundis: fundis,
    generatedProducts: products,
    generatedHousing: housing
  };
}
