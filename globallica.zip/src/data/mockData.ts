import { HousingListing, ServiceProvider, ProductListing, CaretakerInfo } from '../types';
import { generateAllCountyData } from './allCountyBusinesses';

const { generatedFundis, generatedProducts, generatedHousing } = generateAllCountyData();

export const MOCK_CARETAKERS: CaretakerInfo[] = [
  {
    id: 'ct-1',
    name: 'Ochieng Mwangi',
    phone: '+254712345678',
    whatsapp: '254712345678',
    isVerified: true,
    rating: 4.9,
    reviewCount: 38,
    estateBase: 'Kilimani & Lavington',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    propertiesCount: 12
  },
  {
    id: 'ct-2',
    name: 'Samuel Kiprop (Mama Mboga Realty)',
    phone: '+254722987654',
    whatsapp: '254722987654',
    isVerified: true,
    rating: 4.8,
    reviewCount: 54,
    estateBase: 'Roysambu & Mirema',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    propertiesCount: 18
  },
  {
    id: 'ct-3',
    name: 'Grace Wanjiku',
    phone: '+254733112233',
    whatsapp: '254733112233',
    isVerified: true,
    rating: 4.7,
    reviewCount: 29,
    estateBase: 'Pipeline & Donholm',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
    propertiesCount: 8
  },
  {
    id: 'ct-4',
    name: 'Hassan Omar',
    phone: '+254701554433',
    whatsapp: '254701554433',
    isVerified: true,
    rating: 5.0,
    reviewCount: 42,
    estateBase: 'Nyali & Bamburi, Mombasa',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
    propertiesCount: 15
  }
];

export const MOCK_HOUSING: HousingListing[] = [
  {
    id: 'house-101',
    title: 'Modern 2 Bedroom Master En-Suite with Balcony & Borehole',
    houseType: '2 Bedroom',
    rentKES: 38000,
    depositTerms: '1 Month Rent (KES 38,000) + KES 2,500 KPLC & Water Token Deposit',
    county: 'Nairobi',
    constituency: 'Westlands',
    estate: 'Kilimani',
    latitude: -1.2891,
    longitude: 36.7886,
    amenities: ['Borehole Water', 'Wi-Fi Ready', 'CCTV Security', 'KPLC Token Meter', 'Parking Space', 'Security Guard', 'Balcony', 'Backup Generator'],
    photos: [
      'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1484154218962-a197022b5858?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Spacious 2 bedroom apartment located off Argwings Kodhek Rd in Kilimani. Features constant borehole water supply, high-speed fibre internet cabling, perimeter electric wall, and dedicated parking bay. 5-minute walk to Yaya Centre.',
    caretaker: MOCK_CARETAKERS[0],
    status: 'vacant',
    featured: true,
    createdAt: '2026-07-20',
    views: 412,
    vettingInfo: {
      isVetted: true,
      lrTitleDeedNo: 'LR NO. 209/18290',
      landRegistryStatus: 'ARDHISASA_VERIFIED',
      registeredOwnerName: 'Kilimani Crest Towers Ltd',
      geoGpsCoordinatesVerified: true,
      physicalInspectorName: 'Inspector J. Omondi (GLOBALLICA Physical Auditor)',
      verifiedAt: '2026-07-22'
    }
  },
  {
    id: 'house-102',
    title: 'Spacious Bedsitter with Separate Kitchenette & Tiled Floors',
    houseType: 'Bedsitter',
    rentKES: 11000,
    depositTerms: '1 Month Rent + KES 1,000 Garbage & Water Meter Deposit',
    county: 'Nairobi',
    constituency: 'Kasarani / Roysambu',
    estate: 'Mirema',
    latitude: -1.2120,
    longitude: 36.8910,
    amenities: ['Wi-Fi Ready', 'KPLC Token Meter', 'CCTV Security', 'Security Guard', 'Borehole Water'],
    photos: [
      'https://images.unsplash.com/photo-1536376072261-38c75010e6c9?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1554995207-c18c203602cb?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Neat executive bedsitter in Mirema Drive, 2nd row from tarmac. Has hot shower installed, clean water 24/7, full security guard at gate, and easy access to Thika Road Superhighway.',
    caretaker: MOCK_CARETAKERS[1],
    status: 'vacant',
    featured: true,
    createdAt: '2026-07-21',
    views: 890,
    vettingInfo: {
      isVetted: true,
      lrTitleDeedNo: 'NAIROBI/BLOCK 88/1920',
      landRegistryStatus: 'ARDHISASA_VERIFIED',
      registeredOwnerName: 'Samuel Kiprop Investments',
      geoGpsCoordinatesVerified: true,
      physicalInspectorName: 'Inspector A. Wambui (GLOBALLICA Auditor)',
      verifiedAt: '2026-07-24'
    }
  },
  {
    id: 'house-103',
    title: 'Affordable 1 Bedroom Apartment near Tarmac',
    houseType: '1 Bedroom',
    rentKES: 16500,
    depositTerms: '1 Month Deposit KES 16,500 + KES 1,500 Water Agreement',
    county: 'Nairobi',
    constituency: 'Embakasi East',
    estate: 'Pipeline',
    latitude: -1.3162,
    longitude: 36.8970,
    amenities: ['KPLC Token Meter', 'Security Guard', 'Wi-Fi Ready', 'Borehole Water'],
    photos: [
      'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Well lit 1 bedroom in Pipeline Estate. Large sitting room, fitted kitchen cabinets, hot instant shower, individual KPLC token meter. Secure perimeter fence.',
    caretaker: MOCK_CARETAKERS[2],
    status: 'vacant',
    featured: false,
    createdAt: '2026-07-18',
    views: 310
  },
  {
    id: 'house-104',
    title: 'Luxury 3BR Beachfront Villa with Pool & Ocean View',
    houseType: 'Maisonette',
    rentKES: 85000,
    depositTerms: '2 Months Deposit + KES 5,000 Utility Deposit',
    county: 'Mombasa',
    constituency: 'Nyali',
    estate: 'Nyali Estate',
    latitude: -4.0322,
    longitude: 39.6918,
    amenities: ['Borehole Water', 'Wi-Fi Ready', 'CCTV Security', 'Parking Space', 'Gym', 'Backup Generator', 'Balcony', 'Security Guard'],
    photos: [
      'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1512915922686-57c11dde9b6b?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Prime 3 bedroom maisonette in Nyali Estate, 3 minutes walk to City Mall. Features private swimming pool, manicured lawn, air conditioning in all rooms, and UN-approved security standards.',
    caretaker: MOCK_CARETAKERS[3],
    status: 'vacant',
    featured: true,
    createdAt: '2026-07-19',
    views: 620
  },
  {
    id: 'house-105',
    title: 'Executive 1 Bedroom with Elevator & Rooftop Lounge',
    houseType: '1 Bedroom',
    rentKES: 24000,
    depositTerms: '1 Month Rent Deposit',
    county: 'Kiambu',
    constituency: 'Ruiru / Juja',
    estate: 'Ruaka',
    latitude: -1.2058,
    longitude: 36.7761,
    amenities: ['Borehole Water', 'Wi-Fi Ready', 'CCTV Security', 'KPLC Token Meter', 'Parking Space', 'Backup Generator', 'Balcony'],
    photos: [
      'https://images.unsplash.com/photo-1502005229762-cf1b2da7c5d6?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1493809842364-78817add7ffb?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Brand new 1 bedroom in Ruaka near Two Rivers Mall. High speed elevator, rooftop clothes drying area, solar water heating, and 24-hour security guard control.',
    caretaker: MOCK_CARETAKERS[0],
    status: 'vacant',
    featured: false,
    createdAt: '2026-07-22',
    views: 295
  },
  ...generatedHousing
];

export const MOCK_FUNDIS: ServiceProvider[] = [
  {
    id: 'fundi-201',
    name: 'John "Fundi Power" Omondi',
    phone: '+254711998877',
    whatsapp: '254711998877',
    tradeSkill: 'Plumber',
    operationalCounty: 'Nairobi',
    operationalEstate: 'Roysambu',
    latitude: -1.2185,
    longitude: 36.8860,
    pricingModel: 'Per Job',
    rateKES: 1500,
    availability: 'Available Now',
    isVerified: true,
    badge: 'Super Pro',
    rating: 4.9,
    reviewsCount: 84,
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=200&q=80',
    bio: 'Licensed plumber with 8+ years experience in burst pipe repairs, instant shower installation, drainage unblocking, and water pump maintenance across Roysambu, Mirema, and Kasarani.',
    skillsList: ['Instant Shower Fitting', 'Drainage Unblocking', 'Water Meter Installation', 'Borehole Pump Repair', 'Sink & Pipe Leak Fix'],
    completedJobsCount: 142,
    portfolioShowcase: [
      {
        id: 'job-p1',
        title: 'Full Bath Plumbing & Instant Shower Installation',
        description: 'Installed Lorenzetti 4-stage instant shower, PPR concealed water pipes, and floor drain trap for a 2BR apartment in Mirema Drive.',
        photoUrl: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=600&q=80',
        videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-plumbing-repairing-a-pipe-under-the-sink-41525-large.mp4',
        completedDate: 'July 2026',
        location: 'Mirema, Roysambu'
      },
      {
        id: 'job-p2',
        title: 'Overhead Water Tank & Booster Pump Connection',
        description: 'Set up 2,000L Roto plastic water tank with automatic float switch and 1.0HP pressure booster pump.',
        photoUrl: 'https://images.unsplash.com/photo-1542013936693-884638332954?auto=format&fit=crop&w=600&q=80',
        completedDate: 'June 2026',
        location: 'Zimmerman, Kasarani'
      },
      {
        id: 'job-p3',
        title: 'Commercial Kitchen Double Stainless Sink Fitting',
        description: 'Fitted grease trap, heavy-duty mixer taps, and drain overflow piping for a fast-food hotel in Roysambu.',
        photoUrl: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=600&q=80',
        completedDate: 'May 2026',
        location: 'Roysambu Town'
      }
    ]
  },
  {
    id: 'fundi-202',
    name: 'Engineer Mwangi Sparks',
    phone: '+254722334455',
    whatsapp: '254722334455',
    tradeSkill: 'Electrician',
    operationalCounty: 'Nairobi',
    operationalEstate: 'Kilimani',
    latitude: -1.2891,
    longitude: 36.7886,
    pricingModel: 'Per Hour',
    rateKES: 1000,
    availability: 'Available Now',
    isVerified: true,
    badge: 'Top Rated',
    rating: 5.0,
    reviewsCount: 112,
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=200&q=80',
    bio: 'EPRA Certified Electrician. Fault finding, KPLC Token Meter rewiring, solar panel installation, CCTV setup, and socket replacement. Fast emergency response in Kilimani, Lavington & Westlands.',
    skillsList: ['Circuit Breakers', 'Token Meter Rewiring', 'Solar & Inverter Installation', 'CCTV System Wiring', 'Security Light Sensor Setup'],
    completedJobsCount: 205,
    portfolioShowcase: [
      {
        id: 'job-e1',
        title: '5kW Hybrid Solar System & Lithium Battery Wiring',
        description: 'Installed 8 solar panels, 5kVA Felicity hybrid inverter, and 100Ah lithium storage battery box to ensure 24/7 power during blackouts.',
        photoUrl: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&w=600&q=80',
        completedDate: 'July 2026',
        location: 'Kilimani, Nairobi'
      },
      {
        id: 'job-e2',
        title: 'Complete 3-Phase Main Distribution Board Upgrade',
        description: 'Re-wired damaged electrical consumer unit, installed Schneider circuit breakers and surge protector for commercial office.',
        photoUrl: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=600&q=80',
        completedDate: 'June 2026',
        location: 'Westlands, Nairobi'
      },
      {
        id: 'job-e3',
        title: '8-Camera Hikvision IP CCTV & Night Vision Setup',
        description: 'Mounted high-definition dome cameras with perimeter motion detection alerts routed straight to client mobile phone app.',
        photoUrl: 'https://images.unsplash.com/photo-1557597774-9d273605dfa9?auto=format&fit=crop&w=600&q=80',
        completedDate: 'May 2026',
        location: 'Lavington, Nairobi'
      }
    ]
  },
  {
    id: 'fundi-203',
    name: 'Mama Mercy Cleaning Services',
    phone: '+254733445566',
    whatsapp: '254733445566',
    tradeSkill: 'Mama Fua / House Cleaner',
    operationalCounty: 'Nairobi',
    operationalEstate: 'Westlands Central',
    latitude: -1.2682,
    longitude: 36.8058,
    pricingModel: 'Per Job',
    rateKES: 1200,
    availability: 'Available Now',
    isVerified: true,
    badge: 'Verified Fundi',
    rating: 4.8,
    reviewsCount: 67,
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&q=80',
    bio: 'Reliable, trustworthy house cleaning & laundry team. Thorough deep cleaning for move-in/move-out houses, sofa shampooing, rug cleaning, and general weekly house chores.',
    skillsList: ['Laundry & Ironing', 'Move-In Deep Cleaning', 'Sofa & Carpet Shampooing', 'Window & Tile Scrubbing'],
    completedJobsCount: 98,
    portfolioShowcase: [
      {
        id: 'job-c1',
        title: 'Velvet Sofa & Persian Rug Deep Steam Wash',
        description: 'Stain removal and anti-bacterial deep steam cleaning on a 7-seater velvet couch set and dining room carpet.',
        photoUrl: 'https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?auto=format&fit=crop&w=600&q=80',
        completedDate: 'July 2026',
        location: 'Kileleshwa, Nairobi'
      },
      {
        id: 'job-c2',
        title: 'Post-Tenant Move-In Kitchen & Tile Restoration',
        description: 'Scrubbed tough grease from kitchen tiles, cabinets, wall tiles, oven hood, and window glass panes.',
        photoUrl: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=600&q=80',
        completedDate: 'June 2026',
        location: 'Parklands, Nairobi'
      }
    ]
  },
  {
    id: 'fundi-204',
    name: 'Kamau Boda & Express Delivery',
    phone: '+254700112233',
    whatsapp: '254700112233',
    tradeSkill: 'BodaBoda / Delivery',
    operationalCounty: 'Nairobi',
    operationalEstate: 'Pipeline',
    latitude: -1.3162,
    longitude: 36.8970,
    pricingModel: 'Per Job',
    rateKES: 300,
    availability: 'Available Now',
    isVerified: true,
    badge: 'Community Master',
    rating: 4.9,
    reviewsCount: 156,
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=200&q=80',
    bio: 'Safe, fast parcel delivery, gas cylinder home delivery, and errand rider covering Pipeline, Donholm, Fedha, South B, and CBD. Equipped with heavy parcel rack & helmet for passenger rides.',
    skillsList: ['Gas Cylinder Delivery', 'Parcel & Document Dispatch', 'Shopping Errand Service', 'Passenger Rides'],
    completedJobsCount: 310,
    portfolioShowcase: [
      {
        id: 'job-b1',
        title: '13kg Gas Refill & Regulator Home Delivery',
        description: 'Prompt delivery and leak-check installation of K-Gas cylinder straight to 4th floor tenant kitchen.',
        photoUrl: 'https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=600&q=80',
        completedDate: 'July 2026',
        location: 'Pipeline, Nairobi'
      }
    ]
  },
  {
    id: 'fundi-cab-101',
    name: "David 'Uber Captain' Mwangi - Executive Cab & Taxi Rides",
    phone: '+254712334455',
    whatsapp: '254712334455',
    tradeSkill: 'Cab / Taxi Ride (Uber Style)',
    operationalCounty: 'Nairobi',
    operationalEstate: 'Kilimani',
    latitude: -1.2891,
    longitude: 36.7886,
    pricingModel: 'Per Job',
    rateKES: 600,
    availability: 'Available Now',
    isVerified: true,
    badge: 'Super Pro',
    rating: 5.0,
    reviewsCount: 210,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    bio: '24/7 Professional Taxi & Cab Rides in clean, air-conditioned Toyota Axio saloon car. Airport transfers (JKIA / Wilson), SGR Syokimau station drops, and estate pickups across Kilimani, Westlands, Kileleshwa & Lavington. M-Pesa accepted.',
    skillsList: ['Airport & SGR Transfers', '24/7 Estate Pickup (Uber Style)', 'AC Comfort Sedan / Saloon', 'Instant M-Pesa Fare Payment'],
    completedJobsCount: 420,
    portfolioShowcase: [
      {
        id: 'job-c101',
        title: 'JKIA Airport Early Morning Express Taxi Drop',
        description: 'Picked client from Kilimani at 4:30 AM with luggage assistance and smooth highway drive to Terminal 1A.',
        photoUrl: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&w=600&q=80',
        completedDate: 'July 2026',
        location: 'Kilimani to JKIA, Nairobi'
      }
    ]
  },
  {
    id: 'fundi-lorry-102',
    name: 'Njuguna Lorries & Heavy Haulage (3-Ton / 7-Ton / 10-Ton Trucks)',
    phone: '+254722889900',
    whatsapp: '254722889900',
    tradeSkill: 'Lorry / Truck For Hire',
    operationalCounty: 'Nairobi',
    operationalEstate: 'Roysambu',
    latitude: -1.2185,
    longitude: 36.8860,
    pricingModel: 'Per Job',
    rateKES: 5500,
    availability: 'Available Now',
    isVerified: true,
    badge: 'Top Rated',
    rating: 4.9,
    reviewsCount: 178,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
    bio: 'Covered Box Lorries and Open Tipper Trucks for hire. House relocation moving with loaders, commercial cargo transport, building sand/ballast delivery, and upcountry haulage across Nairobi, Thika, Nakuru, Eldoret & Mombasa.',
    skillsList: ['3-Ton & 7-Ton Box Lorries', 'House Relocation & Furniture Loaders', 'Construction Materials Tipper', 'Upcountry Countrywide Haulage'],
    completedJobsCount: 310,
    portfolioShowcase: [
      {
        id: 'job-l101',
        title: 'Complete 3BR House Relocation with Loaders & Protective Blankets',
        description: 'Loaded and safely moved all household furniture and appliances from Roysambu to Ruaka without any scratches.',
        photoUrl: 'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=600&q=80',
        completedDate: 'July 2026',
        location: 'Roysambu to Ruaka'
      }
    ]
  },
  {
    id: 'fundi-205',
    name: 'Fundi James Wood & Furniture',
    phone: '+254715667788',
    whatsapp: '254715667788',
    tradeSkill: 'Fundi / Carpenter',
    operationalCounty: 'Kiambu',
    operationalEstate: 'Ruaka',
    latitude: -1.2058,
    longitude: 36.7761,
    pricingModel: 'Per Job',
    rateKES: 2500,
    availability: 'On a Job',
    isVerified: true,
    badge: 'Top Rated',
    rating: 4.7,
    reviewsCount: 45,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
    bio: 'Master carpenter specializing in custom wooden beds, kitchen cabinet installation, door fitting, lock replacements, and wardrobe repairs.',
    skillsList: ['Door & Lock Fitting', 'Kitchen Cabinetry', 'Custom Bed Frames', 'Wardrobe Repairs'],
    completedJobsCount: 76,
    portfolioShowcase: [
      {
        id: 'job-w1',
        title: 'Custom Mahogany King Bed Frame with Drawers',
        description: 'Handcrafted solid mahogany king bed frame featuring built-in side storage drawers and padded leather headboard.',
        photoUrl: 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=600&q=80',
        completedDate: 'June 2026',
        location: 'Ruaka, Kiambu'
      },
      {
        id: 'job-w2',
        title: 'Modern Modular Kitchen Cabinets & Quartz Countertop',
        description: 'Designed and installed 12-meter soft-close kitchen cabinets with granite finish countertops and microwave shelf.',
        photoUrl: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=600&q=80',
        completedDate: 'May 2026',
        location: 'Kahawa Sukari, Kiambu'
      }
    ]
  },
  {
    id: 'fundi-206',
    name: 'Eldoret Auto Clinic & Diesel Mechanic',
    phone: '+254722990011',
    whatsapp: '254722990011',
    tradeSkill: 'Auto Mechanic',
    operationalCounty: 'Uasin Gishu (Eldoret)',
    operationalEstate: 'Eldoret CBD',
    latitude: 0.5143,
    longitude: 35.2698,
    pricingModel: 'Per Job',
    rateKES: 2000,
    availability: 'Available Now',
    isVerified: true,
    badge: 'Super Pro',
    rating: 4.9,
    reviewsCount: 62,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    bio: 'Expert diesel & petrol car diagnostic mechanic in Eldoret. Suspension overhaul, engine tuning, brake pad replacement, computer diagnostics, and breakdown roadside rescue across North Rift.',
    skillsList: ['Computer Diagnostics', 'Suspension Overhaul', 'Engine Rebuild', 'Breakdown Roadside Tow'],
    completedJobsCount: 110,
    portfolioShowcase: [
      {
        id: 'job-a1',
        title: 'Toyota Hilux D4D Diesel Fuel Injector Cleaning & Service',
        description: 'Replaced faulty fuel rail sensors and serviced common rail injectors for smooth farm trail driving.',
        photoUrl: 'https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?auto=format&fit=crop&w=600&q=80',
        completedDate: 'July 2026',
        location: 'Eldoret CBD'
      }
    ]
  },
  {
    id: 'fundi-207',
    name: 'Coast Solar & Borehole Pump Solutions',
    phone: '+254711443322',
    whatsapp: '254711443322',
    tradeSkill: 'Solar & Borehole Tech',
    operationalCounty: 'Mombasa',
    operationalEstate: 'Nyali Estate',
    latitude: -4.0322,
    longitude: 39.6918,
    pricingModel: 'Per Job',
    rateKES: 3500,
    availability: 'Available Now',
    isVerified: true,
    badge: 'Top Rated',
    rating: 5.0,
    reviewsCount: 48,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    bio: 'Submersible water pump installations, solar borehole pumping kits, desalination maintenance, and solar water heating panels for residential homes and hotels along Mombasa & Kilifi coast.',
    skillsList: ['Submersible Pump Fitting', 'Solar Water Heater Repairs', 'Control Panel Inverter Wiring', 'Water Treatment Filters'],
    completedJobsCount: 88,
    portfolioShowcase: [
      {
        id: 'job-s1',
        title: '300L Solar Thermal Water Heater Roof Mounting',
        description: 'Mounted high-efficiency glass tube solar water heater with pressure valve control on a Nyali Villa rooftop.',
        photoUrl: 'https://images.unsplash.com/photo-1508873696983-2df515122519?auto=format&fit=crop&w=600&q=80',
        completedDate: 'June 2026',
        location: 'Nyali, Mombasa'
      }
    ]
  },
  ...generatedFundis
];

export const MOCK_PRODUCTS: ProductListing[] = [
  {
    id: 'prod-301',
    title: 'Toyota Prado TX-L 2017 (Sunroof, Leather Seats, Diesel 2.8L)',
    category: 'Vehicles',
    subCategory: 'Cars & SUVs',
    priceKES: 4850000,
    isNegotiable: true,
    condition: 'Foreign Used (Import)',
    county: 'Nairobi',
    estate: 'Kilimani',
    photos: [
      'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Clean Pearl White Toyota Prado TXL 2017 Model. Recently cleared from Mombasa Port. Low mileage (54,000 km), original alloy rims, 360-degree camera, multi-terrain select, 7-seater.',
    sellerName: 'Mvule Motors Kenya',
    sellerPhone: '+254712001122',
    sellerWhatsapp: '254712001122',
    isSellerVerified: true,
    status: 'Available',
    featured: true,
    createdAt: '2026-07-21',
    specs: {
      'Year of Manufacture': '2017',
      'Engine Size': '2800 cc Diesel',
      'Transmission': 'Automatic 4WD',
      'Color': 'Pearl White',
      'Mileage': '54,000 km'
    }
  },
  {
    id: 'prod-302',
    title: 'Samsung 55 Inch 4K Smart UHD TV (Original Box & Warranty)',
    category: 'Electronics & Phones',
    subCategory: 'TVs & Audio',
    priceKES: 46000,
    isNegotiable: true,
    condition: 'Brand New',
    county: 'Nairobi',
    estate: 'Nairobi CBD',
    photos: [
      'https://images.unsplash.com/photo-1593784991095-a205069470b6?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Genuine Samsung 55" Crystal UHD 4K Smart TV. Comes with Netflix, YouTube, DStv app pre-installed, Voice Remote Control, and 2-year Samsung East Africa Warranty card.',
    sellerName: 'Jamboshop Electronics CBD',
    sellerPhone: '+254722881100',
    sellerWhatsapp: '254722881100',
    isSellerVerified: true,
    status: 'Available',
    featured: true,
    createdAt: '2026-07-22'
  },
  {
    id: 'prod-303',
    title: 'Heavy Duty 7-Seater L-Shape Velvet Sofa Set with Coffee Table',
    category: 'Home & Furniture',
    subCategory: 'Living Room Furniture',
    priceKES: 34000,
    isNegotiable: false,
    condition: 'Brand New',
    county: 'Kiambu',
    estate: 'Ruiru Town',
    photos: [
      'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Elegantly crafted 7-seater corner velvet sofa set with high-density foam cushions that do not sink. Includes free wooden glass-top coffee table and 4 accent pillows. Free transport within Ruiru & Kasarani.',
    sellerName: 'Nairobi Quality Furniture Ltd',
    sellerPhone: '+254705443322',
    sellerWhatsapp: '254705443322',
    isSellerVerified: true,
    status: 'Available',
    featured: false,
    createdAt: '2026-07-19'
  },
  {
    id: 'prod-304',
    title: 'Apple iPhone 14 Pro Max 256GB Deep Purple (Battery 92%)',
    category: 'Electronics & Phones',
    subCategory: 'Mobile Phones',
    priceKES: 92000,
    isNegotiable: true,
    condition: 'Kenyan Used',
    county: 'Nairobi',
    estate: 'Westlands Central',
    photos: [
      'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Ex-UK iPhone 14 Pro Max 256GB in Deep Purple color. FaceID working perfectly, TrueTone active, 92% battery health. Comes with original fast charging cable and protective silicone case.',
    sellerName: 'iStore Westlands Hub',
    sellerPhone: '+254711223344',
    sellerWhatsapp: '254711223344',
    isSellerVerified: true,
    status: 'Available',
    featured: false,
    createdAt: '2026-07-20'
  },
  {
    id: 'prod-305',
    title: 'Heavy Duty Petrol Solar Water Pump Kit 3.0HP (100m Head)',
    category: 'Farm & Agribusiness',
    subCategory: 'Irrigation & Farming',
    priceKES: 38500,
    isNegotiable: true,
    condition: 'Brand New',
    county: 'Uasin Gishu (Eldoret)',
    estate: 'Eldoret CBD',
    photos: [
      'https://images.unsplash.com/photo-1508873696983-2df515122519?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'High pressure 3.0HP irrigation water pump ideal for drip farming, greenhouse watering, and river pumping. Fuel-efficient 4-stroke engine, pumps up to 40,000 liters per hour. Includes 50m delivery pipe.',
    sellerName: 'Rift Valley AgriTech Store',
    sellerPhone: '+254723991122',
    sellerWhatsapp: '254723991122',
    isSellerVerified: true,
    status: 'Available',
    featured: true,
    createdAt: '2026-07-22'
  },
  {
    id: 'prod-306',
    title: 'TVS HLX 150 Boda Boda Motorcycle 2024 (Zero Mileage)',
    category: 'Vehicles',
    subCategory: 'Motorcycles & BodaBoda',
    priceKES: 148000,
    isNegotiable: true,
    condition: 'Brand New',
    county: 'Nakuru',
    estate: 'Nakuru CBD',
    photos: [
      'https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Brand new TVS HLX 150 Gold Edition. Comes with official logbook registration assistance, crash guard, helmet, reflector jacket, and 2 free showroom oil changes in Nakuru town.',
    sellerName: 'Nakuru TVS Showroom',
    sellerPhone: '+254701223344',
    sellerWhatsapp: '254701223344',
    isSellerVerified: true,
    status: 'Available',
    featured: true,
    createdAt: '2026-07-23'
  },
  {
    id: 'prod-307',
    title: '5kW Hybrid Solar Inverter System with 10kWh Battery Rack',
    category: 'Tools & Building',
    subCategory: 'Solar & Electrical',
    priceKES: 165000,
    isNegotiable: true,
    condition: 'Brand New',
    county: 'Nairobi',
    estate: 'Industrial Area',
    photos: [
      'https://images.unsplash.com/photo-1509391365360-2e959784a276?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Complete backup power system. Powers refrigerators, water pumps, TVs, microwave, lighting, and laptops uninterrupted. Comes with 5-year solar warranty and installation guidance.',
    sellerName: 'PowerSafi Green Energy Ltd',
    sellerPhone: '+254711887766',
    sellerWhatsapp: '254711887766',
    isSellerVerified: true,
    status: 'Available',
    featured: true,
    createdAt: '2026-07-21'
  },
  {
    id: 'prod-308',
    title: 'Lenovo ThinkPad T14 Gen 2 (Intel i7 11th Gen, 16GB RAM, 512GB SSD)',
    category: 'Electronics & Phones',
    subCategory: 'Laptops & Computers',
    priceKES: 52000,
    isNegotiable: true,
    condition: 'Foreign Used (Import)',
    county: 'Machakos',
    estate: 'Syokimau',
    photos: [
      'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Ex-UK pristine Lenovo ThinkPad T14 Gen 2 laptop. Backlit keyboard, fingerprint sensor, Full HD IPS screen, 6-hour battery health. Pre-installed Windows 11 Pro and MS Office 2021.',
    sellerName: 'Syokimau Tech Hub',
    sellerPhone: '+254799332211',
    sellerWhatsapp: '254799332211',
    isSellerVerified: true,
    status: 'Available',
    featured: false,
    createdAt: '2026-07-20'
  },
  {
    id: 'prod-309',
    title: 'Commercial 528 Egg Automatic Poultry Incubator (Digital Temp Control)',
    category: 'Farm & Agribusiness',
    subCategory: 'Poultry & Livestock',
    priceKES: 45000,
    isNegotiable: true,
    condition: 'Brand New',
    county: 'Kisumu',
    estate: 'Kisumu CBD',
    photos: [
      'https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'High hatch rate (95%+) automatic egg turning incubator. Auto temperature, humidity control, solar dual power inverter ready. Suitable for chicken, duck, and quail eggs.',
    sellerName: 'Victoria Agri-Supplies Kisumu',
    sellerPhone: '+254734112233',
    sellerWhatsapp: '254734112233',
    isSellerVerified: true,
    status: 'Available',
    featured: false,
    createdAt: '2026-07-19'
  },
  ...generatedProducts
];

export const MOCK_DOMESTIC_SUBSCRIPTIONS: import('../types').DomesticSubscription[] = [
  {
    id: 'sub-101',
    providerId: 'f-1',
    providerName: 'Mama Fua Jane Wambui',
    providerSkill: 'Mama Fua / House Cleaner',
    providerAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
    clientName: 'Sarah Mwangi',
    clientPhone: '+254712345678',
    clientEstate: 'Kilimani, Nairobi',
    frequency: 'WEEKLY',
    preferredDays: ['Tuesday', 'Saturday'],
    preferredTimeSlot: '08:00 AM - 01:00 PM',
    ratePerVisitKES: 1500,
    autoEscrowDeduct: true,
    nextScheduledDate: '2026-07-28',
    status: 'ACTIVE',
    createdDate: '2026-06-01',
    mpesaAutoBillNumber: '254712345678',
    completedVisitsCount: 14,
    lastEscrowDeductionAt: '2026-07-25 07:00 AM'
  },
  {
    id: 'sub-102',
    providerId: 'f-2',
    providerName: 'Fundi James Otieno',
    providerSkill: 'Plumber',
    providerAvatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=300&q=80',
    clientName: 'Sarah Mwangi',
    clientPhone: '+254712345678',
    clientEstate: 'Kilimani, Nairobi',
    frequency: 'MONTHLY',
    preferredDays: ['1st Saturday of Month'],
    preferredTimeSlot: '10:00 AM - 02:00 PM',
    ratePerVisitKES: 2500,
    autoEscrowDeduct: true,
    nextScheduledDate: '2026-08-01',
    status: 'ACTIVE',
    createdDate: '2026-05-15',
    mpesaAutoBillNumber: '254712345678',
    completedVisitsCount: 3,
    lastEscrowDeductionAt: '2026-07-04 09:00 AM'
  }
];

export const MOCK_JOB_BRIEFS: import('../types').JobBrief[] = [
  {
    id: 'brief-301',
    title: 'Complete 3-Bedroom Villa Electrical Rewiring & Solar Hybrid Setup',
    category: 'Electrical Wiring & Solar',
    location: 'Kitisuru, Nairobi',
    county: 'Nairobi',
    budgetEstimateKES: 280000,
    isBudgetNegotiable: true,
    photos: [
      'https://images.unsplash.com/photo-1508873696983-2df515122519?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Looking for EPRA-certified electrical contractor for complete house conduit rewiring, installation of 5kVA Felicity Solar Hybrid Inverter, lithium battery bank, and smart distribution board with surge protection.',
    clientName: 'Dr. Kamau Njuguna',
    clientPhone: '+254722998877',
    clientEmail: 'kamau.n@example.com',
    status: 'UNDER_NEGOTIATION',
    createdAt: '2026-07-24',
    bidsCount: 2
  },
  {
    id: 'brief-302',
    title: 'Commercial Steel Roof Trussing & Sheet Installation for 400sqm Warehouse',
    category: 'Roofing & Steelwork',
    location: 'Syokimau, Machakos',
    county: 'Machakos',
    budgetEstimateKES: 650000,
    isBudgetNegotiable: true,
    photos: [
      'https://images.unsplash.com/photo-1541888946425-d0fbb186a5b3?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Require heavy gauge tubular steel roof truss fabrication, anti-rust red oxide coating, and installation of Versatile matte dark green roof sheets with gutters.',
    clientName: 'Mwangi Enterprises Ltd',
    clientPhone: '+254733112233',
    status: 'OPEN_FOR_BIDS',
    createdAt: '2026-07-25',
    bidsCount: 1
  }
];

export const MOCK_CONTRACTOR_BIDS: import('../types').ContractorBid[] = [
  {
    id: 'bid-501',
    briefId: 'brief-301',
    contractorId: 'f-3',
    contractorName: 'SolarTech Engineers & Electricians',
    contractorSkill: 'Electrician & Solar Specialist',
    contractorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    contractorPhone: '+254700000003',
    isContractorVerified: true,
    quoteAmountKES: 265000,
    timelineEstimate: '7 Working Days',
    materialsIncluded: true,
    itemizedBreakdown: [
      { description: 'EPRA Certified Labor & Testing', costKES: 65000 },
      { description: '5kVA Hybrid Inverter & 5.12kWh Lithium Battery', costKES: 160000 },
      { description: 'Conduits, Pure Copper Cables & Smart Breakers', costKES: 40000 }
    ],
    notes: 'Includes 2-Year warranty on solar inverter and EPRA compliance certificate upon completion.',
    status: 'COUNTERED',
    submittedAt: '2026-07-24 03:30 PM'
  },
  {
    id: 'bid-502',
    briefId: 'brief-301',
    contractorId: 'f-2',
    contractorName: 'Fundi James Otieno',
    contractorSkill: 'Plumber & General Contractor',
    contractorAvatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=300&q=80',
    contractorPhone: '+254700000002',
    isContractorVerified: true,
    quoteAmountKES: 290000,
    timelineEstimate: '10 Working Days',
    materialsIncluded: true,
    itemizedBreakdown: [
      { description: 'Labor & Installation Crew', costKES: 80000 },
      { description: 'High Grade Heavy Cables & DB Board', costKES: 210000 }
    ],
    notes: 'Can begin site setup within 24 hours of Escrow deposit.',
    status: 'PENDING',
    submittedAt: '2026-07-25 09:15 AM'
  }
];

export const MOCK_NEGOTIATION_MESSAGES: import('../types').NegotiationMessage[] = [
  {
    id: 'msg-1',
    briefId: 'brief-301',
    bidId: 'bid-501',
    senderType: 'CONTRACTOR',
    senderName: 'SolarTech Engineers & Electricians',
    text: 'Jambo Dr. Kamau! We reviewed your electrical layout and photo brief. We can supply genuine Felicity 5kVA with Grade-A Lithium battery and execute the full rewiring for KES 265,000 including EPRA certification.',
    timestamp: '2026-07-24 03:32 PM'
  },
  {
    id: 'msg-2',
    briefId: 'brief-301',
    bidId: 'bid-501',
    senderType: 'CLIENT',
    senderName: 'Dr. Kamau Njuguna',
    text: 'Asante SolarTech. I see the breakdown. Would you consider KES 250,000 if I make the full Escrow deposit today?',
    proposedQuoteAmountKES: 250000,
    isCounterOffer: true,
    timestamp: '2026-07-24 05:10 PM'
  },
  {
    id: 'msg-3',
    briefId: 'brief-301',
    bidId: 'bid-501',
    senderType: 'CONTRACTOR',
    senderName: 'SolarTech Engineers & Electricians',
    text: 'Thank you Doctor. If you cover copper conduit fittings, we can meet halfway at KES 255,000 with 100% Escrow security!',
    proposedQuoteAmountKES: 255000,
    isCounterOffer: true,
    timestamp: '2026-07-25 08:00 AM'
  }
];

