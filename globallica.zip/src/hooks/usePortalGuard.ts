import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  checkPortalAccess, 
  executePortalLoginRedirect, 
  PortalAccessDecision, 
  PortalConfig, 
  PortalId, 
  PORTAL_REGISTRY 
} from '../utils/portalRouter';
import { RBACRole } from '../types';

interface UsePortalGuardOptions {
  currentRoleOverride?: RBACRole;
  onUnauthorizedRedirect?: (portal: PortalConfig, reason: string) => void;
}

export function usePortalGuard(options: UsePortalGuardOptions = {}) {
  const { currentUser, userProfile, openAuthModal } = useAuth();

  const currentRoleOverride = options.currentRoleOverride;
  const onUnauthorizedRedirectRef = useRef(options.onUnauthorizedRedirect);
  useEffect(() => {
    onUnauthorizedRedirectRef.current = options.onUnauthorizedRedirect;
  }, [options.onUnauthorizedRedirect]);

  // Active role is userProfile role or currentRoleOverride (from App UI dropdown) or guest
  const activeRole = currentRoleOverride || userProfile?.role || 'customer';
  const isAuthenticated = Boolean(currentUser);

  const [simulatedPortalId, setSimulatedPortalIdState] = useState<PortalId | null>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('globallica_simulated_portal');
      if (saved && PORTAL_REGISTRY[saved as PortalId]) {
        return saved as PortalId;
      }
    }
    return null;
  });

  const [decision, setDecision] = useState<PortalAccessDecision>(() => {
    const params = typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : undefined;
    return checkPortalAccess({
      userRole: activeRole,
      isAuthenticated,
      searchParams: params
    });
  });

  const lastRedirectRef = useRef<string | null>(null);

  // Re-evaluates portal access whenever role, auth, or simulation state changes
  const evaluateAccess = useCallback(() => {
    const params = typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : undefined;
    const newDecision = checkPortalAccess({
      userRole: activeRole,
      isAuthenticated,
      searchParams: params
    });

    setDecision(prev => {
      if (
        prev.allowed === newDecision.allowed &&
        prev.portal.id === newDecision.portal.id &&
        prev.reason === newDecision.reason &&
        prev.userRole === newDecision.userRole &&
        prev.isAuthenticated === newDecision.isAuthenticated
      ) {
        return prev;
      }
      return newDecision;
    });

    // If access is denied and login redirect is required, handle force redirect once per state change
    const redirectKey = `${newDecision.portal.id}:${newDecision.allowed}:${activeRole}:${isAuthenticated}`;
    if (!newDecision.allowed && newDecision.loginRedirectRequired) {
      if (lastRedirectRef.current !== redirectKey) {
        lastRedirectRef.current = redirectKey;
        console.warn(`[PortalGuard] Access denied for portal '${newDecision.portal.name}'. Reason: ${newDecision.reason}`);
        executePortalLoginRedirect(newDecision.portal, newDecision.reason);
        
        if (onUnauthorizedRedirectRef.current) {
          onUnauthorizedRedirectRef.current(newDecision.portal, newDecision.reason || 'Unauthorized subdomain access');
        } else {
          openAuthModal();
        }
      }
    } else {
      lastRedirectRef.current = null;
    }

    return newDecision;
  }, [activeRole, isAuthenticated, openAuthModal]);

  useEffect(() => {
    evaluateAccess();
  }, [evaluateAccess, simulatedPortalId]);

  // Listener for custom security redirect events or URL popstate changes
  useEffect(() => {
    const handleLocationChange = () => {
      evaluateAccess();
    };

    window.addEventListener('popstate', handleLocationChange);
    return () => {
      window.removeEventListener('popstate', handleLocationChange);
    };
  }, [evaluateAccess]);

  const setSimulatedPortal = (portalId: PortalId | 'clear') => {
    if (typeof window === 'undefined') return;

    if (portalId === 'clear') {
      localStorage.removeItem('globallica_simulated_portal');
      setSimulatedPortalIdState(null);
      
      // Clear URL params
      const url = new URL(window.location.href);
      url.searchParams.delete('portal');
      url.searchParams.delete('subdomain');
      window.history.replaceState({}, '', url.toString());
    } else {
      localStorage.setItem('globallica_simulated_portal', portalId);
      setSimulatedPortalIdState(portalId);

      // Update URL search params
      const url = new URL(window.location.href);
      url.searchParams.set('portal', portalId);
      window.history.replaceState({}, '', url.toString());
    }

    // Force re-evaluation
    setTimeout(() => {
      evaluateAccess();
    }, 10);
  };

  return {
    portal: decision.portal,
    decision,
    isAccessDenied: !decision.allowed,
    simulatedPortalId,
    setSimulatedPortal,
    evaluateAccess
  };
}
