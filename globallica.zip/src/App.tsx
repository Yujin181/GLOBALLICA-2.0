import React, { useState } from 'react';
import globallicaLogo from './assets/images/globallica_logo_1785390734136.jpg';
import { Header } from './components/Header';
import { MobileNav } from './components/MobileNav';
import { HeroSearch } from './components/HeroSearch';
import { HousingModule } from './components/HousingModule';
import { ServiceProvidersModule } from './components/ServiceProvidersModule';
import { TransportModule } from './components/TransportModule';
import { MarketplaceModule } from './components/MarketplaceModule';
import { CaretakerPortalModal } from './components/CaretakerPortalModal';
import { FundiOnboardingModal } from './components/FundiOnboardingModal';
import { ProviderPortalModal } from './components/ProviderPortalModal';
import { SellerPostModal } from './components/SellerPostModal';
import { MpesaModal } from './components/MpesaModal';
import { SafetyTipsModal } from './components/SafetyTipsModal';
import { ArchitectureModal } from './components/ArchitectureModal';
import { ListingDetailModal } from './components/ListingDetailModal';
import { PhoneAuthModal } from './components/PhoneAuthModal';
import { NtsaLogbookVerificationModal } from './components/NtsaLogbookVerificationModal';
import { DigitalVettingModal } from './components/DigitalVettingModal';
import { EscrowJobTrackerModal } from './components/EscrowJobTrackerModal';
import { HouseVettingModal } from './components/HouseVettingModal';
import { LiveSelfieModal } from './components/LiveSelfieModal';
import { DomesticSubscriptionModal } from './components/DomesticSubscriptionModal';
import { ContractorNegotiationModal } from './components/ContractorNegotiationModal';
import { PortalGuardBanner } from './components/PortalGuardBanner';
import { PortalAccessDeniedModal } from './components/PortalAccessDeniedModal';
import { usePortalGuard } from './hooks/usePortalGuard';

import { MOCK_HOUSING, MOCK_FUNDIS, MOCK_PRODUCTS, MOCK_DOMESTIC_SUBSCRIPTIONS, MOCK_JOB_BRIEFS, MOCK_CONTRACTOR_BIDS, MOCK_NEGOTIATION_MESSAGES } from './data/mockData';
import { HousingListing, ServiceProvider, ProductListing, JobShowcase, RBACRole, EscrowJobPayment, ServiceVettingInfo, HouseVettingInfo, LiveSelfieVerification, DomesticSubscription, JobBrief, ContractorBid, NegotiationMessage } from './types';
import { ShieldCheck, Heart, Sparkles, MapPin, PhoneCall, CheckCircle2 } from 'lucide-react';
import { AuthProvider, useAuth } from './context/AuthContext';

function MainApp() {
  // Navigation & Category filter
  const [activeCategory, setActiveCategory] = useState<string>('all');
  
  // Role Based Access Control (RBAC)
  const [currentRole, setCurrentRole] = useState<RBACRole>('customer');

  // Portal Guard Utility integration
  const portalGuard = usePortalGuard({
    currentRoleOverride: currentRole,
    onUnauthorizedRedirect: (_portal, _reason) => {
      openAuthModal();
    }
  });

  // Search & Geolocation Filters
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCounty, setSelectedCounty] = useState<string>('all');
  const [selectedConstituency, setSelectedConstituency] = useState<string>('all');
  const [selectedEstate, setSelectedEstate] = useState<string>('all');

  // Datasets state
  const [housingListings, setHousingListings] = useState<HousingListing[]>(MOCK_HOUSING);
  const [fundis, setFundis] = useState<ServiceProvider[]>(MOCK_FUNDIS);
  const [products, setProducts] = useState<ProductListing[]>(MOCK_PRODUCTS);

  // Modals visibility
  const [isCaretakerModalOpen, setIsCaretakerModalOpen] = useState(false);
  const [isFundiModalOpen, setIsFundiModalOpen] = useState(false);
  const [isProviderPortalOpen, setIsProviderPortalOpen] = useState(false);
  const [isSellerModalOpen, setIsSellerModalOpen] = useState(false);
  const [isSafetyModalOpen, setIsSafetyModalOpen] = useState(false);
  const [isArchitectureModalOpen, setIsArchitectureModalOpen] = useState(false);
  const [isNtsaModalOpen, setIsNtsaModalOpen] = useState(false);
  const [ntsaTargetRegNo, setNtsaTargetRegNo] = useState<string | undefined>(undefined);

  // Digital Vetting & Escrow Modals State
  const [isDigitalVettingOpen, setIsDigitalVettingOpen] = useState(false);
  const [vettingTargetProvider, setVettingTargetProvider] = useState<ServiceProvider | null>(null);

  const [isHouseVettingOpen, setIsHouseVettingOpen] = useState(false);
  const [vettingTargetHouse, setVettingTargetHouse] = useState<HousingListing | null>(null);

  const handleOpenHouseVetting = (house?: HousingListing) => {
    setVettingTargetHouse(house || null);
    setIsHouseVettingOpen(true);
  };

  const handleHouseVetted = (houseId: string, vettingInfo: HouseVettingInfo) => {
    setHousingListings(housingListings.map(h => h.id === houseId ? { ...h, vettingInfo } : h));
    if (selectedDetailItem && 'houseType' in selectedDetailItem && selectedDetailItem.id === houseId) {
      setSelectedDetailItem({ ...selectedDetailItem, vettingInfo });
    }
  };

  const [isLiveSelfieOpen, setIsLiveSelfieOpen] = useState(false);
  const [selfieTargetProvider, setSelfieTargetProvider] = useState<ServiceProvider | null>(null);

  const handleOpenLiveSelfie = (provider?: ServiceProvider) => {
    setSelfieTargetProvider(provider || null);
    setIsLiveSelfieOpen(true);
  };

  const handleSelfieVerified = (providerId: string, selfieData: LiveSelfieVerification) => {
    setFundis(fundis.map(p => p.id === providerId ? { ...p, liveSelfieVerification: selfieData } : p));
    if (selectedDetailItem && 'tradeSkill' in selectedDetailItem && selectedDetailItem.id === providerId) {
      setSelectedDetailItem({ ...selectedDetailItem, liveSelfieVerification: selfieData });
    }
  };

  // Domestic Subscription State
  const [subscriptions, setSubscriptions] = useState<DomesticSubscription[]>(MOCK_DOMESTIC_SUBSCRIPTIONS || []);
  const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = useState(false);
  const [subscriptionTargetProvider, setSubscriptionTargetProvider] = useState<ServiceProvider | null>(null);

  const handleOpenSubscriptions = (provider?: ServiceProvider) => {
    setSubscriptionTargetProvider(provider || null);
    setIsSubscriptionModalOpen(true);
  };

  const handleAddSubscription = (newSub: DomesticSubscription) => {
    setSubscriptions([newSub, ...subscriptions]);
  };

  const handleUpdateSubscription = (updatedSub: DomesticSubscription) => {
    setSubscriptions(subscriptions.map(s => s.id === updatedSub.id ? updatedSub : s));
  };

  // Contractor Negotiation & Job Brief State
  const [jobBriefs, setJobBriefs] = useState<JobBrief[]>(MOCK_JOB_BRIEFS || []);
  const [contractorBids, setContractorBids] = useState<ContractorBid[]>(MOCK_CONTRACTOR_BIDS || []);
  const [negotiationMessages, setNegotiationMessages] = useState<NegotiationMessage[]>(MOCK_NEGOTIATION_MESSAGES || []);
  const [isContractorModalOpen, setIsContractorModalOpen] = useState(false);

  const handleAddJobBrief = (newBrief: JobBrief) => setJobBriefs([newBrief, ...jobBriefs]);
  const handleAddBid = (newBid: ContractorBid) => setContractorBids([newBid, ...contractorBids]);
  const handleSendMessage = (msg: NegotiationMessage) => setNegotiationMessages([...negotiationMessages, msg]);

  const handleUpdateBidStatus = (bidId: string, status: ContractorBid['status'], updatedQuoteKES?: number) => {
    setContractorBids(contractorBids.map(b => b.id === bidId ? {
      ...b,
      status,
      quoteAmountKES: updatedQuoteKES || b.quoteAmountKES
    } : b));
  };

  const handleUpdateBriefStatus = (briefId: string, status: JobBrief['status']) => {
    setJobBriefs(jobBriefs.map(b => b.id === briefId ? { ...b, status } : b));
  };

  const handleOpenEscrowForContractorBid = (brief: JobBrief, bid: ContractorBid) => {
    const newEscrowJob: EscrowJobPayment = {
      id: `ESC-BID-${Date.now()}`,
      providerId: bid.contractorId,
      providerName: bid.contractorName,
      providerPhone: bid.contractorPhone,
      tradeSkill: bid.contractorSkill,
      clientName: brief.clientName,
      clientPhone: brief.clientPhone,
      amountKES: bid.quoteAmountKES,
      jobDescription: brief.title,
      depositDate: new Date().toISOString().split('T')[0],
      mpesaDepositReceipt: `RKE${Math.floor(1000000 + Math.random() * 9000000)}`,
      releaseCode: `${Math.floor(100000 + Math.random() * 900000)}`,
      status: 'DEPOSITED_ESCROW'
    };
    setEscrowJobs([newEscrowJob, ...escrowJobs]);
    setIsContractorModalOpen(false);
    setIsEscrowTrackerOpen(true);
  };

  const [isEscrowTrackerOpen, setIsEscrowTrackerOpen] = useState(false);
  const [escrowTargetProvider, setEscrowTargetProvider] = useState<ServiceProvider | null>(null);

  const [escrowJobs, setEscrowJobs] = useState<EscrowJobPayment[]>([
    {
      id: 'ESC-JOB-101',
      providerId: 'fundi-1',
      providerName: 'Dennis Mwangi',
      providerPhone: '0712345678',
      tradeSkill: 'Plumber',
      clientName: 'David K.',
      clientPhone: '0722114455',
      amountKES: 2500,
      jobDescription: 'Fix underground pipe burst and replace bathroom taps in Kilimani',
      depositDate: '2026-07-26',
      mpesaDepositReceipt: 'RKE8819201',
      releaseCode: '892104',
      status: 'DEPOSITED_ESCROW'
    },
    {
      id: 'ESC-JOB-102',
      providerId: 'fundi-7',
      providerName: 'John Kamau',
      providerPhone: '0711998877',
      tradeSkill: 'Lorry / Truck For Hire',
      clientName: 'Sarah M.',
      clientPhone: '0733887766',
      amountKES: 12000,
      jobDescription: 'Haul 5 Tons of building ballast sand from Athi River to Roysambu',
      depositDate: '2026-07-25',
      mpesaDepositReceipt: 'RKE7721094',
      releaseCode: '729104',
      status: 'CLIENT_VERIFIED_PENDING_CODE'
    }
  ]);

  const handleOpenDigitalVetting = (provider?: ServiceProvider) => {
    setVettingTargetProvider(provider || null);
    setIsDigitalVettingOpen(true);
  };

  const handleVettingComplete = (providerId: string, vettingInfo: ServiceVettingInfo) => {
    setFundis(fundis.map(f => f.id === providerId ? { ...f, vettingInfo } : f));
    if (selectedDetailItem && 'tradeSkill' in selectedDetailItem && selectedDetailItem.id === providerId) {
      setSelectedDetailItem({ ...selectedDetailItem, vettingInfo });
    }
  };

  const handleOpenEscrowTracker = (provider?: ServiceProvider) => {
    setEscrowTargetProvider(provider || null);
    setIsEscrowTrackerOpen(true);
  };

  const handleAddEscrowJob = (newJob: EscrowJobPayment) => {
    setEscrowJobs([newJob, ...escrowJobs]);
  };

  const handleVerifyAndIssueCode = (jobId: string) => {
    setEscrowJobs(escrowJobs.map(j => {
      if (j.id === jobId) {
        return { ...j, status: 'CLIENT_VERIFIED_PENDING_CODE' };
      }
      return j;
    }));
  };

  const handleReleaseEscrowPayment = (jobId: string, inputCode: string): boolean => {
    const targetJob = escrowJobs.find(j => j.id === jobId);
    if (!targetJob) return false;

    if (targetJob.releaseCode.trim() === inputCode.trim()) {
      setEscrowJobs(escrowJobs.map(j => {
        if (j.id === jobId) {
          return {
            ...j,
            status: 'FUNDS_RELEASED_TO_PROVIDER',
            releasedAt: new Date().toLocaleString()
          };
        }
        return j;
      }));
      return true;
    }
    return false;
  };

  const handleOpenNtsaVerification = (initialRegNo?: string) => {
    setNtsaTargetRegNo(initialRegNo);
    setIsNtsaModalOpen(true);
  };

  const handleNtsaVerificationComplete = (verification: any) => {
    if (selectedDetailItem) {
      const updatedItem = { ...selectedDetailItem, ntsaVerification: verification };
      setSelectedDetailItem(updatedItem);

      if ('tradeSkill' in selectedDetailItem) {
        setFundis(fundis.map(f => f.id === selectedDetailItem.id ? { ...f, ntsaVerification: verification } : f));
      } else if ('condition' in selectedDetailItem) {
        setProducts(products.map(p => p.id === selectedDetailItem.id ? { ...p, ntsaVerification: verification } : p));
      }
    }
  };
  
  // Firebase Auth modal
  const { isAuthModalOpen, openAuthModal, closeAuthModal } = useAuth();

  // Detail Modal item
  const [selectedDetailItem, setSelectedDetailItem] = useState<HousingListing | ServiceProvider | ProductListing | null>(null);

  // M-Pesa STK Push Modal state
  const [mpesaModalData, setMpesaModalData] = useState<{
    isOpen: boolean;
    title: string;
    amountKES: number;
    recipientName: string;
    itemDescription: string;
  }>({
    isOpen: false,
    title: '',
    amountKES: 500,
    recipientName: '',
    itemDescription: ''
  });

  // Handlers for adding new data
  const handleAddHousing = (newHouse: HousingListing) => {
    setHousingListings([newHouse, ...housingListings]);
  };

  const handleAddFundi = (newFundi: ServiceProvider) => {
    setFundis([newFundi, ...fundis]);
  };

  const handleUpdateFundiPortfolio = (fundiId: string, updatedPortfolio: JobShowcase[]) => {
    setFundis(fundis.map(f => {
      if (f.id === fundiId) {
        return { ...f, portfolioShowcase: updatedPortfolio };
      }
      return f;
    }));
  };

  const handleAddProduct = (newProd: ProductListing) => {
    setProducts([newProd, ...products]);
  };

  const handleToggleProductStatus = (prodId: string) => {
    setProducts(products.map(p => {
      if (p.id === prodId) {
        return { ...p, status: p.status === 'Available' ? 'Sold' : 'Available' };
      }
      return p;
    }));
  };

  const handleOpenMpesaHousing = (house: HousingListing) => {
    setMpesaModalData({
      isOpen: true,
      title: 'Housing Viewing Slot Reservation',
      amountKES: 500,
      recipientName: house.caretaker.name,
      itemDescription: `Viewing fee for ${house.title} in ${house.estate}`
    });
  };

  const handleOpenMpesaFundi = (fundi: ServiceProvider) => {
    setMpesaModalData({
      isOpen: true,
      title: 'Emergency Fundi Deposit',
      amountKES: fundi.rateKES,
      recipientName: fundi.name,
      itemDescription: `Deposit for ${fundi.tradeSkill} in ${fundi.operationalEstate}`
    });
  };

  // Global search filtering across datasets
  const filterBySearchAndLocation = <T extends { county?: string; estate?: string; operationalCounty?: string; operationalEstate?: string; title?: string; name?: string; description?: string; bio?: string }>(
    items: T[]
  ) => {
    return items.filter(item => {
      // Location matching
      const countyVal = item.county || item.operationalCounty || '';
      const estateVal = item.estate || item.operationalEstate || '';

      if (selectedCounty !== 'all') {
        const normSelected = selectedCounty.replace(/^\d+:\s*/, '').trim().toLowerCase();
        const normItemCounty = countyVal.replace(/^\d+:\s*/, '').trim().toLowerCase();
        if (normItemCounty !== normSelected && !normItemCounty.includes(normSelected) && !normSelected.includes(normItemCounty)) {
          return false;
        }
      }
      if (selectedEstate !== 'all' && estateVal.toLowerCase() !== selectedEstate.toLowerCase()) {
        return false;
      }

      // Query matching
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      const titleName = (item.title || item.name || '').toLowerCase();
      const descBio = (item.description || item.bio || '').toLowerCase();

      return titleName.includes(q) || descBio.includes(q) || estateVal.toLowerCase().includes(q) || countyVal.toLowerCase().includes(q);
    });
  };

  const filteredHousing = filterBySearchAndLocation(housingListings);
  const filteredFundis = filterBySearchAndLocation(fundis);
  const filteredProducts = filterBySearchAndLocation(products);

  const totalListingsCount = filteredHousing.length + filteredFundis.length + filteredProducts.length;

  return (
    <div className="min-h-screen w-full max-w-full bg-stone-100 text-stone-900 font-sans pb-20 md:pb-10 flex flex-col selection:bg-amber-300 selection:text-emerald-950 overflow-x-hidden">
      {/* Subdomain Portal Guard & Routing Banner */}
      <PortalGuardBanner
        currentPortal={portalGuard.portal}
        currentRole={currentRole}
        onRoleChange={(newRole) => setCurrentRole(newRole)}
        isAccessDenied={portalGuard.isAccessDenied}
        denialReason={portalGuard.decision.reason}
        simulatedPortalId={portalGuard.simulatedPortalId}
        onSelectPortal={portalGuard.setSimulatedPortal}
        onOpenLogin={openAuthModal}
      />

      {/* 1. Sticky Navigation Header */}
      <Header
        currentRole={currentRole}
        setCurrentRole={setCurrentRole}
        onOpenCaretakerPortal={() => setIsCaretakerModalOpen(true)}
        onOpenFundiPortal={() => setIsFundiModalOpen(true)}
        onOpenMediaPortal={() => setIsProviderPortalOpen(true)}
        onOpenSellerPortal={() => setIsSellerModalOpen(true)}
        onOpenArchitectureModal={() => setIsArchitectureModalOpen(true)}
        onOpenSafetyModal={() => setIsSafetyModalOpen(true)}
        onOpenPhoneAuthModal={openAuthModal}
        onOpenDigitalVetting={() => handleOpenDigitalVetting()}
        onOpenEscrowTracker={() => handleOpenEscrowTracker()}
        onOpenHouseVetting={() => handleOpenHouseVetting()}
        onOpenLiveSelfie={() => handleOpenLiveSelfie()}
        onOpenSubscriptions={() => handleOpenSubscriptions()}
        activeCategory={activeCategory}
        setActiveCategory={setActiveCategory}
      />

      {/* 2. Unified Hero Search with Cascading Location Filters */}
      <HeroSearch
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        selectedCounty={selectedCounty}
        setSelectedCounty={setSelectedCounty}
        selectedConstituency={selectedConstituency}
        setSelectedConstituency={setSelectedConstituency}
        selectedEstate={selectedEstate}
        setSelectedEstate={setSelectedEstate}
        activeCategory={activeCategory}
        setActiveCategory={setActiveCategory}
        totalListingsCount={totalListingsCount}
      />

      {/* 3. Main Content Container */}
      <main className="w-full max-w-full px-3 sm:px-6 lg:px-8 py-6 flex-1 space-y-10 overflow-x-hidden">
        {/* Active Filter Notice */}
        {(selectedCounty !== 'all' || selectedEstate !== 'all' || searchQuery) && (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 text-xs flex items-center justify-between text-amber-950 font-medium">
            <div className="flex items-center gap-2">
              <MapPin size={16} className="text-amber-600 shrink-0" />
              <span>
                Filtering listings for:{' '}
                <strong className="font-bold text-emerald-900">
                  {selectedEstate !== 'all' ? selectedEstate : selectedCounty !== 'all' ? selectedCounty : 'Kenya-wide'}
                </strong>
                {searchQuery && <> matching <em>"{searchQuery}"</em></>}
                {' '}— ({totalListingsCount} matches found)
              </span>
            </div>

            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCounty('all');
                setSelectedConstituency('all');
                setSelectedEstate('all');
              }}
              className="text-emerald-800 font-bold hover:underline shrink-0 ml-2"
            >
              Reset Location
            </button>
          </div>
        )}

        {/* Category Routing Render */}
        {(activeCategory === 'all' || activeCategory === 'housing') && (
          <section id="housing-section">
            <HousingModule
              listings={filteredHousing}
              onSelectHousing={(house) => setSelectedDetailItem(house)}
              onReserveMpesa={handleOpenMpesaHousing}
              onOpenCaretakerPortal={() => setIsCaretakerModalOpen(true)}
              onOpenHouseVetting={(house) => handleOpenHouseVetting(house)}
            />
          </section>
        )}

        {(activeCategory === 'all' || activeCategory === 'services') && (
          <section id="services-section" className="pt-2">
            <ServiceProvidersModule
              fundis={filteredFundis}
              selectedEstate={selectedEstate}
              selectedCounty={selectedCounty}
              onOpenFundiPortal={() => setIsFundiModalOpen(true)}
              onOpenMediaPortal={() => setIsProviderPortalOpen(true)}
              onOpenNtsaVerification={() => handleOpenNtsaVerification()}
              onOpenDigitalVetting={(provider) => handleOpenDigitalVetting(provider)}
              onOpenEscrowTracker={(provider) => handleOpenEscrowTracker(provider)}
              onOpenLiveSelfie={(provider) => handleOpenLiveSelfie(provider)}
              onOpenSubscriptions={(provider) => handleOpenSubscriptions(provider)}
              onOpenContractorNegotiation={() => setIsContractorModalOpen(true)}
              onHireFundiMpesa={handleOpenMpesaFundi}
              onSelectFundi={(fundi) => setSelectedDetailItem(fundi)}
            />
          </section>
        )}

        {(activeCategory === 'all' || activeCategory === 'transport') && (
          <section id="transport-section" className="pt-2">
            <TransportModule
              providers={filteredFundis}
              selectedEstate={selectedEstate}
              selectedCounty={selectedCounty}
              onOpenDriverPortal={() => setIsFundiModalOpen(true)}
              onOpenMediaPortal={() => setIsProviderPortalOpen(true)}
              onOpenNtsaVerification={() => handleOpenNtsaVerification()}
              onOpenDigitalVetting={(provider) => handleOpenDigitalVetting(provider)}
              onOpenEscrowTracker={(provider) => handleOpenEscrowTracker(provider)}
              onBookTransportMpesa={handleOpenMpesaFundi}
              onSelectProvider={(provider) => setSelectedDetailItem(provider)}
            />
          </section>
        )}

        {(activeCategory === 'all' || activeCategory === 'vehicles' || activeCategory === 'products' || activeCategory === 'marketplace') && (
          <section id="marketplace-section" className="pt-2">
            <MarketplaceModule
              products={filteredProducts}
              onSelectProduct={(prod) => setSelectedDetailItem(prod)}
              onToggleStatus={handleToggleProductStatus}
              onOpenSellerPortal={() => setIsSellerModalOpen(true)}
              onOpenNtsaVerification={() => handleOpenNtsaVerification()}
              currentRole={currentRole}
            />
          </section>
        )}
      </main>

      {/* 4. Footer */}
      <footer className="bg-emerald-950 text-emerald-200 text-xs py-8 px-3 sm:px-6 lg:px-8 border-t border-emerald-900 mt-12 w-full max-w-full">
        <div className="w-full max-w-full mx-auto grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5">
              <img 
                src={globallicaLogo} 
                alt="GLOBALLICA Logo" 
                referrerPolicy="no-referrer"
                className="w-8 h-8 rounded-lg object-cover border border-amber-400/50 shadow-md"
              />
              <span className="font-extrabold text-base text-white">GLOBALLICA Kenya</span>
            </div>
            <p className="text-[11px] text-emerald-300 leading-relaxed">
              Kenya’s local marketplace for vacant housing, verified caretakers, local fundis (plumbers, electricians, mechanics) and vehicles.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-white text-xs uppercase mb-2 text-amber-300">Popular Estates</h4>
            <ul className="space-y-1 text-[11px] text-emerald-300">
              <li>📍 Kilimani & Kileleshwa, Nairobi</li>
              <li>📍 Roysambu & Mirema, Kasarani</li>
              <li>📍 Pipeline & Embakasi</li>
              <li>📍 Ruaka & Kiambu Road</li>
              <li>📍 Nyali & Bamburi, Mombasa</li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white text-xs uppercase mb-2 text-amber-300">Market Services</h4>
            <ul className="space-y-1 text-[11px] text-emerald-300">
              <li>✓ Vacant Bedsitter & 1BR Listings</li>
              <li>✓ Direct Caretaker Contact Info</li>
              <li>✓ Emergency Local Fundi Directory</li>
              <li>✓ Safaricom M-Pesa STK Push Express</li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white text-xs uppercase mb-2 text-amber-300">Trust & Safety</h4>
            <button
              onClick={() => setIsSafetyModalOpen(true)}
              className="bg-emerald-900 hover:bg-emerald-800 text-amber-300 font-bold px-3 py-2 rounded-xl border border-emerald-700 w-full text-left transition-colors cursor-pointer flex items-center gap-2"
            >
              <ShieldCheck size={16} />
              <span>Read Anti-Scam Rules</span>
            </button>
            <p className="text-[10px] text-emerald-400 mt-2">
              Never pay house deposit before physical viewing with the Caretaker.
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto mt-8 pt-4 border-t border-emerald-900/80 flex flex-col sm:flex-row items-center justify-between text-[11px] text-emerald-400 gap-2">
          <span>© {new Date().getFullYear()} GLOBALLICA Kenya. Market Safi kwa Kila Mkenya.</span>
          <button
            onClick={() => setIsArchitectureModalOpen(true)}
            className="text-amber-300 underline hover:text-amber-200 cursor-pointer"
          >
            Developer Architecture Blueprint & DB Schema
          </button>
        </div>
      </footer>

      {/* 5. Mobile Bottom Navigation */}
      <MobileNav
        activeCategory={activeCategory}
        setActiveCategory={setActiveCategory}
        onOpenCaretakerPortal={() => setIsCaretakerModalOpen(true)}
        onOpenFundiPortal={() => setIsFundiModalOpen(true)}
        onOpenSellerPortal={() => setIsSellerModalOpen(true)}
        onOpenArchitectureModal={() => setIsArchitectureModalOpen(true)}
      />

      {/* 6. Interactive Modals */}
      <PhoneAuthModal
        isOpen={isAuthModalOpen}
        onClose={closeAuthModal}
        initialRole={
          currentRole === 'admin' || currentRole === 'customer' 
            ? 'resident' 
            : (currentRole as 'fundi' | 'seller' | 'caretaker' | 'resident')
        }
      />

      <CaretakerPortalModal
        isOpen={isCaretakerModalOpen}
        onClose={() => setIsCaretakerModalOpen(false)}
        onAddHousing={handleAddHousing}
      />

      <FundiOnboardingModal
        isOpen={isFundiModalOpen}
        onClose={() => setIsFundiModalOpen(false)}
        onAddFundi={handleAddFundi}
        onOpenNtsaVerification={handleOpenNtsaVerification}
      />

      <ProviderPortalModal
        isOpen={isProviderPortalOpen}
        onClose={() => setIsProviderPortalOpen(false)}
        fundisList={fundis}
        onUpdateFundiPortfolio={handleUpdateFundiPortfolio}
        onSelectFundiForPreview={(fundi) => setSelectedDetailItem(fundi)}
      />

      <SellerPostModal
        isOpen={isSellerModalOpen}
        onClose={() => setIsSellerModalOpen(false)}
        onAddProduct={handleAddProduct}
        onOpenNtsaVerification={handleOpenNtsaVerification}
      />

      <MpesaModal
        isOpen={mpesaModalData.isOpen}
        onClose={() => setMpesaModalData({ ...mpesaModalData, isOpen: false })}
        title={mpesaModalData.title}
        amountKES={mpesaModalData.amountKES}
        recipientName={mpesaModalData.recipientName}
        itemDescription={mpesaModalData.itemDescription}
      />

      <SafetyTipsModal
        isOpen={isSafetyModalOpen}
        onClose={() => setIsSafetyModalOpen(false)}
      />

      <ArchitectureModal
        isOpen={isArchitectureModalOpen}
        onClose={() => setIsArchitectureModalOpen(false)}
      />

      <ListingDetailModal
        item={selectedDetailItem}
        onClose={() => setSelectedDetailItem(null)}
        onReserveMpesa={handleOpenMpesaHousing}
        onOpenNtsaVerification={handleOpenNtsaVerification}
        onOpenDigitalVetting={(provider) => handleOpenDigitalVetting(provider)}
        onOpenEscrowTracker={(provider) => handleOpenEscrowTracker(provider)}
        onOpenHouseVetting={(house) => handleOpenHouseVetting(house)}
        onOpenLiveSelfie={(provider) => handleOpenLiveSelfie(provider)}
        onOpenSubscriptions={(provider) => handleOpenSubscriptions(provider)}
      />

      <DomesticSubscriptionModal
        isOpen={isSubscriptionModalOpen}
        onClose={() => setIsSubscriptionModalOpen(false)}
        targetProvider={subscriptionTargetProvider}
        allProviders={fundis}
        subscriptions={subscriptions}
        onAddSubscription={handleAddSubscription}
        onUpdateSubscription={handleUpdateSubscription}
        onOpenLiveSelfie={handleOpenLiveSelfie}
      />

      <NtsaLogbookVerificationModal
        isOpen={isNtsaModalOpen}
        onClose={() => setIsNtsaModalOpen(false)}
        initialRegNo={ntsaTargetRegNo}
        onVerificationComplete={handleNtsaVerificationComplete}
      />

      <DigitalVettingModal
        isOpen={isDigitalVettingOpen}
        onClose={() => setIsDigitalVettingOpen(false)}
        targetProvider={vettingTargetProvider}
        onVettingComplete={handleVettingComplete}
      />

      <HouseVettingModal
        isOpen={isHouseVettingOpen}
        onClose={() => setIsHouseVettingOpen(false)}
        targetHouse={vettingTargetHouse}
        allHouses={housingListings}
        onHouseVetted={handleHouseVetted}
      />

      <LiveSelfieModal
        isOpen={isLiveSelfieOpen}
        onClose={() => setIsLiveSelfieOpen(false)}
        targetProvider={selfieTargetProvider}
        allProviders={fundis}
        onSelfieVerified={handleSelfieVerified}
      />

      <EscrowJobTrackerModal
        isOpen={isEscrowTrackerOpen}
        onClose={() => setIsEscrowTrackerOpen(false)}
        initialProvider={escrowTargetProvider}
        escrowJobs={escrowJobs}
        onAddEscrowJob={handleAddEscrowJob}
        onVerifyAndIssueCode={handleVerifyAndIssueCode}
        onReleaseEscrowPayment={handleReleaseEscrowPayment}
      />

      <ContractorNegotiationModal
        isOpen={isContractorModalOpen}
        onClose={() => setIsContractorModalOpen(false)}
        jobBriefs={jobBriefs}
        contractorBids={contractorBids}
        negotiationMessages={negotiationMessages}
        allProviders={fundis}
        onAddJobBrief={handleAddJobBrief}
        onAddBid={handleAddBid}
        onSendMessage={handleSendMessage}
        onUpdateBidStatus={handleUpdateBidStatus}
        onUpdateBriefStatus={handleUpdateBriefStatus}
        onOpenEscrowForBid={handleOpenEscrowForContractorBid}
      />

      <PortalAccessDeniedModal
        isOpen={portalGuard.isAccessDenied}
        portal={portalGuard.portal}
        currentRole={currentRole}
        reason={portalGuard.decision.reason}
        onOpenLogin={openAuthModal}
        onReturnToPublic={() => portalGuard.setSimulatedPortal('public')}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}

