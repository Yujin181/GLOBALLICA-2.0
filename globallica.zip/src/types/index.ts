export type RBACRole = 'customer' | 'caretaker' | 'seller' | 'fundi' | 'admin';

export type CategoryType = 'housing' | 'services' | 'transport' | 'vehicles' | 'products';

export interface LocationItem {
  county: string;
  constituency: string;
  wardOrEstate: string;
  latitude: number;
  longitude: number;
}

export interface CaretakerInfo {
  id: string;
  name: string;
  phone: string; // e.g. +254712345678
  whatsapp: string;
  isVerified: boolean;
  rating: number;
  reviewCount: number;
  estateBase: string;
  avatar: string;
  propertiesCount: number;
}

export interface HouseVettingInfo {
  isVetted: boolean;
  lrTitleDeedNo: string;
  landRegistryStatus: 'ARDHISASA_VERIFIED' | 'COUNTY_REGISTERED' | 'UNVERIFIED';
  registeredOwnerName: string;
  geoGpsCoordinatesVerified: boolean;
  physicalInspectorName?: string;
  verifiedAt: string;
}

export interface HousingListing {
  id: string;
  title: string;
  houseType: 'Bedsitter' | 'Single Room' | '1 Bedroom' | '2 Bedroom' | '3 Bedroom' | 'Maisonette' | 'Commercial' | 'Airbnb / Furnished';
  rentKES: number;
  depositTerms: string; // e.g. "1 Month Rent + KES 2,000 Water Deposit"
  county: string;
  constituency: string;
  estate: string;
  latitude: number;
  longitude: number;
  amenities: string[]; // Borehole Water, Wi-Fi Ready, CCTV, KPLC Token Meter, Parking, Security Guard, Gym, Backup Generator, Balcony
  photos: string[];
  description: string;
  caretaker: CaretakerInfo;
  status: 'vacant' | 'occupied';
  featured: boolean;
  createdAt: string;
  views: number;
  vettingInfo?: HouseVettingInfo;
}

export interface JobShowcase {
  id: string;
  title: string;
  description: string;
  photoUrl: string;
  videoUrl?: string; // Primary video file upload (Blob/Data URL) or video link
  photos?: string[]; // Array of image URLs / Data URLs
  videos?: string[]; // Array of video URLs / Blob URLs
  completedDate?: string;
  location?: string;
}

export interface NtsaLogbookVerification {
  isVerified: boolean;
  registrationNo: string; // e.g. KDG 482Z or KCU 889M
  logbookSerial: string; // e.g. KE-LOG-992014-X
  chassisNo: string; // e.g. JTEHH20V800192842
  engineNo: string; // e.g. 1KD-3829104
  registeredOwner: string; // e.g. Mvule Motors Limited / David Mwangi
  vehicleClass: string; // e.g. Heavy Goods Lorry / Medium Saloon Cab / Private Motor Vehicle
  timsRefNumber: string; // e.g. TIMS-NTSA-2026-881920
  verificationDate: string; // e.g. 2026-07-26
  qrPayloadRaw?: string;
  status: 'AUTHENTIC_VERIFIED' | 'PENDING' | 'INVALID';
}

export interface ServiceVettingInfo {
  isVetted: boolean;
  nationalIdNo: string; // e.g. 33891024
  iprsVerified: boolean; // Integrated Population Registration System check
  goodConductCertNo: string; // e.g. DCI-CID-2026-992014
  dciVerified: boolean; // Directorate of Criminal Investigations Good Conduct check
  tradeLicenceNo?: string; // NTSA PSV / Fundi TVET Certificate
  vettingDate: string; // e.g. 2026-07-26
  clearanceStatus: 'CLEARED_NO_RECORD' | 'PENDING' | 'REJECTED';
}

export interface EscrowJobPayment {
  id: string;
  providerId: string;
  providerName: string;
  providerPhone: string;
  tradeSkill: string;
  clientName: string;
  clientPhone: string;
  amountKES: number;
  jobDescription: string;
  depositDate: string;
  mpesaDepositReceipt: string;
  releaseCode: string; // 6-digit verification release code e.g. "892104"
  status: 'DEPOSITED_ESCROW' | 'CLIENT_VERIFIED_PENDING_CODE' | 'FUNDS_RELEASED_TO_PROVIDER';
  releasedAt?: string;
}

export interface LiveSelfieVerification {
  isSelfieVerified: boolean;
  capturedSelfieUrl?: string;
  matchedScorePercent: number; // e.g. 98.6
  verifiedAt?: string;
  facialLandmarksCount: number;
  isOnlineActive: boolean;
  roleSensitivityLevel: 'HIGH_SENSITIVE' | 'MEDIUM_SENSITIVE' | 'STANDARD';
}

export interface ServiceProvider {
  id: string;
  name: string;
  phone: string;
  whatsapp: string;
  tradeSkill: 'Plumber' | 'Electrician' | 'Auto Mechanic' | 'Fundi / Carpenter' | 'Mama Fua / House Cleaner' | 'BodaBoda / Delivery' | 'Cab / Taxi Ride (Uber Style)' | 'Lorry / Truck For Hire' | 'Mason / Painter' | 'Appliance Repair' | 'Movers' | 'Solar & Borehole Tech';
  operationalCounty: string;
  operationalEstate: string;
  latitude: number;
  longitude: number;
  pricingModel: 'Per Hour' | 'Per Job' | 'Negotiable';
  rateKES: number;
  availability: 'Available Now' | 'On a Job' | 'Off Duty';
  isVerified: boolean;
  badge: 'Top Rated' | 'Verified Fundi' | 'Super Pro' | 'Community Master';
  rating: number;
  reviewsCount: number;
  avatar: string;
  bio: string;
  skillsList: string[];
  completedJobsCount: number;
  distanceKm?: number;
  portfolioShowcase?: JobShowcase[];
  mediaPhotos?: string[]; // Provider-level photo gallery
  mediaVideos?: string[]; // Provider-level video gallery
  ntsaVerification?: NtsaLogbookVerification;
  vettingInfo?: ServiceVettingInfo;
  liveSelfieVerification?: LiveSelfieVerification;
}

export interface ProductListing {
  id: string;
  title: string;
  category: 'Vehicles' | 'Electronics & Phones' | 'Home & Furniture' | 'Fashion & Beauty' | 'Farm & Agribusiness' | 'Tools & Building';
  subCategory?: string;
  priceKES: number;
  isNegotiable: boolean;
  condition: 'Brand New' | 'Foreign Used (Import)' | 'Kenyan Used';
  county: string;
  estate: string;
  photos: string[];
  description: string;
  sellerName: string;
  sellerPhone: string;
  sellerWhatsapp: string;
  isSellerVerified: boolean;
  status: 'Available' | 'Sold';
  featured: boolean;
  createdAt: string;
  specs?: Record<string, string>; // e.g. YOM, Engine, Transmission for cars
  ntsaVerification?: NtsaLogbookVerification;
}

export interface Review {
  id: string;
  authorName: string;
  authorPhone: string;
  rating: number;
  comment: string;
  date: string;
  targetId: string; // Housing ID or Fundi ID or Seller ID
}

export interface DomesticSubscription {
  id: string;
  providerId: string;
  providerName: string;
  providerSkill: string;
  providerAvatar: string;
  clientName: string;
  clientPhone: string;
  clientEstate: string;
  frequency: 'WEEKLY' | 'BI_WEEKLY' | 'MONTHLY' | 'CUSTOM_DAYS';
  preferredDays: string[];
  preferredTimeSlot: string;
  ratePerVisitKES: number;
  autoEscrowDeduct: boolean;
  nextScheduledDate: string;
  status: 'ACTIVE' | 'PAUSED' | 'CANCELLED';
  createdDate: string;
  mpesaAutoBillNumber?: string;
  completedVisitsCount: number;
  lastEscrowDeductionAt?: string;
}

export interface JobBrief {
  id: string;
  title: string;
  category: 'Construction & Masonry' | 'Electrical Wiring & Solar' | 'Plumbing & Drainage' | 'Roofing & Steelwork' | 'Painting & Interior Fitout' | 'Borehole & Irrigation' | 'Other Major Work';
  location: string;
  county: string;
  budgetEstimateKES: number;
  isBudgetNegotiable: boolean;
  photos: string[];
  description: string;
  clientName: string;
  clientPhone: string;
  clientEmail?: string;
  status: 'OPEN_FOR_BIDS' | 'UNDER_NEGOTIATION' | 'CONTRACT_AWARDED' | 'COMPLETED';
  createdAt: string;
  bidsCount: number;
}

export interface ItemizedQuote {
  description: string;
  costKES: number;
}

export interface ContractorBid {
  id: string;
  briefId: string;
  contractorId: string;
  contractorName: string;
  contractorSkill: string;
  contractorAvatar: string;
  contractorPhone: string;
  isContractorVerified: boolean;
  quoteAmountKES: number;
  timelineEstimate: string;
  materialsIncluded: boolean;
  itemizedBreakdown: ItemizedQuote[];
  notes: string;
  status: 'PENDING' | 'COUNTERED' | 'ACCEPTED' | 'REJECTED';
  submittedAt: string;
}

export interface NegotiationMessage {
  id: string;
  briefId: string;
  bidId: string;
  senderType: 'CLIENT' | 'CONTRACTOR';
  senderName: string;
  text: string;
  proposedQuoteAmountKES?: number;
  isCounterOffer?: boolean;
  timestamp: string;
}

export interface UserProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  role: RBACRole;
  county: string;
  estate: string;
  avatar: string;
  isPhoneVerified: boolean;
  savedFavoriteIds: string[];
}
